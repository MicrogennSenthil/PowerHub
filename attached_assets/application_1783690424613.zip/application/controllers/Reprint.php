<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Reprint extends CI_Controller {

function __construct() {
        parent::__construct();
         define('ActMenu','Reprint');
		$ci =& get_instance();
		$ci->router->class;  
		$ci->router->method; 
    }

	 
	public function Purchase($ID=0)
	{
		$data=array('F_Class'=>'Reprint','F_Ctrl'=>'Purchase','ID'=>$ID);
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	 public function PurchaseDet($ID=0)
	{
		$data=array('F_Class'=>'Reprint','F_Ctrl'=>'PurchaseDet','ID'=>$ID);
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	public function Payment($ID=0)
	{
		$data=array('F_Class'=>'Reprint','F_Ctrl'=>'Payment','ID'=>$ID);
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	 public function PaymentDet($ID=0)
	{
		$data=array('F_Class'=>'Reprint','F_Ctrl'=>'PaymentDet','ID'=>$ID);
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	public function Print_Payment($ID=0,$PTY)
	{
		$data=array('F_Class'=>'Reprint','F_Ctrl'=>'Print_Payment','ID'=>$ID,'PTY'=>$PTY);
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
    public function Sales($ID=0)
	{
		$data=array('F_Class'=>'Reprint','F_Ctrl'=>'Sales','ID'=>$ID);
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	 public function SalesDet($ID=0)
	{
		$data=array('F_Class'=>'Reprint','F_Ctrl'=>'SalesDet','ID'=>$ID);
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	
	public function Print_Sales($ID=0,$PTY)
	{
		$data=array('F_Class'=>'Reprint','F_Ctrl'=>'Print_Sales','ID'=>$ID,'PTY'=>$PTY);
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	public function Collection($ID=0)
	{
		$data=array('F_Class'=>'Reprint','F_Ctrl'=>'Collection','ID'=>$ID);
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	 public function CollectionDet($ID=0)
	{
		$data=array('F_Class'=>'Reprint','F_Ctrl'=>'CollectionDet','ID'=>$ID);
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	public function Print_Collection($ID=0,$PTY)
	{
		$data=array('F_Class'=>'Reprint','F_Ctrl'=>'Print_Collection','ID'=>$ID,'PTY'=>$PTY);
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	
	
	public function Print_Purchase($ID=0,$PTY)
	{
		$data=array('F_Class'=>'Reprint','F_Ctrl'=>'Print_Purchase','ID'=>$ID,'PTY'=>$PTY);
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	public function Print_Voucher($ID=0)
	{
		$data=array('F_Class'=>'Reprint','F_Ctrl'=>'Print_Voucher','ID'=>$ID);
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
}
