<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Customers extends CI_Controller {

function __construct() {
        parent::__construct();
         define('ActMenu','Customers');
		$ci =& get_instance();
		$ci->router->class;
		$ci->router->method;
    }
 
	public function Customer($ID=-1,$BUT='SAVE')
	{

		$data=array('F_Class'=>'Customers','F_Ctrl'=>'Customer','ID'=>$ID,'BUT'=>$BUT,'Logo'=>rand().rand().rand(),'UpiId'=>rand().rand().rand());
		if($ID!=-1)
		{
			$REC=$this->Myclass->Customer($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);

	}
	public function Customer_Val()
	{
		$this->load->model('Customers/Customer');
		$this->Customer->Customer_Val();
	}
    public function Customer_View()
	{
		$data=array('F_Class'=>'Customers','F_Ctrl'=>'Customer');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);

	}
	 public function Announcement()
	 {
		$data=array('F_Class'=>'Customers','F_Ctrl'=>'Announcement');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."",$data);
	 }

}
