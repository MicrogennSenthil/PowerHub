<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
class Login extends CI_Controller {

	public function index()
	{


	 
		$qry=" EXEC dbo.Pro_Login '".$_POST['username']."','".md5($_POST['password'])."'"; 
		$res=$this->db->query($qry);
		$data=json_encode($res->result());
	 
		$data=json_decode($data,true);
		if(count($data)== 0)
		{
		   $this->load->view('welcome_message');
		}
		else
		{
			 // print_r($data[0]); exit;
			$this->session->set_userdata('POS',$data[0]);
			$this->load->helper('url');			
		    redirect(scs_url, 'refresh');
           // $this->load->view('main',$data);
		}
		 
     }
    public function Hotel($LogKey)
	{
	 $qry=" EXEC dbo.Pro_Login_Dir '".$LogKey."','".UserId."'"; 	
		$res=$this->db->query($qry);
		$data=json_encode($res->result());
		$data=json_decode($data,true);
		$this->session->set_userdata('POS',$data[0]);
		$this->load->helper('url');			
		redirect(scs_url, 'refresh');
		
	}
	public function logout()
	{
		@session_start();
	    @session_destroy();
		$this->load->view('welcome_message');
	}
}
