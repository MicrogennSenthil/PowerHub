<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Help extends CI_Controller {

function __construct() {
        parent::__construct();
         define('ActMenu','Help');
		$ci =& get_instance();
		$ci->router->class;
		$ci->router->method;
    }
    public function ResetPassword($ID=-1,$BUT='UPDATE',$MOD=0)
	{
		
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'ResetPassword','ID'=>$ID,'BUT'=>$BUT,'MOD'=>$MOD);
		
        $REC=$this->Myclass->User(UserId);
 
		$data=array_merge($data,array('Active'=>$REC[0]['Active'],'UserId'=>$REC[0]['UserId'],'UserName'=>$REC[0]['UserName'],'UserGroup'=>$REC[0]['UserGroup'],'Password'=>'','EnableONOFFoperation'=>$REC[0]['EnableONOFFoperation']));
	
		$this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	public function ByPassonoff($ID=-1,$BUT='SAVE')
	{
		$data=array('F_Class'=>'Help','F_Ctrl'=>'ByPassonoff','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{
			$REC=$this->Myclass->RoomType($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
	}
	public function ByPassonoff_Val()
	{
		$this->load->model('Help/ByPassonoff');
		$this->ByPassonoff->ByPassonoff_Val();
	}
}
///User/1/UPDATE