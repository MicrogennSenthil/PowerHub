<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MsSql extends CI_Controller {

	public function index()
	{
		
		$bool=false;
		 
	 
		if($bool==false){
		$this->load->model($_REQUEST['Mname']);
		}
		switch($_REQUEST['Mname'])
		{
			
			case "Master/Block":
		    $this->Block->Block_exec();
			break;
			
			case "Master/Floor":
		    $this->Floor->Floor_exec();
			break; 
			
			case "Master/RoomType":
		    $this->RoomType->RoomType_exec();
			break;
			
			case "Master/Room":
		    $this->Room->Room_exec();
			break; 
			
			case "Master/Process":
		    $this->Process->Process_exec();
			break;
			case "Master/Control":
		    $this->Control->Control_exec();
			break;
			case "Welcome/Profile":
		    $this->Profile->Profile_exec();
			break;
			
			case "Customers/Customer":
		    $this->Customer->Customer_exec();
			break;
			case "Master/Device":
		    $this->Device->Device_exec();
			break;	
				
			case "Setting/Regestermn":
			$this->Regestermn->Regestermn_exec();
			break;
			case "Setting/ControlType":
		    $this->ControlType->ControlType_exec();
			break;
			case "Setting/Status":
		    $this->Status->Status_exec();
			break;
			case "Setting/User":
			$this->User->User_exec();
			break;
			case "Setting/UserGroup":
			$this->UserGroup->UserGroup_exec();
			break;
			case "Setting/ResetPassword":
			$this->ResetPassword->ResetPassword_exec();
			break;		
			case "Help/ByPassonoff":
			$this->ByPassonoff->ByPassonoff_exec();
			break;	
		}
		 
	}
	

	 
}
