<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Pdff extends CI_Controller {

function __construct() {
        parent::__construct();
         define('ActMenu','Account');
		$ci =& get_instance();
		$ci->router->class;
		$ci->router->method;
    }
 
	//###########################################
	public function index()
	{
         
        $this->load->view('pdfhtml',array('pdfhtml'=>$_POST['pdfhtml']));
    }
}