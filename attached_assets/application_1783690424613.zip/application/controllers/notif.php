<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

class notif extends CI_Controller
{

  function __construct()
  {
    parent::__construct();
    define('ActMenu', 'Account');
    $ci = &get_instance();
    $ci->router->class;
    $ci->router->method;
  }

  //###########################################
  public function index()
  {
    $res = $this->db->query('Notif')->row();
    echo ' <li>
                <!-- inner menu: contains the actual data -->
                 <ul class="menu">
                  <li>
                    <a href="#">
                      <i style="color:#059efc" class="fa fa-users text-lightblue"></i> ' . $res->NewCus . ' Total number of customers joined today
                    </a>
                  </li>
                  
                  <li>
                    <a href="#">
                      <i class="fa fa-users text-red"></i> ' . $res->TotCus . ' Total number of customers joined
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      <i class="fa fa-shopping-cart text-green"></i> ' . $res->NewPur . ' Total number of purchase made today
                    </a>
                  </li>
				         <li>
                    <a href="#">
                      <i class="fa fa-shopping-cart text-warning"></i> ' . $res->PTot . ' Total number of purchase  made
                    </a>
                  </li>

                  <li>
                  <a href="#">
                    <i class="fa fa-shopping-cart text-purble"></i> ' . $res->NewSal . ' Total number of sales made today
                  </a>
                </li>
               <li>
                  <a href="#">
                    <i class="fa fa-shopping-cart text-yellow"></i> ' . $res->Tot . ' Total number of sales  made
                  </a>
                </li>

                  <li>
                    <a href="' . scs_index . 'Setting/User/' . User_Id . '/UPDATE/1">
                      <i class="fa fa-user text-info"></i> You Can change Your  Password
                    </a>
                  </li>
                </ul>
              </li>';
  }
}
