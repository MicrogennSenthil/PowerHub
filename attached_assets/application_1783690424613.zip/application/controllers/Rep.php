<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Rep extends CI_Controller {

function __construct() {
        parent::__construct();
         define('ActMenu','Report');
		$ci =& get_instance();
		$ci->router->class;  
		$ci->router->method; 
    }

	 
    public function RoomProcessReport()
	{
		$this->load->view('Report/Rep/RoomProcessReport');
	}
	public function DeviceProcessReport()
	{
		$this->load->view('Report/Rep/DeviceProcessReport');
	}
	public function Controlstatus()
	{
		$this->load->view('Controlstatus.php');
	}
	public function PowerDet()
	{
		$this->load->view('Power_Det.php');
	}
	public function PowerUsageReport()
	{
	//	$this->load->view('Report/Rep/PowerUsageReport.php');
	$this->load->view('Report/Rep/RoomProcessReport');
	}
}
