<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Power extends CI_Controller {

function __construct() {
        parent::__construct();
        
		$ci =& get_instance();
		$ci->router->class;  
		$ci->router->method; 
    }
	public function poweronoffcontrol($Dev,$Ctrl,$st,$Slat)
	{
		if($Ctrl ==0)
		{
			$qry="UPDATE Mas_Control SET State=".$st." WHERE Device='".$Dev."' and  Slate='".$Slat."'";
			$this->db->query($qry);
			
			$qry="SELECT * FROM Mas_Control WHERE Device='".$Dev."' and Slate=1 order by Control ";
			$res=$this->db->query($qry);
			$val='';
			foreach($res->result() as $row)
			{
			$val=$row->State.$val;
			}
			
			$binary = $val;
			$hex = dechex(bindec($binary));
			if(strlen($hex)==1)
			{
			$Controlpush= "*0X0".$hex; 
			}
			else{
				$Controlpush= "*0X".$hex; 
			}
			
			$qry="SELECT * FROM Mas_Control WHERE Device='".$Dev."' and Slate=2 order by Control ";
			$res=$this->db->query($qry);
			$val='';
			foreach($res->result() as $row)
			{
			$val=$row->State.$val;
			}
			
			$binary = $val;
			$hex = dechex(bindec($binary));
			if(strlen($hex)==1)
			{
			$Controlpull= "$0X0".$hex; 
			}
			else{
				$Controlpull= "$0X".$hex; 
			}
			
			$qry="exec Exec_Powerpush  0,'".$Dev."','".$Controlpush."','".$Controlpull."','".$st."','0','1'";
			$this->db->query($qry);
		}
		else
		{
			$qry="SELECT * FROM Mas_Control where Device='".$Dev."' and Slate='".$Slat."' and Control='".$Ctrl."'";
			$Con=$this->db->query($qry);
			foreach($Con->result() as $CTRL)
			{
				$qry="UPDATE Mas_Control SET State=".$st." WHERE Control_Id=".$CTRL->Control_Id;
				$this->db->query($qry);

				$qry="SELECT * FROM Mas_Control WHERE Device='".$CTRL->Device."' and Slate=1 order by Control ";
				$res=$this->db->query($qry);
				$val='';
				foreach($res->result() as $row)
				{
				$val=$row->State.$val;
				}
				
				$binary = $val;
				$hex = dechex(bindec($binary));
				if(strlen($hex)==1)
				{
				$Controlpush= "*0X0".$hex; 
				}
				else{
					$Controlpush= "*0X".$hex; 
				}
				
				$qry="SELECT * FROM Mas_Control WHERE Device='".$CTRL->Device."' and Slate=2 order by Control ";
				$res=$this->db->query($qry);
				$val='';
				foreach($res->result() as $row)
				{
				$val=$row->State.$val;
				}
				
				$binary = $val;
				$hex = dechex(bindec($binary));
				if(strlen($hex)==1)
				{
				$Controlpull= "$0X0".$hex; 
				}
				else{
					$Controlpull= "$0X".$hex; 
				}
				
				$qry="exec Exec_Powerpush  0,'".$CTRL->Device."','".$Controlpush."','".$Controlpull."','".$st."','0','1'";
				$this->db->query($qry);
			}
		}
	}

	public function poweronoff($Id,$st,$Status_Id)
	{
		$Device="";
		$qry="SELECT * FROM Mas_Control WHERE Room_Id=".$Id;
		$Con=$this->db->query($qry);
		foreach($Con->result() as $CTRL)
		{
			
		
		$qry="UPDATE Mas_Control SET State=".$st." WHERE Room_Id=".$Id;
			$this->db->query($qry);
		$qry =" UPDATE Mas_Room SET Status_Id=".$Status_Id.",State=".$st." WHERE Room_Id=".$Id;
		 
		$this->db->query($qry);
		
		$qry="SELECT * FROM Mas_Control WHERE Device='".$CTRL->Device."' and Slate=1 order by Control ";
		$res=$this->db->query($qry);
		$val='';
		foreach($res->result() as $row)
		{
           $val=$row->State.$val;
		}
		
		$binary = $val;
		$hex = dechex(bindec($binary));
		if(strlen($hex)==1)
		{
		   $Controlpush= "*0X0".$hex; 
		}
		else{
			$Controlpush= "*0X".$hex; 
		}
		
		$qry="SELECT * FROM Mas_Control WHERE Device='".$CTRL->Device."' and Slate=2 order by Control ";
		$res=$this->db->query($qry);
		$val='';
		foreach($res->result() as $row)
		{
           $val=$row->State.$val;
		}
		
		$binary = $val;
		$hex = dechex(bindec($binary));
		if(strlen($hex)==1)
		{
		   $Controlpull= "$0X0".$hex; 
		}
		else{
			$Controlpull= "$0X".$hex; 
		}
		
		  $qry="exec Exec_Powerpush ".$CTRL->Room_Id.", '".$CTRL->Device."','".$Controlpush."','".$Controlpull."','".$st."','".$Status_Id."','1'";
		 $this->db->query($qry);
		}
	}
	public function apipush($UID='',$Device='',$Controlpush='',$Controlpull='',$Status='',$State='')
	{
		 $qry="exec Exec_Powerpush '".$Device."','".$Controlpush."','".$Controlpull."','".$Status."','".$State."','".$UID."'";
		 $this->db->query($qry);
		echo $Device.'/'.$Controlpush.'/'.$Controlpull.'/'.$Status.'/'.$State;
	}
	public function apipull($UID='',$Device='',$Controlpush='',$Controlpull='',$Status='',$State='')
	{
		 $qry="exec Exec_Powerpull '".$Device."','".$Controlpush."','".$Controlpull."','".$Status."','".$State."','".$UID."'";
		 $this->db->query($qry);
		echo $Device.'/'.$Controlpush.'/'.$Controlpull.'/'.$Status.'/'.$State;
	}
	public function apiupdate($PowerLog_Id='',$FLAG='')
	{
		if(is_numeric($PowerLog_Id)==1 && is_numeric($FLAG)==1 )
		{
			 $qry="exec Api_Update  ".$PowerLog_Id.",".$FLAG."";
			 $this->db->query($qry);
			echo 'Successfully Update';
		}
		else
		{
			echo 'Invalid Value';
		}
	}
	public function Rep()
	{
		$qry=" SELECT top 1 * FROM PowerLog where isnull(flag,5)=5";
       $res=$this->db->query($qry);
	   if($res->num_rows()>0)
	   {
		   $res=$res->row();
		   echo $res->Device.'/'.$res->Controlpush.'/'.$res->Controlpull.'/'.$res->Status.'/'.$res->PowerLog_Id;
	   }
	   else
	   {
		   echo 'NORECORDS';
	   }
	  
	}
	public function RepAll()
	{
		$qry=" SELECT   * FROM PowerLog   ORDER BY PowerLog_Id desc";
       $res=$this->db->query($qry);
		echo  '<style> table {
  border-collapse: collapse;
}

td, th {
  border: 1px solid #999;
  padding: 0.5rem;
  text-align: left;
}</style> <table width="100%" border="0" cellspacing="0" cellpadding="0"><tr>
<td><strong>ID</strong></td>
<td><strong>Device</strong></td>
<td><strong>ControlPush</strong></td>
<td><strong>ControlPull</strong></td>
<td><strong>Status</strong></td><td><strong>State</strong></td> <td width="200" ><strong>Date</strong></td> </tr>';
	   foreach($res->result() as $row)
	   {
	        echo '<tr>';
			echo '<td>'.$row->PowerLog_Id.'</td>';
			echo '<td>'.$row->Device.'</td>';
			echo '<td>'.$row->Controlpush.'</td>';
			echo '<td>'.$row->Controlpull.'</td>';
			echo '<td>'.$row->Status.'</td>';
			echo '<td>'.$row->State.'</td>';
			echo '<td>'.$row->Rdate.'</td>';
			
			echo '</tr>';
	   }
	   echo '</table>';
	}
	 
}
