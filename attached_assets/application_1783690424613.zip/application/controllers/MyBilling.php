<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class MyBilling extends CI_Controller {

function __construct() {
        parent::__construct();
         define('ActMenu','Customers');
		$ci =& get_instance();
		$ci->router->class;
		$ci->router->method;
    }
  
	 public function Summary()
	 {
		$data=array('F_Class'=>'MyBilling','F_Ctrl'=>'Summary');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."",$data);
	 }
     public function Transactions()
	 {
		$data=array('F_Class'=>'MyBilling','F_Ctrl'=>'Transactions');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."",$data);
	 }
	public function PendingPayment()
	 {
		$data=array('F_Class'=>'MyBilling','F_Ctrl'=>'PendingPayment');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."",$data);
	 }
}
