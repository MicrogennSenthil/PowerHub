<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

function __construct() {
        parent::__construct();
         define('ActMenu','Dashboard');
		$ci =& get_instance();
		$ci->router->class;  
		$ci->router->method; 
    }

	public function main()
	{
		 $this->load->view('main');
	}
	public function index()
	{
		 
       $data=array('F_Class'=>'Welcome','F_Ctrl'=>'Dashboard');
		 
		if(@$this->session->userdata['POS']['Hotel_Id'])
		   {					
			   if(Type==0)
			   	{
			  		 $this->load->view('Power');
				}
			   else{
				   $this->load->view('Hotel');
			   }
		   }
		   else
		   {
		      $this->load->view('welcome_message');
		   }
	}
	public function Profile($PTY=0)
	{
		$qry="SELECT * FROM Mas_Hotel where Hotel_Id=".Hotel_Id;
		$res=$this->db->query($qry);
		$Res= json_encode($res->result());
	    $Res=json_decode($Res,true);
		
		$data=array_merge(array('F_Class'=>'Welcome','F_Ctrl'=>'Profile','PTY'=>$PTY),$Res[0]);
		$this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."",$data);
	}
	public function Profile_Val()
	{
	   $this->load->model('Master/Profile');
	   $this->Profile->Profile_Val();	
	}
	public function BellSal()
	{
		$qry="exec Bell_Sales";
			$res=$this->db->query($qry);
			foreach($res->result() as $row)
			{
		         echo '<li><a href="#" style="font-size:11px">
                       <i class="fa fa-user text-red"></i>Customer : '.$row->CustomerName.' <br> Amount : '.$row->TotalAmount.'
                       </a>
                       </li>';
				  
			}
	}
}
