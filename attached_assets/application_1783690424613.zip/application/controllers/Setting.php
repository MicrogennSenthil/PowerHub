<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Setting extends CI_Controller {

function __construct() {
        parent::__construct();
         define('ActMenu','Setting');
		$ci =& get_instance();
		$ci->router->class;  
		$ci->router->method; 
    }
	public function ManageProducts()
	{
		$this->load->view('Setting/ManageProducts',array('F_Class'=>'Setting','F_Ctrl'=>'ManageProducts'));
	}
	public function Regestermn($ID=-1,$BUT='SAVE')
	{

		$data=array('F_Class'=>'Setting','F_Ctrl'=>'Regestermn','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{
			$REC=$this->Myclass->Regester($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);

	}
	public function Regestermn_Val()
	{
		$this->load->model('Setting/Regestermn');
		$this->Regestermn->Regestermn_Val();
	}
	 public function Regestermn_View()
	{
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'Regestermn');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);

	}
	public function Mobileda()
	{
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'Mobileda');
		$this->load->view('Setting/Mobileda',$data);
	}
	public function ControlType($ID=-1,$BUT='SAVE')
	{

		$data=array('F_Class'=>'Setting','F_Ctrl'=>'ControlType','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{
			$REC=$this->Myclass->ControlType($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);

	}
	public function ControlType_Val()
	{
		$this->load->model('Setting/ControlType');
		$this->ControlType->ControlType_Val();
	}
    public function ControlType_View()
	{
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'ControlType');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);

	}	
//##############################################################
public function Status($ID=-1,$BUT='SAVE')
	{

		$data=array('F_Class'=>'Setting','F_Ctrl'=>'Status','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{
			$REC=$this->Myclass->Status($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);

	}
	public function Status_Val()
	{
		$this->load->model('Setting/Status');
		$this->Status->Status_Val();
	}
    public function Status_View()
	{
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'Status');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);

	}	
    public function Reset()
	{
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'Reset');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."",$data);
	}


public function User($ID=-1,$BUT='SAVE',$MOD=0)
	{
		
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'User','ID'=>$ID,'BUT'=>$BUT,'MOD'=>$MOD);
		if($ID!=-1)
		{ 
			$REC=$this->Myclass->User($ID);
 
			$data=array_merge($data,array('Active'=>$REC[0]['Active'],'UserId'=>$REC[0]['UserId'],'UserName'=>$REC[0]['UserName'],'UserGroup'=>$REC[0]['UserGroup'],'EnableONOFFoperation'=>$REC[0]['EnableONOFFoperation'],'Password'=>md5($REC[0]['Password'])));
		}
		$this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	public function User_Val()
	{ 
		$this->load->model('Setting/User');
		$this->User->User_Val();
	}
    public function User_View()
	{
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'User');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);
		
	}
	public function UserGroup($ID=-1,$BUT='SAVE',$MOD=0)
	{
		
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'UserGroup','ID'=>$ID,'BUT'=>$BUT,'MOD'=>$MOD);
		if($ID!=-1)
		{ 
			$REC=$this->Myclass->UserGroup($ID);
 
			$data=array_merge($data,array('Active'=>'1','Group_Id'=>$REC[0]['Group_Id'],'UserGroup'=>$REC[0]['UserGroup']));
		}
		$this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	public function UserGroup_Val()
	{ 
		$this->load->model('Setting/UserGroup');
		$this->UserGroup->UserGroup_Val();
	}
	public function UserGroup_View()
	{
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'UserGroup');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);
		
	}
	public function UserRights()
	{
		 $data=array('F_Class'=>'Setting','F_Ctrl'=>'UserRights');
		 $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
	}
	public function getuser()
	{
		$this->load->view('Setting/GetUser');
	}
	public function UpdateUser()
	{
		   $qry="Update_UserR '".$_POST['val']."',".$_POST['MID'];
		 $this->db->query($qry);
		echo 'Successfully Update !!!';
	}
    //###########################################
	public function sms($ID=-1,$BUT='SAVE')
	{
		
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'sms','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{ 
			$REC=$this->Myclass->SMSAPI($ID);
			$data=array_merge($data,$REC[0]);
		}
		 
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	public function sms_Val()
	{ 
		$this->load->model('Setting/sms');
		$this->sms->sms_Val();
	}
    public function sms_View()
	{
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'sms');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);
		
	}
    //###########################################
	public function emails($ID=-1,$BUT='SAVE')
	{
		
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'emails','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{ 
			$REC=$this->Myclass->Emails($ID);
			$data=array_merge($data,$REC[0]);
		}
		 
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	public function emails_Val()
	{ 
		$this->load->model('Setting/emails');
		$this->emails->emails_Val();
	}
    public function emails_View()
	{
		$data=array('F_Class'=>'Setting','F_Ctrl'=>'emails');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);
		
	}
	public function RateUpdate()
	{
		$cou=count($_POST['Price_Id']);
		for($i=0;$i<$cou;$i++)
		{
			$qry =" UPDATE dbo.Mas_Price SET Rate =".$_POST['Rate'][$i].",	Renew = ".$_POST['Renew'][$i]." WHERE Price_Id = ".$_POST['Price_Id'][$i]." ";
			$this->db->query($qry);
		}
		echo 'Successfully Update !!!';
	}
	
	//*********************************************************************\\
	public function Edit()
	{
		$this->load->view('Setting/Edit/'.$_REQUEST['link']);
	}
	public function ResetPassword_Val()
	{ 
		$this->load->model('Setting/ResetPassword');
		$this->ResetPassword->ResetPassword_Val();
	}
	public function ResetPassword()
	{
		$this->load->view('Power');
	}

}
