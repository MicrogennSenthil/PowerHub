<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Api extends CI_Controller {

function __construct() {
        parent::__construct();
         define('ActMenu','Api');
		$ci =& get_instance();
		$ci->router->class;  
		$ci->router->method; 
    }

	function Device($id)
	{
		$this->load->view('MControlstatus.php',array('Hotel_Id'=>$id));
	}
	function Status($id)
	{
		$this->load->view('MDevicestatus',array('HotelId'=>$id));
	}
	function Proceed()
	{
		$qry="exec Login '".$_POST['Mobile']."','".md5($_POST['Password'])."'";  
		$res=$this->db->query($qry);
		 
		$Res= json_encode($res->row());
		 
		return print_r($Res);
	}
	function HFloor()
	{
		$qry="SELECT * FROM Mas_Floor";
		$res=$this->db->query($qry);
		$chk='checked="checked"';
		foreach($res->result() as $row)
		{
			echo ' <label onclick="Hapi.Hroom('.$row->Floor_Id.')" 
			       class="tabbar__item tabbar--top-border__item">
				   <input type="radio" name="top-tabbar-b" '.$chk.' >
			       <button  class="tabbar__button tabbar--top-border__button">
			       <img src="icon/Floor.png" >  <b>'.$row->Floor.'</b>
			       </button> </label>';
			$chk='';
		}
	}
	 
	function Hroom($HotelId)
	{
		$qry="SELECT * FROM Mas_Floor";
		$res=$this->db->query($qry);
		 
		foreach($res->result() as $Flo)
		{
			$qry="SELECT * FROM Mas_room where Hotel_Id=".$HotelId." and Floor_Id=".$Flo->Floor_Id;
			$res=$this->db->query($qry);
			echo  ' <img width="16" hight="16" src="icon/Floor.png" > <b>'.$Flo->Floor.'</b><br>';
			echo '<ons-row>';
			foreach($res->result() as $row)
			{
				echo '<ons-col on  onclick="showTemplateDialog('.$row->Room_Id.','.$row->Floor_Id.','.$row->State.')" class="img-thumbnail txt_center"   >
					  <img width="64" height="64" src="icon/'.$row->Status_Id.'.png" />
					  <br><b>'.$row->RoomNo.'</b></ons-col>';
			}
			echo '</ons-row>';
		}
	}
	function HRoomType($HotelId)
	{
		$qry="SELECT * FROM Mas_RoomType";
		$res=$this->db->query($qry);
		 
		foreach($res->result() as $Flo)
		{
			$qry="SELECT * FROM Mas_room where Hotel_Id=".$HotelId." and  RoomType_Id=".$Flo->RoomType_Id;
			$res=$this->db->query($qry);
			echo  ' <img width="16" hight="16" src="icon/bed.png" > <b>'.$Flo->RoomType.'</b><br>';
			echo '<ons-row>';
			foreach($res->result() as $row)
			{
				echo '<ons-col on  onclick="showTemplateDialog('.$row->Room_Id.','.$row->Floor_Id.','.$row->State.')" class="img-thumbnail txt_center"   >
					  <img width="64" height="64" src="icon/'.$row->Status_Id.'.png" />
					  <br><b>'.$row->RoomNo.'</b></ons-col>';
			}
			echo '</ons-row>';
		}
	}
	public function PowerApi($Id,$st,$div,$Status_Id,$Ctrl)
	{
		$qry="exec Get_RoomId '".urldecode($Id)."'";
		$res=$this->db->query($qry);
		$res=$res->row();
		$Room_Id=$res->Room_Id;
		$this->poweronoff($Room_Id,$st,$div,$Status_Id,$Ctrl);
		echo 'Succss';
	}
	public function PowerRest()
	{
		$qry="exec Set_Reset  ".Hotel_Id;
		$res=$this->db->query($qry);
		
		$qry="SELECT * FROM Mas_Device WHERE Hotel_Id=".Hotel_Id;
		$Device=$this->db->query($qry);
		foreach($Device->result() as $Drow)
		{
					$qry="SELECT * FROM Mas_Control WHERE Device='".$Drow->Device."' and Slate=1 order by Control ";
				$res=$this->db->query($qry);
				$val='';
				foreach($res->result() as $row)
				{
				   $val=$row->State.$val;
				}
				
				$binary = $val;
				$hex = dechex(bindec($binary));
				if(strlen($hex)==1)
				{
				   $Controlpush= "*0X0".$hex; 
				}
				else{
					$Controlpush= "*0X".$hex; 
				}
				
				$qry="SELECT * FROM Mas_Control WHERE Device='".$Drow->Device."' and Slate=2 order by Control ";
				$res=$this->db->query($qry);
				$val='';
				foreach($res->result() as $row)
				{
				   $val=$row->State.$val;
				}
				
				$binary = $val;
				$hex = dechex(bindec($binary));
				if(strlen($hex)==1)
				{
				   $Controlpull= "$0X0".$hex; 
				}
				else{
					$Controlpull= "$0X".$hex; 
				}
				
				 $qry="exec Exec_Powerpush 0, '".$Drow->Device."','".$Controlpush."','".$Controlpull."','".$Status_Id."',0,8,'1'";
		 $this->db->query($qry);
		}
	}
	public function poweronoff($Id,$st,$Device,$Status_Id,$Ctrl)
	{
		$Device="";
		$qry="SELECT * FROM Mas_Control WHERE Room_Id=".$Id." and ControlType_Id=".$Ctrl;
		$Con=$this->db->query($qry);
		foreach($Con->result() as $CTRL)
		{
			
		
		$qry="UPDATE Mas_Control SET State=".$st." WHERE Room_Id=".$Id." and ControlType_Id=".$Ctrl;
		$this->db->query($qry);
		$qry =" UPDATE Mas_Room SET Status_Id=".$Status_Id.",State=".$st." WHERE Room_Id=".$Id;
		 
		$this->db->query($qry);
		
		$qry="SELECT * FROM Mas_Control WHERE Device='".$CTRL->Device."' and Slate=1 order by Control";
		$res=$this->db->query($qry);
		$val='';
		foreach($res->result() as $row)
		{
           $val=$row->State.$val;
		}
		
		$binary = $val;
		$hex = dechex(bindec($binary));
		if(strlen($hex)==1)
		{
		   $Controlpush= "*0X0".$hex; 
		}
		else{
			$Controlpush= "*0X".$hex; 
		}
		
		$qry="SELECT * FROM Mas_Control WHERE Device='".$CTRL->Device."' and Slate=2 order by Control";
		$res=$this->db->query($qry);
		$val='';
		foreach($res->result() as $row)
		{
           $val=$row->State.$val;
		}
		
		$binary = $val;
		$hex = dechex(bindec($binary));
		if(strlen($hex)==1)
		{
		   $Controlpull= "$0X0".$hex; 
		}
		else{
			$Controlpull= "$0X".$hex; 
		}
		
		 $qry="exec Exec_Powerpush ".$CTRL->Room_Id.", '".$CTRL->Device."','".$Controlpush."','".$Controlpull."','".$st."','".$Status_Id."','".$Ctrl."','1'";
		 $this->db->query($qry);
		}		
	}
		//($Id,$st,$div,$Status_Id,$Ctrl)
	public function PowerDeviceApi($div)
	{
		$qry="select Top 1 * from powerlog where Device='".$div."' and isnull(update_Status,0)=0 order by PowerLog_Id asc";
		$res=$this->db->query($qry);
		foreach($res->result() as $row)
		{
			$rand=str_pad($row->RandomNo, 4, '0', STR_PAD_LEFT);			
		echo 	$row->Device.$row->Controlpush.$row->Controlpull.'#'.$rand.'+';			
			if($row->Status_Id !=2)
			{
			$up="Update powerlog set Recevied=convert(varchar(25),getdate(),120) where Device='".$div."' and PowerLog_Id='".$row->PowerLog_Id."' ";
			$res=$this->db->query($up);
			}
			else
			{
				$up="Update powerlog set Ofdate=convert(varchar(25),getdate(),120) where Device='".$div."' and PowerLog_Id='".$row->PowerLog_Id."' ";
				$res=$this->db->query($up);
			}
		}
		$ins="update Mas_Device set StUpdate=convert(varchar(25),getdate(),120),Dev_status=1 where Device='".$div."' ";
		$res=$this->db->query($ins);
		
		
	}
	public function PowerDeviceStatusApi($div,$Rand)
	{
				
		$qry="Update powerlog set Update_Status=1,FLAG=1,Closed=convert(varchar(25),getdate(),120)  where Device='".$div."' and RandomNo='".$Rand."' and isnull(Update_Status,0)=0 ";
		$res=$this->db->query($qry);
		
		$qry1="select Top 1 Room_Id,* from powerlog where Device='".$div."' and isnull(Update_Status,0)=1 and RandomNo='".$Rand."' and Status_Id=2 order by PowerLog_Id desc";
		$res1=$this->db->query($qry1);
		$no=$res1->num_rows();
		if($no !=0)
		{
			foreach($res1->result() as $row1)
			{
				$qry2="select  Top 1 * from powerlog where Device='".$div."' and Room_id='".$row1->Room_Id."' and isnull(Ofdate,'')='' and Status_Id<>2  and isnull(update_Status,0)=1 order by PowerLog_Id desc";
				$res2=$this->db->query($qry2);
				foreach($res2->result() as $row2)
				{
					$upd="update powerlog set Recevied='".$row2->Recevied."'  where PowerLog_Id='".$row1->PowerLog_Id."'";
					$res=$this->db->query($upd);
					
					$upd1="update powerlog set Ofdate=convert(varchar(25),getdate(),120)  where PowerLog_Id='".$row2->PowerLog_Id."'";
					$res1=$this->db->query($upd1);
				}	
						
			}
		} 
		
		echo 'Succss';
	}
}
