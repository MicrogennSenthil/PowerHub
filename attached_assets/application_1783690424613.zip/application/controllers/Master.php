<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Master extends CI_Controller {

function __construct() {
        parent::__construct();
         define('ActMenu','Master');
		$ci =& get_instance();
		$ci->router->class;
		$ci->router->method;
    }
//###########################################
	public function Block($ID=-1,$BUT='SAVE')
	{

		$data=array('F_Class'=>'Master','F_Ctrl'=>'Block','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{
			$REC=$this->Myclass->Block($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);

	}
	public function Block_Val()
	{
		$this->load->model('Master/Block');
		$this->Block->Block_Val();
	}
    public function Block_View()
	{
		$data=array('F_Class'=>'Master','F_Ctrl'=>'Block');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);

	}
	 //###########################################
	public function Device($ID=-1,$BUT='SAVE')
	{

		$data=array('F_Class'=>'Master','F_Ctrl'=>'Device','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{
			$REC=$this->Myclass->Device($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);

	}
	public function Device_Val()
	{
		$this->load->model('Master/Device');
		$this->Device->Device_Val();
	}
    public function Device_View()
	{
		$data=array('F_Class'=>'Master','F_Ctrl'=>'Device');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);

	}
//###########################################
	public function Floor($ID=-1,$BUT='SAVE')
	{

		$data=array('F_Class'=>'Master','F_Ctrl'=>'Floor','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{
			$REC=$this->Myclass->Floor($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);

	}
	public function Floor_Val()
	{
		$this->load->model('Master/Floor');
		$this->Floor->Floor_Val();
	}
    public function Floor_View()
	{
		$data=array('F_Class'=>'Master','F_Ctrl'=>'Floor');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);

	}
//###########################################
	public function Room($ID=-1,$BUT='SAVE')
	{

		$data=array('F_Class'=>'Master','F_Ctrl'=>'Room','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{
			$REC=$this->Myclass->Room($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);

	}
	public function Room_Val()
	{
		$this->load->model('Master/Room');
		$this->Room->Room_Val();
	}
    public function Room_View()
	{
		$data=array('F_Class'=>'Master','F_Ctrl'=>'Room');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);

	}	 	
	//###########################################
	public function RoomType($ID=-1,$BUT='SAVE')
	{

		$data=array('F_Class'=>'Master','F_Ctrl'=>'RoomType','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{
			$REC=$this->Myclass->RoomType($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);

	}
	public function RoomType_Val()
	{
		$this->load->model('Master/RoomType');
		$this->RoomType->RoomType_Val();
	}
    public function RoomType_View()
	{
		$data=array('F_Class'=>'Master','F_Ctrl'=>'RoomType');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);

	}
	//###########################################
	public function Process($ID=-1,$BUT='SAVE')
	{

		$data=array('F_Class'=>'Master','F_Ctrl'=>'Process','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{
			$REC=$this->Myclass->ProcessAp($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);

	}
	public function Process_Val()
	{
		$this->load->model('Master/Process');
		$this->Process->Process_Val();
	}
    public function Process_View()
	{
		$data=array('F_Class'=>'Master','F_Ctrl'=>'Process');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);

	}
	//###########################################
	public function Customer($ID=-1,$BUT='SAVE')
	{

		$data=array('F_Class'=>'Master','F_Ctrl'=>'Customer','ID'=>$ID,'BUT'=>$BUT,'Logo'=>rand().rand().rand(),'UpiId'=>rand().rand().rand());
		if($ID!=-1)
		{
			$REC=$this->Myclass->Customer($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);

	}
	public function Customer_Val()
	{
		$this->load->model('Master/Customer');
		$this->Customer->Customer_Val();
	}
    public function Customer_View()
	{
		$data=array('F_Class'=>'Master','F_Ctrl'=>'Customer');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);

	}
	//###########################################
	public function ControlType($ID=-1,$BUT='SAVE')
	{

		$data=array('F_Class'=>'Master','F_Ctrl'=>'ControlType','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{
			$REC=$this->Myclass->ControlType($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);

	}
	public function ControlType_Val()
	{
		$this->load->model('Master/ControlType');
		$this->ControlType->ControlType_Val();
	}
    public function ControlType_View()
	{
		$data=array('F_Class'=>'Master','F_Ctrl'=>'ControlType');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);

	}		
	//###########################################
	public function Control($ID=-1,$BUT='SAVE')
	{

		$data=array('F_Class'=>'Master','F_Ctrl'=>'Control','ID'=>$ID,'BUT'=>$BUT);
		if($ID!=-1)
		{
			$REC=$this->Myclass->Control($ID);
			$data=array_merge($data,$REC[0]);
		}

	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);

	}
	public function Control_Val()
	{
		$this->load->model('Master/Control');
		$this->Control->Control_Val();
	}
    public function Control_View()
	{
		$data=array('F_Class'=>'Master','F_Ctrl'=>'Control');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl']."_View",$data);

	}	
 public function UpdateCtrl($ID)
 {
	 $qry="exec Up_Control ".$_POST['Control'.$ID].",".$_POST['Room_Id'.$ID].",".$_POST['Slate'.$ID].",".$_POST['ControlType_Id'.$ID].",".$ID;
		  $res = $this->db->query($qry);
		  foreach($res->result_array() as $row){
			if($row['mgs']=='success'){
				echo '<lable style="color:grean" >Successfully !!!</lable>';
			}else{
				echo '<lable style="color:red" >Control Already Exists !!!</lable>';
			}
		  }
 }	 
	//*********************************************************************\\
	public function Edit()
	{
		$this->load->view('Master/Edit/'.$_REQUEST['link']);
	}

	public function username_check($str)
        {
                if ($str == '0' && $_POST['Ctype']==1)
                {
                        $this->form_validation->set_message('username_check', 'The {field}  field is required');
                        return FALSE;
                }
                else
                {
                        return TRUE;
                }
        }
		public function NOI_check($str)
        {
                if ($str == '0')
                {
                        $this->form_validation->set_message('NOI_check', 'The No of Installments field is required');
                        return FALSE;
                }
                else
                {
                        return TRUE;
                }
        }
		public function NOM_check($str)
        {
                if ($str == '0')
                {
                        $this->form_validation->set_message('NOM_check', 'The No of Members  field is required');
                        return FALSE;
                }
                else
                {
                        return TRUE;
                }
        }

}
