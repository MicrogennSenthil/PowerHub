<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Report extends CI_Controller {

function __construct() {
        parent::__construct();
         define('ActMenu','Report');
		$ci =& get_instance();
		$ci->router->class;  
		$ci->router->method; 
    }

	 
    public function Control()
	{
		$data=array('F_Class'=>'Report','F_Ctrl'=>'Control');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
		
	}
	public function RoomProcessReport()
	{
		$data=array('F_Class'=>'Report','F_Ctrl'=>'RoomProcessReport');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);		
	} 
	public function PowerUsageReport()
	{
		$data=array('F_Class'=>'Report','F_Ctrl'=>'PowerUsageReport');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
	}
	public function DeviceProcessReport()
	{
		$data=array('F_Class'=>'Report','F_Ctrl'=>'DeviceProcessReport');
	    $this->load->view($data['F_Class'].'/'.$data['F_Ctrl'],$data);
	}
}
