<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
//$this->pweb->Cheader('Master','Room');
$this->pfrm->FrmHead2('Help / ByPass On/Off',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
      <input type="hidden" name="idv" value="<?php echo @$Room_Id; ?>" >
      <table class="FrmTable T-4" >
        <tr>
          <td align="right" class="F_val">Device</td>
          <td align="left"><select type="text" id="Device_Id" name="Device_Id" class="scs-ctrl" style="width:100%">
              <option value="" > -- Select Device -- </option>
              <?php
				  $Res=$this->Myclass->Device();
				  $count=1;
				   foreach($Res as $row)
					{
						echo '<option value="'.$row['Device'].'">'.$row['Device'].'</option>';
					}
		  	   ?>
            </select>
            <div class="Device_Id" ></div></td>
        </tr>
         <tr>
          <td align="right" class="F_val">Process</td>
          <td align="left"><select type="text" id="Process" name="Process" class="scs-ctrl" style="width:100%">
              <option value="0">ON</option>
						  <option value="1">OFF</option>			
            </select>
            <div class="Process" ></div></td>
          </tr>          
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
