<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<link href="https://fonts.googleapis.com/css?family=Roboto:300,400&amp;display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?php echo scs_url; ?>login/fonts/icomoon/style.css">
<link rel="stylesheet" href="<?php echo scs_url; ?>login/css/owl.carousel.min.css">
<link rel="stylesheet" href="<?php echo scs_url; ?>login/css/bootstrap.min.css">
<link rel="stylesheet" href="<?php echo scs_url; ?>login/css/style.css">
<title>Mpower Customer Login V1.1</title>
</head>
<body>
<div class="content">
  <div class="container">
    <div class="row">
      <div class="col-md-6"> <img src="<?php echo scs_url; ?>login/images/undraw_remotely_2j6y.svg" alt="Image" class="img-fluid"> </div>
      <div class="col-md-6 contents">
        <div class="row justify-content-center">
          <div class="col-md-8">
            <div class="mb-4">
              <h3>Sign In</h3>
              <p class="mb-4">Customer Login</p>
            </div>
            <form  action="<?php echo scs_index ?>login" method="post">
              <div class="form-group first">
                <label for="username">Email</label>
                <input type="text" class="form-control" id="username" name="username" required>
              </div>
              <div class="form-group last mb-4">
                <label for="password">Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
              </div>
              <div class="d-flex mb-5 align-items-center">
                <label class="control control--checkbox mb-0">
                <span class="caption">Remember me</span>
                <input type="checkbox" checked="checked" />
                <div class="control__indicator"></div>
                </label>
                <span class="ml-auto"><a href="#" class="forgot-pass">Forgot Password</a></span> </div>
              <input type="submit" value="Log In" class="btn btn-block btn-primary">
             
            </form>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<script src="<?php echo scs_url; ?>login/js/jquery-3.3.1.min.js"></script> 
<script src="<?php echo scs_url; ?>login/js/popper.min.js"></script> 
<script src="<?php echo scs_url; ?>login/js/bootstrap.min.js"></script> 
<script src="<?php echo scs_url; ?>login/js/main.js"></script>
</body>
</html>