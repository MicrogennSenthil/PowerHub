<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();

$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Home','Hotel');
$this->pfrm->FrmHeadD('Home','','');

?>
 
<section class="content" style="background-color:#F3F3F3">
   <div class="table-responsive">
      <table class="table table-bordered table-hover table-striped mydatatable"  id="example1">
        <thead  >
          <tr>
            <th>Sno</th>
            <th>Customer</th>
            <th>City</th>
            <th>Phone</th>
            <th>Create</th>
            <th>Expiry</th>
            <th style="width:260px !important" align="center" >
            <div align="center">Action</div></th>
          </tr>
        </thead>
        <tbody>
          <?php 
			$Res=$this->Myclass->Customer();
			$count=1;
			 
		 foreach($Res as $row)
			{ 
      echo '<tr class="odd gradeX">
            <td>'.$count.' </td>
            <td>'.$row['Hotel'].'</td>
					  <td>'.$row['City'].'</td>
					  <td>'.$row['Phone'].'</td>
					  <td>'.$row['CD'].'</td>
					  <td>'.$row['Exd'].'</td>						
            <td align="center" >
					  <a class="btn btn-warning btn-xs" href="'.scs_index."Customers/Customer/".$row['Hotel_Id'].'/UPDATE"   >
					  <i class="fa fa-edit"></i> Managed</a> | 
					   <a class="btn btn-success btn-xs" href="'.scs_index.'/Login/Hotel/'.$row['LogKey'].'"   >
					  <i class="fa fa-hand-o-right"></i> Go To Login</a>					  
					  </td>                     
          </tr>';                           
				 $count++;
			}
			 ?>
        </tbody>
      </table>
   
</div>
</section>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs(@$F_Ctrl);
?>
 