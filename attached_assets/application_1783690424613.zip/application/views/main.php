<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();

$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Home','Control Status');
$this->pfrm->FrmHeadD('Master','','');

?>

<section class="content" style="background-color:#F3F3F3">
 <div class="row RepDet" >
 <?php include('Controlstatus.php'); ?>
	</div>
</section>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs(@$F_Ctrl);
?>
 
<script>
	var myVar = setInterval(Power_,32000);
function Power_()
	{		
		$.ajax({
		type:"POST",
		url:"<?php echo scs_index; ?>Rep/Controlstatus",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.RepDet').html(html);
		}
			
	  })
		
	}
	function On_Off(Dev,Ctrl,onoff,Slat)
	{
		//alert(Dev);alert(onoff);alert();
		alert((Ctrl) +'-'+ (Slat));
		$.ajax({
		type:"POST",
		url:"<?php echo scs_index; ?>Power/poweronoffcontrol/"+Dev+"/"+Ctrl+"/"+onoff+"/"+Slat,
		success: function(data)
		{
			//$('.Mbutclose').click();
			//	window.location.reload();
				alert("poweronoffcontrol");
	    },
		error: function(jqXHR,exception)
			{
			
			}		
		});
		
	}
</script>