<fieldset style="background-color:#FFFFFF ; "  class="Mdiv FloorW MC" >
    <legend>Floor</legend>
    <?php 
			$Res=$this->Myclass->Floor();
			$count=1;
			date_default_timezone_set('Asia/Kolkata');

foreach ($Res as $row) {
    // Check if 'Floor' and 'Floor_Id' exist in the current row
    if (isset($row['Floor'], $row['Floor_Id'])) {
        echo '<h5 class="card-title"><img width="16" height="16" src="' . scs_url . 'power/icon/Floor.png" /> ' . htmlspecialchars($row['Floor']) . '</h5>';

        // Prepare the SQL query securely using query bindings
		$qry="
		  select *,
	 isnull( (SELECT TOP 1 PowerLog_Id FROM PowerLog WHERE Room_Id=b.Room_Id AND isnull(FLAG,-5)=-5 ),0) A from Mas_Room b 
 where Hotel_Id=".Hotel_Id." and  Floor_Id=".$row['Floor_Id']." order by roomno";

      
				$rom = $this->db->query($qry, [Hotel_Id, $row['Floor_Id']]);
				
				if ($rom) {  // Check if query execution is successful
					foreach ($rom->result() as $RM) {
						if (isset($RM->Room_Id, $RM->State, $RM->RoomNo, $RM->Status_Id)) { // Check for essential properties
							if ($RM->A == 0) {
								echo '<div align="center" onClick="showTemplateDialog(' . htmlspecialchars($RM->Room_Id) . ',' . htmlspecialchars($RM->State) . ')" class="img-thumbnail txt_center RoomHover">
								<img width="64" height="64" src="' . scs_url . 'power/icon/' . htmlspecialchars($RM->Status_Id) . '.png" /><br>
								<b>' . htmlspecialchars($RM->RoomNo) . '</b></div>';
							} else {
								echo '<div align="center" class="img-thumbnail txt_center RoomHover">
								<img width="64" height="64" src="' . scs_url . 'power/icon/e.gif" /><br>
								<b>' . htmlspecialchars($RM->RoomNo) . '</b></div>';
							}
						} else {
							// Handle missing data in $RM
							echo '<p>Error: Missing room data.</p>';
						}
					}
				} else {
            // Handle query failure
            echo '<p>Error fetching room data. Please try again later.</p>';
        }
    } else {
        // Handle missing data in $row
        echo '<p>Error: Missing floor data.</p>';
    }
}

			 $sql1="select * from Mas_Hotel where isnull(Enableonoffsms,0)=1 and Hotel_Id=".Hotel_Id."";
			$sql1exe=$this->db->query($sql1);
			$enabled=$sql1exe->num_rows();
			if($enabled != 0)
			{
			     $sql="SELECT Device, sent,
			   
					CASE WHEN datediff(Minute,StUpdate,getdate()) >1 THEN 'Offline' ELSE 'Online' END AS Status,
					CASE WHEN datediff(Minute,StUpdate,getdate()) >1 THEN 0 ELSE 1 END AS Img,Dev_status,Dev_statusflg,fl.Floor FROM Mas_Device Dev
					left outer join Mas_Floor fl on fl.Floor_Id=Dev.Floor_Id
					WHERE Dev.Hotel_Id=".Hotel_Id." and isnull(Dev_status,0)=1  and isnull(sent,0)=1 ";
				$sqlexe=$this->db->query($sql);
				foreach($sqlexe->result() as $resbox)
				{ 
					if($resbox->Status == 'Offline')
					{ 
                        $sql1 = "   
                        SELECT Device, hotel_id, Dev_status, Dev_smsflg,
                         sent,
                                       CASE WHEN datediff(Minute, StUpdate, getdate()) > 1 THEN 'Offline' ELSE 'Online' END AS Status, 
                                       CASE WHEN datediff(Minute, StUpdate, getdate()) > 1 THEN 0 ELSE 1 END AS Img 
                                       
                                    FROM Mas_Device 
                                    WHERE Hotel_Id = " . Hotel_Id . " 
                                    AND ISNULL(Dev_status, 0) = 1 
                                    AND ISNULL(Dev_smsflg, 0) = 1
                                    AND ISNULL(sent, 0) =1";
   
   
                           $sql1exe = $this->db->query($sql1);
   
                         
                           if ($sql1exe->num_rows() > 0) {
                               foreach ($sql1exe->result() as $resbox1) {
                                   $myServer = "FS-RECEPTION";
                                   $myUser = "SA";
                                   $myPass = "mgenn";
                                   $myDB = "fortunenew1";
   
                                  
                                   $dbhandle = odbc_connect("Driver={SQL Server Native Client 10.0};Server=$myServer;Database=$myDB;", $myUser, $myPass);
   
                                 
                                   $sqlother = "SELECT * FROM usedb";
                                   $sqlotherexe = odbc_exec($dbhandle, $sqlother);
   
                                  
                                   $headings = [];
                                   while ($rowother = odbc_fetch_array($sqlotherexe)) {
                                       $myServerin = $rowother['servername'];
                                       $myDBin = $rowother['dbname'];
                                       $myUserin = $rowother['userid'];
                                       $myPassin = $rowother['password'];
   
                                       
                                       $dbhandle1 = odbc_connect("Driver={SQL Server Native Client 10.0};Server=$myServerin;Database=$myDBin;", $myUserin, $myPassin);
   
                                      
                                       if (empty($headings)) {
                                           $Name= '';
                                           $sqlheadings = "SELECT * FROM headings WHERE restypeid = 7";
                                           $headingsexe = odbc_exec($dbhandle1, $sqlheadings);
                                           while ($headingsrow = odbc_fetch_array($headingsexe)) {
                                               $Name= $headingsrow['Name']; 
                                           }
                                       }
                                               $Floor='';
                                  
                                       $sqlmobile = "SELECT * FROM mas_smsusers WHERE usertype='500'";
                                       $mobileexe = odbc_exec($dbhandle1, $sqlmobile);
   
                                       while ($mobilerow = odbc_fetch_array($mobileexe)) {
                                           $Floor = $resbox->Floor; 
                                           $mobileno = $mobilerow['mobileno'];
   
                                   
                                           $smsMessage = "Device No: " . $resbox1->Device . ", Floor: " . $Floor . " Status: Disconnected on " . date('d/m/Y H:i:s') . " - " . $Name;
   
                                          
                                           $checkDuplicate = "SELECT COUNT(*) as count FROM Outbox WHERE MobileNumber = '$mobileno' AND SMSMessage = '$smsMessage'";
                                           $duplicateCheckExe = odbc_exec($dbhandle1, $checkDuplicate);
                                           $duplicateCount = odbc_fetch_array($duplicateCheckExe)['count'];
   
   
                                           if ($duplicateCount == 0) { 
                                             
                                             //  $ins = "DECLARE @siden INT; 
                                                   //	INSERT INTO Outbox(MobileNumber, SMSMessage, DateCreated,hotelcode)
                                                       //VALUES('" . $mobileno . "', '$smsMessage', CONVERT(varchar(25), GETDATE(), 101),'FC588919126');
                                                       
                                                $ins = "DECLARE @siden INT; 
                                                       INSERT INTO Outbox(MobileNumber, SMSMessage, DateCreated,hotelcode,smstemplateid,smstemplatecnt)
                                                       VALUES('" . $mobileno . "', '$smsMessage', CONVERT(varchar(25), GETDATE(), 101),'FC588919126','powerbypass',5);
                                                       
                                                       SET @siden = @@IDENTITY;
                                                       INSERT INTO Outbox_smsval(msgid, smstype, Variablename, Variableval, Smsval) VALUES(@siden, 'PWRBY', 'Device No', '1', '" . $resbox1->Device . "');
                                                       INSERT INTO Outbox_smsval(msgid, smstype, Variablename, Variableval, Smsval) VALUES(@siden, 'PWRBY', 'Floor', '2', '" . $Floor . "');
                                                       INSERT INTO Outbox_smsval(msgid, smstype, Variablename, Variableval, Smsval) VALUES(@siden, 'PWRBY', 'Status', '3', '" . $resbox1->Status . "');
                                                       INSERT INTO Outbox_smsval(msgid, smstype, Variablename, Variableval, Smsval) VALUES(@siden, 'PWRBY', 'Hotelier Name', '4', 'Fortune Suites');
                                                       INSERT INTO Outbox_smsval(msgid, smstype, Variablename, Variableval, Smsval) VALUES(@siden, 'PWRBY', 'Date & Time', '5', '" . date('d/m/Y H:i:s') . "');";
   
                                               $insexe = odbc_exec($dbhandle1, $ins);
   
                                             
                                               $up1 = "UPDATE Mas_Device SET Dev_smsflg = 1,sent = 0 WHERE Device = '" . $resbox1->Device . "'";
                                               $upexe1 = $this->db->query($up1);
                                               
                                             // $up2 = "UPDATE Mas_Device SET sent =1 WHERE Device = '" . $resbox1->Device . "'";
                                              // $upexe2 = $this->db->query($up2);
                                           }
                                       }
   
                                    
                                       odbc_close($dbhandle1);
                                   }
   
                                   odbc_close($dbhandle);
                               }
      //}
   //}
                       //}
                       //	 }
                           
                           }	
					}
					 else {
						
					    $sql1 = "   
					 SELECT Device, hotel_id, Dev_status, Dev_smsflg,
					  sent,
									CASE WHEN datediff(Minute, StUpdate, getdate()) > 1 THEN 'Offline' ELSE 'Online' END AS Status, 
									CASE WHEN datediff(Minute, StUpdate, getdate()) > 1 THEN 0 ELSE 1 END AS Img 
									
								 FROM Mas_Device 
								 WHERE Hotel_Id = " . Hotel_Id . " 
								 AND ISNULL(Dev_status, 0) = 1 
								 AND ISNULL(Dev_smsflg, 0) = 1
								 AND ISNULL(sent, 0) =1";


						$sql1exe = $this->db->query($sql1);

					  
						if ($sql1exe->num_rows() > 0) {
							foreach ($sql1exe->result() as $resbox1) {
								$myServer = "FS-RECEPTION";
								$myUser = "SA";
								$myPass = "mgenn";
								$myDB = "fortunenew1";

							   
								$dbhandle = odbc_connect("Driver={SQL Server Native Client 10.0};Server=$myServer;Database=$myDB;", $myUser, $myPass);

							  
								$sqlother = "SELECT * FROM usedb";
								$sqlotherexe = odbc_exec($dbhandle, $sqlother);

							   
								$headings = [];
								while ($rowother = odbc_fetch_array($sqlotherexe)) {
									$myServerin = $rowother['servername'];
									$myDBin = $rowother['dbname'];
									$myUserin = $rowother['userid'];
									$myPassin = $rowother['password'];

									
									$dbhandle1 = odbc_connect("Driver={SQL Server Native Client 10.0};Server=$myServerin;Database=$myDBin;", $myUserin, $myPassin);

								   
									if (empty($headings)) {
										$Name= '';
										$sqlheadings = "SELECT * FROM headings WHERE restypeid = 7";
										$headingsexe = odbc_exec($dbhandle1, $sqlheadings);
										while ($headingsrow = odbc_fetch_array($headingsexe)) {
											$Name= $headingsrow['Name']; 
										}
									}
											$Floor='';
							   
									$sqlmobile = "SELECT * FROM mas_smsusers WHERE usertype='500'";
									$mobileexe = odbc_exec($dbhandle1, $sqlmobile);

									while ($mobilerow = odbc_fetch_array($mobileexe)) {
										$Floor = $resbox->Floor; 
										$mobileno = $mobilerow['mobileno'];

								
										$smsMessage = "Device No: " . $resbox1->Device . ", Floor: " . $Floor . " Status: Active on " . date('d/m/Y H:i:s') . " - " . $Name;

									   
										$checkDuplicate = "SELECT COUNT(*) as count FROM Outbox WHERE MobileNumber = '$mobileno' AND SMSMessage = '$smsMessage'";
										$duplicateCheckExe = odbc_exec($dbhandle1, $checkDuplicate);
										$duplicateCount = odbc_fetch_array($duplicateCheckExe)['count'];


										if ($duplicateCount == 0) { 
										  
									      //  $ins = "DECLARE @siden INT; 
												//	INSERT INTO Outbox(MobileNumber, SMSMessage, DateCreated,hotelcode)
													//VALUES('" . $mobileno . "', '$smsMessage', CONVERT(varchar(25), GETDATE(), 101),'FC588919126');
													
									       echo  $ins = "DECLARE @siden INT; 
													INSERT INTO Outbox(MobileNumber, SMSMessage, DateCreated,hotelcode,smstemplateid,smstemplatecnt)
													VALUES('" . $mobileno . "', '$smsMessage', CONVERT(varchar(25), GETDATE(), 101),'FC588919126','powerbypasson',5);
													
													SET @siden = @@IDENTITY;
													INSERT INTO Outbox_smsval(msgid, smstype, Variablename, Variableval, Smsval) VALUES(@siden, 'PWRBY', 'Device No', '1', '" . $resbox1->Device . "');
													INSERT INTO Outbox_smsval(msgid, smstype, Variablename, Variableval, Smsval) VALUES(@siden, 'PWRBY', 'Floor', '2', '" . $Floor . "');
													INSERT INTO Outbox_smsval(msgid, smstype, Variablename, Variableval, Smsval) VALUES(@siden, 'PWRBY', 'Status', '3', '" . $resbox1->Status . "');
													INSERT INTO Outbox_smsval(msgid, smstype, Variablename, Variableval, Smsval) VALUES(@siden, 'PWRBY', 'Hotelier Name', '4', 'Fortune Suites');
													INSERT INTO Outbox_smsval(msgid, smstype, Variablename, Variableval, Smsval) VALUES(@siden, 'PWRBY', 'Date & Time', '5', '" . date('d/m/Y H:i:s') . "');";

											$insexe = odbc_exec($dbhandle1, $ins);

										  
											$up1 = "UPDATE Mas_Device SET Dev_smsflg = 1,sent = 0 WHERE Device = '" . $resbox1->Device . "'";
											$upexe1 = $this->db->query($up1);
											
										  // $up2 = "UPDATE Mas_Device SET sent =1 WHERE Device = '" . $resbox1->Device . "'";
										   // $upexe2 = $this->db->query($up2);
										}
									}

								 
									odbc_close($dbhandle1);
								}

								odbc_close($dbhandle);
							}
   //}
//}
					//}
					//	 }
						
						}						
					}
				}
			}
	?>
  </fieldset>
  
   <fieldset style="background-color:#FFFFFF;display: none" class="Mdiv RoomTypeW MC" >
    <legend>RoomType</legend>
    <?php 
			$Res=$this->Myclass->RoomType();
			$count=1;
			 
		
		foreach ($Res as $row) { 
			
			if (isset($row['RoomType'], $row['RoomType_Id'])) {
				echo '<h5 class="card-title"><img width="16" height="16" src="' . scs_url . 'power/icon/roomtype.png" /> ' . htmlspecialchars($row['RoomType']) . '</h5>';
				
			
				$qry="select *,isnull( (SELECT TOP 1 PowerLog_Id FROM PowerLog WHERE Room_Id=b.Room_Id AND isnull(FLAG,-5)=-5 ),0) A from Mas_Room b where Hotel_Id=".Hotel_Id." and RoomType_Id=".$row['RoomType_Id'];
				
				
				$rom = $this->db->query($qry, [Hotel_Id, $row['RoomType_Id']]);
				
				if ($rom) {  
					foreach ($rom->result() as $RM) {
						if (isset($RM->Room_Id, $RM->State, $RM->RoomNo, $RM->Status_Id)) { // Check for essential properties
							if ($RM->A == 0) {
								echo '<div align="center" onClick="showTemplateDialog(' . htmlspecialchars($RM->Room_Id) . ',' . htmlspecialchars($RM->State) . ')" class="img-thumbnail txt_center RoomHover">
								<img width="64" height="64" src="' . scs_url . 'power/icon/' . htmlspecialchars($RM->Status_Id) . '.png" /><br>
								<b>' . htmlspecialchars($RM->RoomNo) . '</b></div>';
							} else {
								echo '<div align="center" class="img-thumbnail txt_center RoomHover">
								<img width="64" height="64" src="' . scs_url . 'power/icon/e.gif" /><br>
								<b>' . htmlspecialchars($RM->RoomNo) . '</b></div>';
							}
						} else {
							
							echo '<p>Error: Missing room data.</p>';
						}
					}
				} else {
					
					echo '<p>Error fetching room data. Please try again later.</p>';
				}
			} else {
				// Handle missing data in $row
				echo '<p>Error: Missing room type data.</p>';
			}
		}
		
			
	?>
  </fieldset>