 <style>
 .switch-field {
	display: flex;
	
	overflow: hidden;
}

.switch-field input {
	position: absolute !important;
	clip: rect(0, 0, 0, 0);
	height: 1px;
	width: 1px;
	border: 0;
	overflow: hidden;
}

.switch-field label {
	background-color: #e4e4e4;
	color: rgba(0, 0, 0, 0.6);
	font-size: 14px;
	line-height: 1;
	text-align: center;
	padding: 8px 16px;
	margin-right: -1px;
	border: 1px solid rgba(0, 0, 0, 0.2);
	box-shadow: inset 0 1px 3px rgba(0, 0, 0, 0.3), 0 1px rgba(255, 255, 255, 0.1);
	transition: all 0.1s ease-in-out;
}

.switch-field label:hover {
	cursor: pointer;
}

.switch-field input:checked + label {
	background-color: #074993;
	box-shadow: none;
	color:#FFFFFF;
}

.switch-field label:first-of-type {
	border-radius: 4px 0 0 4px;
}

.switch-field label:last-of-type {
	border-radius: 0 4px 4px 0;
}

/* This is just for CodePen. */

.form {
	max-width: 600px;
	font-family: "Lucida Grande", Tahoma, Verdana, sans-serif;
	font-weight: normal;
	line-height: 1.625;
	margin: 8px auto;
	padding: 16px;
}

h2 {
	font-size: 18px;
	margin-bottom: 8px;
}
 </style>
 <?php
	
	$Res='select * from Mas_Device where Hotel_Id='.Hotel_Id;
    $Res=$this->db->query($Res);
	foreach($Res->result_array() as $row)
			{
				?>
				<div class="col-md-4">
				<table class="sertable" >
					<thead>
					<tr><th style="background-color:#34495e;
					" colspan="6" ><div style="color:#FFFFFF" align="center"><?php echo $row['Device'];?></div></th></tr>
					<tr style="background-color:#34495e;">
						<th colspan="3"><div style="color: #FFFFFF"  align="center">Slate 1</div> </th>
						<th colspan="3"><div style="color: #FFFFFF"  align="center">Slate 2</div> </th>
					</tr>
					<tr>
						<th colspan="3">						
								<div style="color: #FFFFFF"  align="center ">	
									<input type="radio" id="<?php echo $row['Device'];?>1-one" onclick="On_Off('<?php echo $row['Device'];?>','0',1,1)"  name="<?php echo $row['Device'];?>1" value="1"  />
									<label for="<?php echo $row['Device'];?>1-one">ON</label>
									<input type="radio" id="<?php echo $row['Device'];?>1-two" onclick="On_Off('<?php echo $row['Device'];?>','0',0,1)"  name="<?php echo $row['Device'];?>1"  value="0" />
									<label for="<?php echo $row['Device'];?>1-two">OFF</label>
								</div>						
						</th>
						<th colspan="3">
							<div style="color: #FFFFFF"  align="center ">	
							    <input type="radio" id="<?php echo $row['Device'];?>2-one" onclick="On_Off('<?php echo $row['Device'];?>','0',1,2)"  name="<?php echo $row['Device'];?>2" value="1"  />
								<label for="<?php echo $row['Device'];?>2-one">ON</label>
								<input type="radio" id="<?php echo $row['Device'];?>2-two" onclick="On_Off('<?php echo $row['Device'];?>','0',0,2)"  name="<?php echo $row['Device'];?>2"  value="0" />
								<label for="<?php echo $row['Device'];?>2-two">OFF</label>
							</div> </th>
						</tr>
						<tr style="background-color:#34495e;color: #FFFFFF">
							<th style="color:#FFFFFF !important" >Control</th>
							<th style="color:#FFFFFF !important">Status</th>
							<th style="color:#FFFFFF !important">ON/OFF</th>
							<th style="color:#FFFFFF !important">Control</th>
							<th style="color:#FFFFFF !important">Status</th>
							<th style="color:#FFFFFF !important">ON/OFF</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$qry=" SELECT a.Control AC,isnull(a.State,0) ASS,b.Control BC,isnull(b.State,0) BS FROM TMC1 a, TMC2 b
WHERE a.Control=b.Control AND a.Device=b.Device and a.Device='".$row['Device']."' ORDER BY a.Control ";
						$Rm=$this->db->query($qry);
						foreach($Rm->result() as $R)
						{
							$FSCON="checked"; 
							$FSCOFF="";
							if($R->ASS==0){ $FSCON="";$FSCOFF="checked"; }
							
							
							$SSCON="checked";
							$SSCOFF="";
							if($R->BS==0){ $SSCON="";$SSCOFF="checked"; }
							echo '<tr>';
							echo '<td align="center" >'.$R->AC.'</td>';						 
							echo '<td align="center" > <img src="'.scs_url.'power/icon/'.$R->ASS.'l.png" > </td>';
							echo '<td align="center" ><div  align="center" class="switch-field">
		<input type="radio" id="'.$row['Device'].$R->AC.'1-one" onclick="On_Off(&#39;'.$row['Device'].'&#39;,'.$R->AC.',1,1)"  name="'.$row['Device'].$R->AC.'1" value="1" '.$FSCON.' />
		<label for="'.$row['Device'].$R->AC.'1-one">ON</label>
		<input type="radio" id="'.$row['Device'].$R->AC.'1-two" onclick="On_Off(&#39;'.$row['Device'].'&#39;,'.$R->AC.',0,1)"  name="'.$row['Device'].$R->AC.'1" '.$FSCOFF.'  value="0" />
		<label for="'.$row['Device'].$R->AC.'1-two">OFF</label>
	</div> </td>';
							
							echo '<td align="center" >'.$R->BC.'</td>';						 
							echo '<td align="center" > <img src="'.scs_url.'power/icon/'.$R->BS.'l.png" > </td>';
									echo '<td align="center" >
									<div  align="center" class="switch-field">
		<input type="radio" id="'.$row['Device'].$R->BC.'2-one" onclick="On_Off(&#39;'.$row['Device'].'&#39;,'.$R->BC.',1,2)"   name="'.$row['Device'].$R->BC.'2" '.$SSCON.' value="1" />
		<label for="'.$row['Device'].$R->BC.'2-one">ON</label>
		<input type="radio" id="'.$row['Device'].$R->BC.'2-two" onclick="On_Off(&#39;'.$row['Device'].'&#39;,'.$R->BC.',0,2)"   name="'.$row['Device'].$R->BC.'2" '.$SSCOFF.'  value="0" />
		<label for="'.$row['Device'].$R->BC.'2-two">OFF</label>
	</div> </td>';
					
							echo '<tr>';
						}
						?>
					</tbody>
				</table>
</div>
				<?php
			}
	
	?>