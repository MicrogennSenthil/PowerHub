<fieldset style="background-color:#FFFFFF ; "  class="Mdiv FloorW MC" >
    <legend>Floor</legend>
    <?php 
			$Res=$this->Myclass->Floor();
			$count=1;
			date_default_timezone_set('Asia/Kolkata');

foreach ($Res as $row) {
    // Check if 'Floor' and 'Floor_Id' exist in the current row
    if (isset($row['Floor'], $row['Floor_Id'])) {
        echo '<h5 class="card-title"><img width="16" height="16" src="' . scs_url . 'power/icon/Floor.png" /> ' . htmlspecialchars($row['Floor']) . '</h5>';

        // Prepare the SQL query securely using query bindings
		$qry="
		  select *,
	 isnull( (SELECT TOP 1 PowerLog_Id FROM PowerLog WHERE Room_Id=b.Room_Id AND isnull(FLAG,-5)=-5 ),0) A from Mas_Room b 
 where Hotel_Id=".Hotel_Id." and  Floor_Id=".$row['Floor_Id']." order by roomno";

      
				$rom = $this->db->query($qry, [Hotel_Id, $row['Floor_Id']]);
				
				if ($rom) {  // Check if query execution is successful
					foreach ($rom->result() as $RM) {
						if (isset($RM->Room_Id, $RM->State, $RM->RoomNo, $RM->Status_Id)) { // Check for essential properties
							if ($RM->A == 0) {
								echo '<div align="center" onClick="showTemplateDialog(' . htmlspecialchars($RM->Room_Id) . ',' . htmlspecialchars($RM->State) . ')" class="img-thumbnail txt_center RoomHover">
								<img width="64" height="64" src="' . scs_url . 'power/icon/' . htmlspecialchars($RM->Status_Id) . '.png" /><br>
								<b>' . htmlspecialchars($RM->RoomNo) . '</b></div>';
							} else {
								echo '<div align="center" class="img-thumbnail txt_center RoomHover">
								<img width="64" height="64" src="' . scs_url . 'power/icon/e.gif" /><br>
								<b>' . htmlspecialchars($RM->RoomNo) . '</b></div>';
							}
						} else {
							// Handle missing data in $RM
							echo '<p>Error: Missing room data.</p>';
						}
					}
				} else {
            // Handle query failure
            echo '<p>Error fetching room data. Please try again later.</p>';
        }
    } else {
        // Handle missing data in $row
        echo '<p>Error: Missing floor data.</p>';
    }
}

	?>
  </fieldset>
  
   <fieldset style="background-color:#FFFFFF;display: none" class="Mdiv RoomTypeW MC" >
    <legend>RoomType</legend>
    <?php 
			$Res=$this->Myclass->RoomType();
			$count=1;
			 
		
		foreach ($Res as $row) { 
			
			if (isset($row['RoomType'], $row['RoomType_Id'])) {
				echo '<h5 class="card-title"><img width="16" height="16" src="' . scs_url . 'power/icon/roomtype.png" /> ' . htmlspecialchars($row['RoomType']) . '</h5>';
				
			
				$qry="select *,isnull( (SELECT TOP 1 PowerLog_Id FROM PowerLog WHERE Room_Id=b.Room_Id AND isnull(FLAG,-5)=-5 ),0) A from Mas_Room b where Hotel_Id=".Hotel_Id." and RoomType_Id=".$row['RoomType_Id'];
				
				
				$rom = $this->db->query($qry, [Hotel_Id, $row['RoomType_Id']]);
				
				if ($rom) {  
					foreach ($rom->result() as $RM) {
						if (isset($RM->Room_Id, $RM->State, $RM->RoomNo, $RM->Status_Id)) { // Check for essential properties
							if ($RM->A == 0) {
								echo '<div align="center" onClick="showTemplateDialog(' . htmlspecialchars($RM->Room_Id) . ',' . htmlspecialchars($RM->State) . ')" class="img-thumbnail txt_center RoomHover">
								<img width="64" height="64" src="' . scs_url . 'power/icon/' . htmlspecialchars($RM->Status_Id) . '.png" /><br>
								<b>' . htmlspecialchars($RM->RoomNo) . '</b></div>';
							} else {
								echo '<div align="center" class="img-thumbnail txt_center RoomHover">
								<img width="64" height="64" src="' . scs_url . 'power/icon/e.gif" /><br>
								<b>' . htmlspecialchars($RM->RoomNo) . '</b></div>';
							}
						} else {
							
							echo '<p>Error: Missing room data.</p>';
						}
					}
				} else {
					
					echo '<p>Error fetching room data. Please try again later.</p>';
				}
			} else {
				// Handle missing data in $row
				echo '<p>Error: Missing room type data.</p>';
			}
		}
		
			
	?>
  </fieldset>