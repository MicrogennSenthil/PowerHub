<fieldset style="background-color:#FFFFFF" class="Mdiv FloorW MC" >
    <legend>Floor</legend>
    <?php 
			$Res=$this->Myclass->Floor();
			$count=1;
			 
		 foreach($Res as $row)
			{
              echo '<h5 class="card-title"><img width="16" height="16" src="'.scs_url.'power/icon/Floor.png" /> '.$row['Floor'].'</h5>';
			 echo   $qry=" select *,
isnull( (SELECT TOP 1 PowerLog_Id FROM PowerLog WHERE Room_Id=b.Room_Id AND isnull(FLAG,-5)=-5 ),0) A from Mas_Room b 
where Hotel_Id=".Hotel_Id." and  Floor_Id=".$row['Floor_Id']." order by roomno";
			   $rom=$this->db->query($qry);
			   foreach($rom->result() as $RM)
				{
					if($RM->A==0)
					{
					  echo '<div align="center"';
					  if(EnableONOFFoperation==1)
					  {
						echo 'onClick="showTemplateDialog('.$RM->Room_Id.','.$RM->State.')"';
					  }
					 echo ' class="img-thumbnail txt_center RoomHover"   >
					<img width="64" height="64" src="'.scs_url.'power/icon/'.$RM->Status_Id.'.png" /><br>
        			<b>'.$RM->RoomNo.'</b></div>';
					}
					else{
						
						echo '<div align="center"  class="img-thumbnail txt_center RoomHover"   >
					<img width="64" height="64" src="'.scs_url.'power/icon/e.gif" /><br>
        			<b>'.$RM->RoomNo.'</b></div>';
					}
				}
				
			}
			$sql1="select * from Mas_Hotel where isnull(Enableonoffsms,0)=1 and Hotel_Id=".Hotel_Id."";
			$sql1exe=$this->db->query($sql1);
			$enabled=$sql1exe->num_rows();
			if($enabled != 0)
			{
			    $sql="SELECT Device,
					CASE WHEN datediff(Minute,StUpdate,getdate()) >1 THEN 'Offline' ELSE 'Online' END AS Status,
					CASE WHEN datediff(Minute,StUpdate,getdate()) >1 THEN 0 ELSE 1 END AS Img,Dev_status,fl.Floor FROM Mas_Device Dev
					left outer join Mas_Floor fl on fl.Floor_Id=Dev.Floor_Id
					WHERE Dev.Hotel_Id=".Hotel_Id." and isnull(Dev_status,0)=1 ";
				$sqlexe=$this->db->query($sql);
				foreach($sqlexe->result() as $resbox)
				{ 
					if($resbox->Status == 'Offline')
					{ 
						date_default_timezone_set('Asia/Kolkata');
						$myServer = "FS-RECEPTION";  ///// New DB connection for geting current frontoffice database
						$myUser = "sa";
						$myPass = "mgenn";
						$myDB = "fortunenew1"; 		
						$dbhandle1 =  odbc_connect("Driver={SQL Server Native Client 11.0};Server=$myServer;Database=$myDB;", $myUser, $myPass);

						
						  
						  
						  $sqlheadings="select * from headings where restypeid=1";
						  $headingsexe = ODBC_EXEC($dbhandle1,$sqlheadings);	
						  while ($headingsrow = odbc_fetch_array($headingsexe))						  
						  {
							 $Name= $headingsrow['Name'];
						  }
						  
						  $sqlmobile="select * from mas_smsusers where usertype='500'";
						  $mobileexe = ODBC_EXEC($dbhandle1,$sqlmobile);	
                          foreach ($mobileexe as $mobilerow) {
						  {
							$mobileno=$mobilerow['mobileno'];
							$ins="insert into Outbox(MobileNumber,SMSMessage,DateCreated,hotelcode)
								 values('".$mobileno."','Device No:".$resbox->Device.",Floor:".$resbox->Floor." Status:Disconnected on ".date('d/m/Y H:i:s')." - ".$Name."',convert(varchar(25),getdate(),101),(select whatsapphotelcode)";
						    $insexe = ODBC_EXEC($dbhandle1,$ins);	
							
							$up="update Mas_Device set Dev_status=0,Dev_smsflg=0 where Device='".$resbox->Device."'";
							$upexe=$this->db->query($up);
						  }
						
					}
					else
					{
					  $sql1="SELECT Device, CASE WHEN datediff(Minute,StUpdate,getdate()) >1
						THEN 'Offline' ELSE 'Online' END AS Status, CASE WHEN datediff(Minute,StUpdate,getdate()) >1 THEN 0 ELSE 1 END AS Img,Dev_status
						FROM Mas_Device WHERE Hotel_Id=".Hotel_Id." and isnull(Dev_status,0)=1 and isnull(Dev_smsflg,0)=0";
						$sql1exe=$this->db->query($sql1);
						foreach($sql1exe->result() as $resbox1)
						{
							date_default_timezone_set('Asia/Kolkata');
						$myServer = "FS-RECEPTION";  ///// New DB connection for geting current frontoffice database
						$myUser = "sa";
						$myPass = "mgenn";
						$myDB = "fortunenew1"; 		
						$dbhandle1 =  odbc_connect("Driver={SQL Server Native Client 11.0};Server=$myServer;Database=$myDB;", $myUser, $myPass);


					
						  $sqlheadings="select * from headings where restypeid=1";
						  $headingsexe = ODBC_EXEC($dbhandle1,$sqlheadings);	
						  while ($headingsrow = odbc_fetch_array($headingsexe))						  
						  {
							 $Name= $headingsrow['Name'];
						  }
						  
						  $sqlmobile="select * from mas_smsusers where usertype='500'";
						  $mobileexe = ODBC_EXEC($dbhandle1,$sqlmobile);	
						  foreach ($mobileexe as $mobilerow) {
						  {
							$mobileno=$mobilerow['mobileno'];
							$ins="insert into Outbox(MobileNumber,SMSMessage,DateCreated)
								 values('".$mobileno."','Device No:".$resbox1->Device.",Floor:".$resbox->Floor." Status:Active on ".date('d/m/Y H:i:s')." - ".$Name."',convert(varchar(25),getdate(),101))";
						    $insexe = ODBC_EXEC($dbhandle1,$ins);	
							
							$up1="update Mas_Device set Dev_smsflg=1 where Device='".$resbox1->Device."'";
							$upexe1=$this->db->query($up1);
						  }
						 }
						
						}						
					
				}
			}
			
	?>
  </fieldset>
  
   <fieldset style="background-color:#FFFFFF;display: none" class="Mdiv RoomTypeW MC" >
    <legend>RoomType</legend>
    <?php 
			$Res=$this->Myclass->RoomType();
			$count=1;
			 
		 foreach($Res as $row)
			{ 
			   echo '<h5 class="card-title"><img width="16" height="16" src="'.scs_url.'power/icon/roomtype.png" /> '.$row['RoomType'].'</h5>';
			   $qry="select *,isnull( (SELECT TOP 1 PowerLog_Id FROM PowerLog WHERE Room_Id=b.Room_Id AND isnull(FLAG,-5)=-5 ),0) A from Mas_Room b where Hotel_Id=".Hotel_Id." and RoomType_Id=".$row['RoomType_Id'];
			   $rom=$this->db->query($qry);
			   foreach($rom->result() as $RM)
				{
					if($RM->A==0)
					{
					echo '<div align="center"  onClick="showTemplateDialog('.$RM->Room_Id.','.$RM->State.')" class="img-thumbnail txt_center RoomHover"   >
					<img width="64" height="64" src="'.scs_url.'power/icon/'.$RM->Status_Id.'.png" /><br>
        			<b>'.$RM->RoomNo.'</b></div>';
					}
					else{
						
						echo '<div align="center"  class="img-thumbnail txt_center RoomHover"   >
					<img width="64" height="64" src="'.scs_url.'power/icon/e.gif" /><br>
        			<b>'.$RM->RoomNo.'</b></div>';
					}
				}
			}
			
	?>
  </fieldset>