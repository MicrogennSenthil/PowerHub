<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Report','Order');
$this->pfrm->FrmHead3('Report / Order',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");
 
?>
<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
      <input type="hidden" name="idv" value="<?php echo @$MemberType_Id; ?>" >
      <table class="FrmTable T-12" >
        <tr>
          <td>From</td>
          <td><input type="text" value="<?php echo date('d/m/Y'); ?>" name="FromDate" to="FromDate" readonly class="scs-ctrl Dat" ></td>
          <td>To</td>
          <td><input type="text" value="<?php echo date('d/m/Y'); ?>" name="ToDate" to="ToDate" readonly class="scs-ctrl Dat" ></td>
          
           <td><label style="background-color:#F8B5B6;padding:3px" ><input checked onClick="Chkk(&#39;BROILER&#39;,this.checked)" type="checkbox" id="BROILER" > BROILER </label>
          <label style="background-color:#F8B5B6;padding:3px" ><input checked onClick="Chkk(&#39;HYBRID&#39;,this.checked)" type="checkbox" id="HYBRID" > HYBRID NATTUKU KOZHI  </label>
          <label style="background-color:#F8B5B6;padding:3px" ><input checked onClick="Chkk(&#39;NATTUKU&#39;,this.checked)" type="checkbox" id="NATTUKU" > NATTUKU KOZHI  </label>
          <label style="background-color:#F8B5B6;padding:3px" ><input checked onClick="Chkk(&#39;PARENT&#39;,this.checked)" type="checkbox" id="PARENT" > PARENT  </label>
           
            </td>
          <td align="left"><a    class="btn btn-success btn-sm"  onClick="GetRep()"    >GET</a></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="RepDet" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
 
 function Chkk(cla,chk)
 {
	  if(chk){ $('.'+cla).show(); } else { $('.'+cla).hide();   }
 }
function GetRep()
{
	$.ajax({
		
		type:"POST",
		url:"<?php echo scs_index; ?>Rep/Order",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.RepDet').html(html);
		}
		
		
		
	})
}
</script> 
