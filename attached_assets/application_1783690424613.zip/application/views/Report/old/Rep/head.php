<style>
.mytables {
	border-collapse: collapse;
	width: 100%;
	font-size: 13px;
	color: #000000 !important;
}
.mytables thead   {
  background: #757575; 

}
.mytables thead th  {
		padding: 4px !important;
	border: solid #bdbdbd 1px;
	color: #FFFFFF !important;
	font-weight: bold !important;
}
.mytables td {
	padding: 2px;
	border: solid #bdbdbd 1px;
	font-weight: normal ; 
	background-color: #FFFFFF;
}
</style>
<?php
$Logo = file_get_contents(spath.'upload/logo.png');
$Logo = base64_encode($Logo);
?>
<table width="100%" border="0" cellspacing="1" cellpadding="1" style="border-bottom:dashed 1px #000000" >
  <tbody>
    <tr>
      <td align="left">
	   
	  <img width="100" height="100" src="data:image/png;base64,<?php echo $Logo; ?>" > </td>
      <td align="right" style="font-size:13px" >
	   <strong style="font-size:15px;color:red"><?php echo Company; ?></strong>  <br>
        <?php echo Address; ?>, <?php echo City; ?> - <?php echo PinCode; ?>. <br>
        <strong>Phone</strong> : +91 <?php echo Phone  ; ?>, <strong>Email</strong> : <?php echo Email; ?><br>
        <strong>GSTIN : </strong><?php echo GST; ?></td>
    </tr>
  </tbody>
</table>