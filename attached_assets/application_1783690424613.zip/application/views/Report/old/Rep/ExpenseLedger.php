<?php include('head.php'); ?>
 
 <div align="center" ><font size="+2" >ExpenseLedger</font> <br> From : <?php echo $_POST['FromDate']?> To : <?php echo $_POST['ToDate']?></div>
<table class="mytables" style="margin-top:10px ">
  <thead>
    <tr style="font-weight:bold " >
      <th style="width:20px;"> <strong>#</strong></th>
      <th  ><strong>Code</strong></th>
      <th  ><strong>SupplierName</strong></th>
      <th  ><strong>GrnNo</strong></th>
	  <th  ><strong>Date</strong></th>
	  <th  ><strong>Head</strong></th>
      <th  ><strong>Amount</strong></th>
      
    </tr>
  </thead>
  <tbody>
    <?php
            
	$qry=" exec Rep_ExpenseLedger '".$this->Myclass->DateSplit($_POST['FromDate'])."',
	      '".$this->Myclass->DateSplit($_POST['ToDate'])."',".$_POST['Ledger_Id'].",".Branch_Id;
		$res=$this->db->query($qry);
		$cou=1;
		$AMT=0;
		$Qty=0;$Debit=0;$Amount=0;
		 
		foreach($res->result() as $row)
		{
			echo '<tr   >
			<td  >'.$cou.'</td>
			<td >'.$row->Code.'</td>
			<td >'.$row->SupplierName.'</td>
			<td >'.$row->DcNo.'</td>
			<td >'.$row->Dat.'</td>
			<td >'.$row->LNAME.'</td>
			 <td  align="right">'.floatval($row->Amount).'</td>
			
			
			
			</tr>';
			$cou++;
			 
		$Amount +=$row->Amount;
		 
			 
			 
		}
			
			?>
  </tbody>
  <tfoot>
    <tr style="font-weight:bold " >
      <td align="right" style="background-color:#E5E5E5;" colspan="6"><strong>Total</strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $Amount; ?></strong></td>
   
    </tr>
  </tfoot>
</table>
