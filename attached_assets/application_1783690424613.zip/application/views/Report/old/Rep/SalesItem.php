<?php include('head.php'); ?>
 
 <div align="center" ><font size="+2" >Sales Item</font> <br> From : <?php echo $_POST['FromDate']?> To : <?php echo $_POST['ToDate']?></div>
<table class="mytables" style="margin-top:10px ">
  <thead>
    <tr style="font-weight:bold " >
      <th style="width:20px;"> <strong>#</strong></th>
      <th  ><strong>CustomerName</strong></th>
      <th  ><strong>InvNo</strong></th>
      <th  ><strong>Date</strong></th>
      <th  ><strong>ItemName</strong></th>
      <th  ><strong>No Of Box</strong></th>
      <th  ><strong>No Of Birds</strong></th>
      <th  ><strong>EmptyWeight</strong></th>
      <th  ><strong>LoadWeight</strong></th>
      <th  ><strong>NetValue</strong></th>
             <th  ><strong>Rate</strong></th>
      <th  ><strong>Amount</strong></th>
    </tr>
  </thead>
  <tbody>
    <?php
            
	$qry=" exec Rep_Sales_Item '".$this->Myclass->DateSplit($_POST['FromDate'])."',
	       '".$this->Myclass->DateSplit($_POST['ToDate'])."',".Branch_Id.",".$_POST['Customer_Id'].",".$_POST['Item_Id'];
		$res=$this->db->query($qry);
		$cou=1;
		$AMT=0;
		$Qty=0;$NetValue=0;$Amount=0;
		 
		foreach($res->result() as $row)
		{
			echo '<tr   >
			<td  >'.$cou.'</td>
			<td >'.$row->CustomerName.'</td>
			<td >'.$row->DcNo.'</td>
			<td >'.$row->Date.'</td>
			<td >'.$row->ItemName.'</td>
			<td  align="right">'.floatval($row->Box).'</td>
			<td  align="right">'.floatval($row->Qty).'</td>
			<td  align="right">'.floatval($row->EmptyWeight).'</td> 
			<td  align="right">'.floatval($row->LoadWeight).'</td> 
			<td  align="right">'.floatval($row->NetValue).'</td>
			<td  align="right">'.floatval($row->Rate).'</td>
			<td  align="right">'.floatval($row->Amount).'</td>
			 
			
			
			
			</tr>';
			$cou++;
			 
			 $Qty +=$row->Qty;$NetValue +=$row->NetValue;$Amount +=$row->Amount;
			 
			 
		}
			
			?>
  </tbody>
  <tfoot>
    <tr style="font-weight:bold " >
      <td align="right" colspan="11" style="background-color:#E5E5E5;"  ><strong>Total</strong></td>
     
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $Amount; ?></strong></td>
    </tr>
  </tfoot>
</table>
