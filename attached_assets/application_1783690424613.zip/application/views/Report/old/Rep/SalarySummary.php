<?php include('head.php'); ?>
<div align="center" ><font size="+2" >Salary Summary</font> <br>
  From : <?php echo $_POST['FromDate']?> To : <?php echo $_POST['ToDate']?></div>
<table class="mytables"  >
  <thead>
    <tr style="font-weight:bold " >
      <th style="width:20px;"> <strong>#</strong></th>
      <th  ><strong>EmployeeName</strong></th>
      <th  ><strong>Grn</strong></th>
      <th  ><strong>No</strong></th>
      <th  ><strong>Date</strong></th>
      <th  ><strong>PayMode</strong></th>
      <th  ><strong>Receipt</strong></th>
      <th  ><strong>Payment</strong></th>
    </tr>
  </thead>
  <tbody>
    <?php
            
	  $qry=" exec Rep_SalarySummary '".$this->Myclass->DateSplit($_POST['FromDate'])."','".$this->Myclass->DateSplit($_POST['ToDate'])."',".$_POST['Employee_Id'].",".Branch_Id;
		$res=$this->db->query($qry);
		$cou=1;
		$AMT=0;
		$Qty=0;$Payment=0;$Receipt=0;
		 
		foreach($res->result() as $row)
		{
			echo '<tr   >
			<td  >'.$cou.'</td>
			<td >'.$row->EmployeeName.'</td>
			<td >'.$row->DcNo.'</td> 
            <td >'.$row->No.'</td> 
			<td >'.$row->Date.'</td> 
			<td >'.$row->Mode.'</td> 
		    <td  align="right">'.floatval($row->Receipt).'</td>
			<td  align="right">'.floatval($row->Payment).'</td>';
        
			
			echo '</tr>';
			$cou++;
			 
		$Receipt +=$row->Receipt;
	    $Payment +=$row->Payment;
			 
			 
		}
			
			?>
  </tbody>
  <tfoot>
    <tr style="font-weight:bold " >
      <td align="right" style="background-color:#E5E5E5;" colspan="6"><strong>Total </strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $Receipt; ?></strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $Payment; ?></strong></td>
   
  </tfoot>
</table>
