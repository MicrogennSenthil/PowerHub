<?php include('head.php'); ?>
  <div align="center" ><font size="+2" >Bank Book</font> <br> From : <?php echo $_POST['FromDate']?> To : <?php echo $_POST['ToDate']?></div>
<table class="mytables" style="margin-top:10px ">
  <thead>
    <tr style="font-weight:bold " >
      <th style=""> <strong>#</strong></th>
      <th  ><strong>No</strong></th>
      <th  ><strong>Date</strong></th>
      <th  ><strong>Voucher</strong></th>
      <th  ><strong>Particulars</strong></th>
      <th  ><strong>Debit</strong></th>
      <th  ><strong>Credit</strong></th>
    </tr>
  </thead>
  <tbody>
    <?php
            
	  $qry=" exec Rep_BankBook '".$this->Myclass->DateSplit($_POST['FromDate'])."',
	       '".$this->Myclass->DateSplit($_POST['ToDate'])."'";  
		$res=$this->db->query($qry);
		$cou=1;
		$AMT=0;
		$Qty=0;$Debit=0;$Credit=0;
		 
		foreach($res->result() as $row)
		{
			echo '<tr   >
			<td  >'.$cou.'</td>
			<td >'.$row->PNo.'</td>
			<td >'.$row->DATE.'</td>
			<td >'.$row->Voucher.'</td>
			<td >'.$row->Particulars.'</td>
			<td align="right" >'.floatval($row->Debit).'</td> 
			<td align="right" >'.floatval($row->Credit).'</td> 
		 
			 
			
			
			
			</tr>';
			$cou++;
			 
		$Debit +=$row->Debit;
		$Credit +=$row->Credit;	 
			 
		}
			$Bal=$Debit-$Credit;
			?>
  </tbody>
  <tfoot>
  <tr style="font-weight:bold " >
      <td style="background-color:#E5E5E5;" align="right" colspan="5"><strong>Opening Total</strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php   $Debit; ?></strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php   $Credit; ?></strong></td>
    </tr>
    <tr style="font-weight:bold " >
      <td style="background-color:#E5E5E5;" align="right" colspan="5"><strong>Current Total</strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $Debit; ?></strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $Credit; ?></strong></td>
    </tr>
    
    <tr style="font-weight:bold " >
      <td style="background-color:#E5E5E5;" colspan="5" align="right"><strong>Closing Total</strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php if($Bal>0){ echo str_replace('-','',$Bal); } ?></strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php if($Bal<0){ echo str_replace('-','',$Bal); } ?></strong></td>
    </tr>
    
  </tfoot>
</table>
