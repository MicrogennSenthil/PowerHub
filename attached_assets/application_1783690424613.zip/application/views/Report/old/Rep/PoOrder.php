<table class="mytable" style="margin-top:10px ">
  <thead>
    <tr>
      <th style="width:20px" >#</th>
      <th  >OrderNo</th>
      <th>OrderDate</th>
      <th style="width:150px" >Employee</th>
      <th  >Model</th>
      <th style="width:120px"  >Qty</th>
    </tr>
  </thead>
  <tbody>
    <?php
            
		 	$qry=" exec Rep_Sales_Order '".$this->Myclass->DateSplit($_POST['FromDate'])."','".$this->Myclass->DateSplit($_POST['ToDate'])."',
			'".$_POST['Product_Id']."','".$_POST['Employee_Id']."'";
		$res=$this->db->query($qry);
		$cou=1;
		$AMT=0;
		foreach($res->result() as $row)
		{
			echo '<tr   >
			<td>'.$cou.'</td>
			<td>'.$row->OrderNo.'</td>
			<td>'.$row->Dat.'</td>
			<td>'.$row->EmployeeName.'</td>
			<td>'.$row->Product.'</td>
			<td align="right">'.floatval($row->Qty).'</td> 
			 </tr>';
			$cou++;
			 
		}
			
			?>
  </tbody>
  
</table>
