<table class="mytable" style="margin-top:10px ">
  <thead>
    <tr>
      <th style="width:20px" >#</th>
      <th style="width:150px" >ITEM CODE</th>
      <th>ITEM DESCRIPTION</th>
      <th  style="width:50px" >UOM</th>
      <th style="width:100px" >BOM QTY</th>
      <th    >Rate</th>
      <th    >Total</th>
    </tr>
  </thead>
  <tbody>
  
   <?php
            
		 	$qry=" exec Get_Product_Det   '".$_POST['Product_Id']."'";
		$res=$this->db->query($qry);
		$cou=1;
		$AMT=0;
		foreach($res->result() as $row)
		{
			echo '<tr class="RW'.$row->Product_Det_Id.'" >
			<td>'.$cou.'</td>
			<td>'.$row->PartNumber.'</td>
			<td>'.$row->Itemname.'</td>
			<td>'.$row->SYMBOL.'</td>
			<td align="right" >'.$row->BOMQTY.'</td> 
			<td align="right" >'.$row->Rate.'</td> 
			<td align="right" >'.($row->Cost).'</td> 
			 </tr>';
			$cou++;
			$AMT=$AMT+ $row->Cost;
		}
			
			?>
  
  </tbody>
  <tfoot>
  <tr><td colspan="6" >Total</td>
  <td><div align="right"><?php echo $AMT;?></div></td>
  </tr>
  </tfoot>
</table>
