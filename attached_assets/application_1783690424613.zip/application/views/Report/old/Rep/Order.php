<?php include('head.php'); ?>
<div align="center" ><font size="+2" >Order Form</font> <br>
  From : <?php echo $_POST['FromDate']?> To : <?php echo $_POST['ToDate']?></div>
<table class="mytables" style="margin-top:10px ">
  <thead>
    <tr style="font-weight:bold " >
      <th style="width:20px;"> <strong>#</strong></th>
      <th  ><strong>CustomerId</strong></th>
      <th  ><strong>CustomerName</strong></th>
      <th class="BROILER"  ><strong>BROILER</strong></th>
      <th class="HYBRID"  ><strong>HYBRID NATTUKU KOZHI</strong></th>
      <th class="NATTUKU"  ><strong>NATTUKU KOZHI</strong></th>
      <th class="PARENT"  ><strong>PARENT</strong></th>
    </tr>
  </thead>
  <?php
   $qry=" exec Rep_Order '".$this->Myclass->DateSplit($_POST['FromDate'])."',
	       '".$this->Myclass->DateSplit($_POST['ToDate'])."'";
		$res=$this->db->query($qry);
		$cou=1;
		$BROILER=0;$HYBRID=0;$NATTUKU=0;$PARENT=0;
		$tot=0;
		
		foreach($res->result() as $row)
		{
			$EmployeeName=$row->EmployeeName;
			
			$BRO='';$HYB='';$NAT='';$PAR='';
			if(floatval($row->BROILER)!=0) { $BRO=floatval($row->BROILER); }
			if(floatval($row->HYBRID)!=0) { $HYB=floatval($row->HYBRID); }
			if(floatval($row->NATTUKU)!=0) { $NAT=floatval($row->NATTUKU); }
			if(floatval($row->PARENT)!=0) { $PAR=floatval($row->PARENT); }
			echo '<tr   >
			<td  >'.$cou.'</td>
			<td >'.$row->CustomerId.'</td>
			<td >'.$row->CustomerName.' 
			 - '.$row->Mobile.'</td>
			<td class="BROILER"  align="right">'.$BRO.'</td>
			<td class="HYBRID"  align="right">'.$HYB.'</td>
			<td class="NATTUKU"  align="right">'.$NAT.'</td> 
			<td class="PARENT"  align="right">'.$PAR.'</td> 
		 
			</tr>';
			$cou++;
			 
			 $BROILER +=$row->BROILER;
			 $HYBRID   +=$row->HYBRID;
			 $NATTUKU +=$row->NATTUKU;
			 $PARENT +=$row->PARENT;
			 
			 
		}
		
  
  
  ?>
    </tbody>
  
  <tfoot>
    <tr style="font-weight:bold; ">
      <td style="background-color:#E5E5E5"   colspan="3"><strong>Total</strong></td>
      <td style="background-color:#E5E5E5" class="BROILER" align="right"><strong><?php echo  $BROILER; ?></strong></td>
      <td style="background-color:#E5E5E5" class="HYBRID" align="right"><strong><?php echo  $HYBRID; ?></strong></td>
      <td style="background-color:#E5E5E5" class="NATTUKU" align="right"><strong><?php echo  $NATTUKU; ?></strong></td>
      <td style="background-color:#E5E5E5" class="PARENT" align="right"><strong><?php echo  $PARENT; ?></strong></td>
  </tfoot>
  
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="3">
    
     
    <tr>
      <td align="left"  height="80" ><?php echo $EmployeeName; ?><br><b>Authorized by</b> </td>
      <td align="center"    > </td>
      <td  colspan="5" align="right"   ><b>Approved by</b></td>
    </tr>
	</table>
  
 