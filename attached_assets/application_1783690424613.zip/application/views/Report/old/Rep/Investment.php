<?php include('head.php'); ?>
 
 <div align="center" ><font size="+2" >Purchase </font> <br> From : <?php echo $_POST['FromDate']?> To : <?php echo $_POST['ToDate']?></div>
<table class="mytables" style="margin-top:10px ">
  <thead>
    
    <tr style="font-weight:bold " >
      <th style="width:20px;"> <strong>#</strong></th>
      <th  ><strong>AccountHead</strong></th>
      <th  ><strong>No</strong></th>
      <th  ><strong>Date</strong></th>
      <th  ><strong>Amount</strong></th>
     
      
    </tr>
  </thead>
  <tbody>
    <?php
            
	$qry=" exec Rep_Investment '".$this->Myclass->DateSplit($_POST['FromDate'])."',
	      '".$this->Myclass->DateSplit($_POST['ToDate'])."',".Branch_Id.",".$_POST['AccountHead_Id'];
		$res=$this->db->query($qry);
		$cou=1;
		$AMT=0;
		$Qty=0;$NetValue=0;$Amount=0;
		 
		foreach($res->result() as $row)
		{
			echo '<tr   >
			<td  >'.$cou.'</td>
			<td >'.$row->AccountHead.'</td>
			<td >'.$row->InvestmentNo.'</td>
			<td >'.$row->Dat.'</td>
			  
			<td  align="right">'.floatval($row->Amount).'</td>
			 
			
			
			
			</tr>';
			$cou++;
			 
		$Amount +=$row->Amount;
			 
			 
		}
			
			?>
  </tbody>
  
  <tfoot>
  <tr style="font-weight:bold " >
      <td style="width:20px;background-color:#E5E5E5;" colspan="4"> <strong>Total</strong></td>
     
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $Amount; ?></strong></td>
      
     
      
    </tr>
  
  </tfoot>
  
</table>
