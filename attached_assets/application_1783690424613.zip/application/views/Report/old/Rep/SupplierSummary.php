<?php include('head.php'); ?>
<div align="center" ><font size="+2" >Supplier Summary</font> <br>
   From : <?php echo $_POST['FromDate']?> To : <?php echo $_POST['ToDate']?></div>
<table class="mytables"  >
  <thead>
    <tr style="font-weight:bold " >
      <th style="width:20px;"> <strong>#</strong></th>
      <th  ><strong>Code</strong></th>
      <th  ><strong>SupplierName</strong></th>
      <th  ><strong>Balance</strong></th>
    </tr>
  </thead>
  <tbody>
    <?php
            
	$qry=" exec Rep_SupplierSummary '".$this->Myclass->DateSplit($_POST['FromDate'])."',".$_POST['Supplier_Id'].",".Branch_Id;
		$res=$this->db->query($qry);
		$cou=1;
		$AMT=0;
		$Qty=0;$Bal=0;$Credit=0;
		 
		foreach($res->result() as $row)
		{
			echo '<tr   >
			<td  >'.$cou.'</td>
			<td >'.$row->Code.'</td>
            <td >'.$row->SupplierName.'</td>';
            if(floatval($row->Bal)==0)
            {
                echo '<td  align="right"> </td>';
            }
		  else {
			echo '<td  align="right">'.floatval($row->Bal).'</td>';
        }
			
			
			echo '</tr>';
			$cou++;
			 
		$Bal +=$row->Bal;
	 
			 
			 
		}
			
			?>
  </tbody>
  <tfoot>
    <tr style="font-weight:bold " >
      <td align="right" style="background-color:#E5E5E5;" colspan="3"><strong>Total Outstanding Balance</strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $Bal; ?></strong></td>
  </tfoot>
</table>
