<?php include('head.php'); ?>
 
<div align="center" ><font size="+2" >Sinkage</font> <br> From : <?php echo $_POST['FromDate']?> To : <?php echo $_POST['ToDate']?></div>
<table class="mytables" style="margin-top:10px ">
  <thead>
    <tr>
      <td style="background-color:#F1FD5C" colspan="8"><div align="center"><strong>Purchase</strong></div></td>
      <td style="background-color:#FC965A" colspan="3"><div align="center"><strong>Sales</strong></div></td>
      <td style="background-color:#62C6FD" colspan="3"><div align="center"><strong> Sinkage Weight & PL</strong></div></td>
    </tr>
    <tr style="font-weight:bold " >
      <td style="width:20px;background-color:#F1FD5C;"> <strong>#</strong></td>
      <td style="background-color:#F1FD5C" ><strong>SupplierName</strong></td>
      <td style="background-color:#F1FD5C" ><strong>GrnNo</strong></td>
      <td style="background-color:#F1FD5C" ><strong>Date</strong></td>
      <td style="background-color:#F1FD5C" ><strong>No Of Birds</strong></td>
      <td style="background-color:#F1FD5C" ><strong>NetValue</strong></td>
      <td style="background-color:#F1FD5C" ><strong>Amount</strong></td>
      <td style="background-color:#F1FD5C" ><strong>Expenses</strong></td>
      
      <td style="background-color:#FC965A" ><strong>No Of Birds</strong></td>
      <td style="background-color:#FC965A" ><strong>NetValue</strong></td>
      <td style="background-color:#FC965A" ><strong>Amount</strong></td>
      
       <td style="background-color:#62C6FD"  ><strong>No Of Birds</strong></td>
      <td style="background-color:#62C6FD"  ><strong>Sinkage Weight</strong></td>
      <td style="background-color:#62C6FD"  ><strong>PL</strong></td>
      
    </tr>
  </thead>
  <tbody>
    <?php
            
	$qry=" exec Rep_Sinkage '".$this->Myclass->DateSplit($_POST['FromDate'])."',
	       '".$this->Myclass->DateSplit($_POST['ToDate'])."',".Branch_Id;
		$res=$this->db->query($qry);
		$cou=1;
		$AMT=0;
		$Qty=0;$NetValue=0;$Amount=0;
		$SQty=0;$SNetValue=0;$SAmount=0;
		$TQty=0;$TNetValue=0;$TAmount=0;
		foreach($res->result() as $row)
		{
			echo '<tr   >
			<td style="background-color:#F9FFBA" >'.$cou.'</td>
			<td style="background-color:#F9FFBA">'.$row->SupplierName.'</td>
			<td style="background-color:#F9FFBA">'.$row->DcNo.'</td>
			<td style="background-color:#F9FFBA">'.$row->Date.'</td>
			<td style="background-color:#F9FFBA" align="right">'.floatval($row->Qty).'</td>
			<td style="background-color:#F9FFBA" align="right">'.floatval($row->NetValue).'</td> 
			<td style="background-color:#F9FFBA" align="right">'.floatval($row->Amount).'</td>
			<td style="background-color:#F9FFBA" align="right">'.floatval($row->Eamt).'</td>
			
			<td style="background-color:#FDD6BF" align="right">'.floatval($row->SQty).'</td>
			<td style="background-color:#FDD6BF" align="right">'.floatval($row->SNetValue).'</td> 
			<td style="background-color:#FDD6BF" align="right">'.floatval($row->SAmount).'</td>
			
			<td style="background-color:#B8E6FF" align="right">'.floatval($row->Qty-$row->SQty).' <div style="margin-bottom:0" class="progress progress-sm">
                          <div class="progress-bar progress-bar-success" style="width: '.floatval(($row->SQty/$row->Qty)*100).'%" ></div>
                        </div></td>
			<td style="background-color:#B8E6FF" align="right">'.floatval($row->NetValue-$row->SNetValue).'</td> 
			<td style="background-color:#B8E6FF" align="right">'.floatval($row->SAmount-$row->Amount).'</td>
			
			
			
			</tr>';
			$cou++;
			 
			 $Qty +=$row->Qty;$NetValue +=$row->NetValue;$Amount +=$row->Amount;
			 $SQty +=$row->SQty;$SNetValue +=$row->SNetValue;$SAmount +=$row->SAmount;
			 $TQty +=($row->Qty-$row->SQty);$TNetValue +=($row->NetValue-$row->SNetValue);$TAmount +=($row->SAmount-$row->Amount);
			 
		}
			
			?>
  </tbody>
  
  <tfoot>
  <tr style="font-weight:bold " >
      <td style="background-color:#E5E5E5;" colspan="5"> <strong>Total</strong></td>
     
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $Qty; ?></strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $NetValue; ?></strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $Amount; ?></strong></td>
      
      <td  align="right" style="background-color:#E5E5E5" ><strong><?php echo $SQty; ?></strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $SNetValue; ?></strong></td>
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $SAmount; ?></strong></td>
      
       <td align="right" style="background-color:#E5E5E5"  ><strong><?php echo $TQty; ?></strong></td>
      <td align="right" style="background-color:#E5E5E5"  ><strong><?php echo $TNetValue; ?></strong></td>
      <td align="right" style="background-color:#E5E5E5"  ><strong><?php echo $TAmount; ?></strong></td>
      
    </tr>
  
  </tfoot>
  
</table>
