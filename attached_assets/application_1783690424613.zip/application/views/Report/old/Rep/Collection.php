<?php include('head.php'); ?>
 
 <div align="center" ><font size="+2" >Collection</font> <br> From : <?php echo $_POST['FromDate']?> To : <?php echo $_POST['ToDate']?></div>
<table class="mytables" style="margin-top:10px ">
  <thead>
    
    <tr style="font-weight:bold " >
      <th style="width:20px;"> <strong>#</strong></th>
      <th  ><strong>CustomerName</strong></th>
      <th  ><strong>No</strong></th>
      <th  ><strong>Date</strong></th>
       <th  ><strong>PayMode</strong></th>
      <th  ><strong>Amount</strong></th>
     
      
    </tr>
  </thead>
  <tbody>
    <?php
            
	$qry=" exec Rep_Collection '".$this->Myclass->DateSplit($_POST['FromDate'])."',
	       '".$this->Myclass->DateSplit($_POST['ToDate'])."',".Branch_Id.",".$_POST['Customer_Id'];
		$res=$this->db->query($qry);
		$cou=1;
		$AMT=0;
		$Qty=0;$NetValue=0;$Amount=0;
		 
		foreach($res->result() as $row)
		{
			echo '<tr   >
			<td  >'.$cou.'</td>
			<td >'.$row->CustomerName.'</td>
			<td >'.$row->CollectionNo.'</td>
			<td >'.$row->Dat.'</td>
			<td >'.$row->PayMode.'</td>  
			<td  align="right">'.floatval($row->Amount).'</td>
			 
			
			
			
			</tr>';
			$cou++;
			 
		$Amount +=$row->Amount;
			 
			 
		}
			
			?>
  </tbody>
  
  <tfoot>
  <tr style="font-weight:bold " >
      <td style="background-color:#E5E5E5;" colspan="5"> <strong>Total</strong></td>
     
      <td align="right" style="background-color:#E5E5E5" ><strong><?php echo $Amount; ?></strong></td>
      
     
      
    </tr>
  
  </tfoot>
  
</table>
