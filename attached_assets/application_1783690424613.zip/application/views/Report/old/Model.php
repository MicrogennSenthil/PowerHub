<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Report','Model');
$this->pfrm->FrmHead3('Report / Model',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");
 
?>
 

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$MemberType_Id; ?>" >
      <table class="FrmTable T-4" >
        <tr>
           <td>Model</td>
            <td>
            <select type="text"   id="Product_Id" name="Product_Id"   class="scs-ctrl" >
              <option value="0" > -- Select -- </option>
              <?php
          $Res=$this->Myclass->Product();
			$count=1;
			 
		 foreach($Res as $row)
			{
			    echo '<option value="'.$row['Product_Id'].'"	 >'.$row['Product'].'</option>';
			}
		  ?>
            </select>
            </td>
        
          <td align="left"><a    class="btn btn-success btn-sm"  onClick="GetRep()"    >GET</a></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="RepDet" ></div>
</div>
 
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
 <script>
 
function GetRep()
{
	$.ajax({
		
		type:"POST",
		url:"<?php echo scs_index; ?>Rep/Model",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.RepDet').html(html);
		}
		
		
		
	})
}
</script>
 