<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Report','LetterPad');
$this->pfrm->FrmHead3('Report / LetterPad',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");
 
?>
<div class="col-sm-12">
  <div class="the-box F_ram">
   
  </div>
  <div class="RepDet" >
  
  <?php include('Rep/head.php'); ?>

   
  
  
  </div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
 