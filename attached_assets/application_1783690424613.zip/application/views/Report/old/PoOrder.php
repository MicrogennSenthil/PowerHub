<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Report','SalesOrder');
$this->pfrm->FrmHead3('Report / SalesOrder',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");
 
?>
 

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$MemberType_Id; ?>" >
      <table class="FrmTable T-8" >
        <tr>
        
        <td>From</td>
        <td> <input type="text" value="<?php echo date('d/m/Y'); ?>" name="FromDate" to="FromDate" readonly class="scs-ctrl Dat" > </td>
        
        <td>To</td>
        <td> <input type="text" value="<?php echo date('d/m/Y'); ?>" name="ToDate" to="ToDate" readonly class="scs-ctrl Dat" > </td>
        
           <td>Supplier</td>
            <td>
            <select type="text"   id="Ledger_Id" name="Ledger_Id"   class="scs-ctrl" >
              <option value="0" > -- All -- </option>
              <?php
          $Res=$this->Myclass->Supplier();
			$count=1;
			 
		 foreach($Res as $row)
			{
			    echo '<option value="'.$row['Ledger_Id'].'"	 >'.$row['LedgerName'].'</option>';
			}
		  ?>
            </select>
            </td>
            
            
           
            
            
        
          <td align="left"><a    class="btn btn-success btn-sm"  onClick="GetRep()"    >GET</a></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="RepDet" ></div>
</div>
 
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
 <script>
 
function GetRep()
{
	$.ajax({
		
		type:"POST",
		url:"<?php echo scs_index; ?>Rep/SalesOrder",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.RepDet').html(html);
		}
		
		
		
	})
}
</script>
 