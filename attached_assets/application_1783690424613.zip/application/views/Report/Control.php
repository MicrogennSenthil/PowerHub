<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Report','Control');
$this->pfrm->FrmHead3('Report / Control',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");
 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
      <table class="mytable" width="30%" >
        <thead>
          <tr>
            <th>#</th>
            <th   >FLOOR</th>
            <th  >ROOM NO</th>
            <th  >ROOM TYPE</th>
			<th>CTRL TYPE</th>
            <th>CTRL</th>
            <th>SLATE</th>
          </tr>
        </thead>
        <?php
				  $Res=$this->Myclass->Device();
				  $count=1;
				   foreach($Res as $row)
					{
						  $qry="SELECT * FROM Mas_Control mc
							   INNER JOIN Mas_room mr ON mr.Room_Id=mc.Room_Id
							   INNER JOIN Mas_roomtype ry ON ry.RoomType_Id=mr.RoomType_Id
							   INNER JOIN Mas_floor mf ON mf.Floor_Id=mr.Floor_Id
							   INNER JOIN Mas_controlType mct ON mct.ControlType_Id=mc.ControlType_Id
							   WHERE mc.Device='".$row['Device']."' ORDER BY mr.RoomNo,mc.Slate,mc.Control_Id";
					    $RM=$this->db->query($qry);
						echo '<tr><td  colspan="7" align="center" style="color:red" ><b> Device Name : '.$row['Device'].'</b></td></tr>';
						$cou=1;
						foreach($RM->result() as $R)
					           {	
							       echo '<tr>';
								   echo '<td width="10">'.$cou.'</td>';
								   echo '<td>'.$R->Floor.'</td>';
								   echo '<td>'.$R->RoomNo.'</td>';
								   echo '<td>'.$R->RoomType.'</td>';
								   echo '<td>'.$R->ControlType.'</td>';
								   echo '<td>'.$R->Control.'</td>';
								   echo '<td>'.$R->Slate.'</td>';
								   echo '</tr>';
								   $cou++;
							   }
					}
		  	   ?>
      </table>
    </fieldset>
  </div>
  <div class="RepDet" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
