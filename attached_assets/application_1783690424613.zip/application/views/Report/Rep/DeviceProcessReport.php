<?php include('head.php'); ?>
 
 <div align="center" ><font size="+2" >DeviceProcessReport</font> <br> From : <?php echo $_POST['FromDate']?> To : <?php echo $_POST['ToDate']?></div>
<table class="mytables" style="margin-top:10px ">
  <thead>
    
    <tr style="font-weight:bold " >
      <th style="width:20px;"> <strong>#</strong></th>
      <th><strong>Device</strong></th>
  	  <th><strong>S 1</strong></th>
  	  <th><strong>S 2</strong></th>    
      <th><strong>On/Off Date</strong></th>      
      <th><strong>Process</strong></th>
	  <th><strong>User</strong></th>
      <th><strong>Action</strong></th>      
    </tr>
  </thead>
  <tbody>
    <?php
            
	$qry=" exec Rep_DeviceProcessReport '".$this->Myclass->DateSplit($_POST['FromDate'])."',
	       '".$this->Myclass->DateSplit($_POST['ToDate'])."',".Hotel_Id.",".$_POST['Status_Id'];
		$res=$this->db->query($qry);
		$cou=1;
		$AMT=0;
		$Qty=0;$NetValue=0;$Amount=0;
		 
		foreach($res->result() as $row)
		{
			echo '<tr   >
			<td  >'.$cou.'</td>
			<td >'.$row->Device.'</td>
			<td >'.$row->Controlpush.'</td>
			<td >'.$row->Controlpull.'</td>			
			<td >'.$row->Rdate.'</td>			
			<td >'.$row->Status.'</td>
			<td >'.$row->UserName.'</td>			 
			<td >'.$row->Action.'</td>
			
			
			</tr>';
			$cou++;
			 
		 
			 
			 
		}
			
			?>
  </tbody>
  
  
  
</table>
