<?php include('head.php'); ?>
 
 <div align="center" ><font size="+2" >RoomProcessReport</font> <br> From : <?php echo $_POST['FromDate']?> To : <?php echo $_POST['ToDate']?></div>
<table class="mytables" style="margin-top:10px ">
  <thead>
    
    <tr style="font-weight:bold " >
      <th style="width:20px;"> <strong>#</strong></th>
      <th  ><strong>RoomNo</strong></th>
  <th  ><strong>S 1</strong></th>
  <th  ><strong>S 2</strong></th>
      <th  ><strong>CTRL</strong></th>
      <th  ><strong>SW Date</strong></th>
       <th  ><strong>On Date</strong></th>
      <th  ><strong>Off Date</strong></th>
      <th  ><strong>Duration</strong></th>
      <th  ><strong>Process</strong></th>
      <th  ><strong>Action</strong></th>
      
    </tr>
  </thead>
  <tbody>
    <?php
            
	$qry=" exec Rep_RoomProcessReport '".$this->Myclass->DateSplit($_POST['FromDate'])."',
	       '".$this->Myclass->DateSplit($_POST['ToDate'])."',".Hotel_Id.",".$_POST['Status_Id'];
		$res=$this->db->query($qry);
		$cou=1;
		$AMT=0;
		$Qty=0;$NetValue=0;$Amount=0;
		 
		foreach($res->result() as $row)
		{
			echo '<tr   >
			<td  >'.$cou.'</td>
			<td >'.$row->RoomNo.'</td>
<td >'.$row->Controlpush.'</td>
<td >'.$row->Controlpull.'</td>
			<td >'.$row->ControlType.'</td>
			<td >'.$row->Rdate.'</td>
			<td >'.$row->Recevied.'</td>  
			<td >'.$row->Ofdate.'</td>  
			<td >'.$row->Hours.':'.$row->Minutes.':'.$row->Seconds.'</td>  
			<td >'.$row->Status.'</td>
			 
			<td >'.$row->Action.'</td>
			
			
			</tr>';
			$cou++;
			 
		 
			 
			 
		}
			
			?>
  </tbody>
  
  
  
</table>
