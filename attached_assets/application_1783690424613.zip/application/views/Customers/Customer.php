<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Customer','Customer');
$this->pfrm->FrmHead1('Customer / Customer',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
   <fieldset>
      <legend>Profile Details</legend>
          <input type="hidden" name="idv" value="<?php echo @$Hotel_Id; ?>" >
          <input type="hidden" name="Logo" value="<?php echo @$Logo; ?>" >
          <input type="hidden" name="UpiId" value="<?php echo @$UpiId; ?>" >
      <table class="FrmTable T-12" >
        <tr>
          <td width="150" align="right" class=""><strong>Hotel</strong></td>
          <td align="left"><input type="text" placeholder="Hotel" id="Hotel" name="Hotel" value="<?php echo @$Hotel; ?>" class="scs-ctrl scs-txt scs-txt" />
            <div class="Hotel" ></div></td>
        
          <td  width="150" align="right" class=""><strong>Name</strong></td>
          <td align="left"><input type="text" placeholder="FirstName" id="Name" name="Name" value="<?php echo @$Name; ?>" class="scs-ctrl scs-txt" />
            <div class="Name" ></div></td>
        </tr>
        <tr>
          <td align="right" class=""><strong>Address</strong></td>
          <td align="left"><input type="text" placeholder="Address" id="Address" name="Address" value="<?php echo @$Address; ?>" class="scs-ctrl scs-txt" />
            <div class="Address" ></div></td>
         
          <td align="right" class=""><strong>City</strong></td>
          <td align="left"><input type="text" placeholder="City" id="City" name="City" value="<?php echo @$City; ?>" class="scs-ctrl scs-txt" />
            <div class="City" ></div></td>
        </tr>
        <tr>
          <td align="right" class=""><strong>PinCode</strong></td>
          <td align="left"><input type="text" placeholder="PinCode" id="PinCode" name="PinCode" value="<?php echo @$PinCode; ?>" class="scs-ctrl scs-txt" />
            <div class="PinCode" ></div></td>
         
          <td align="right" class=""><strong>Email</strong></td>
          <td align="left"><input type="text" placeholder="Email" id="Email" name="Email" value="<?php echo @$Email; ?>" class="scs-ctrl scs-txt" />
            <div class="Email" ></div></td>
        </tr>
        <tr>
          <td align="right" class=""><strong>MobileNo</strong></td>
          <td align="left"><input type="text" placeholder="MobileNo" id="MobileNo" name="MobileNo" value="<?php echo @$MobileNo; ?>" class="scs-ctrl scs-txt" />
            <div class="MobileNo" ></div></td>
      
          <td align="right" class=""><strong>Phone</strong></td>
          <td align="left"><input type="text" placeholder="Phone" id="Phone" name="Phone" value="<?php echo @$Phone; ?>" class="scs-ctrl scs-txt" />
            <div class="Phone" ></div></td>
        </tr>
         <tr>
          <td align="right" class=""><strong>WEBSITE</strong></td>
          <td align="left"><input type="text" placeholder="WEB" id="WEB" name="WEB" value="<?php echo @$WEB; ?>" class="scs-ctrl scs-txt" />
            <div class="WEB" ></div></td>
       
          <td align="right" class=""><strong>GSTIN</strong></td>
          <td align="left"><input type="text" placeholder="GST" id="GST" name="GST" value="<?php echo @$GST; ?>" class="scs-ctrl scs-txt" />
            <div class="GST" ></div></td>
        </tr>
        <tr>
        	 <td align="right" class=""><strong>Active</strong></td>
        	<td align="left">
        	<select id="Active" name="Active" class="scs-ctrl" >
        	<option value="1" >Yes</option>
       	    <option value="0" >No</option>
        	    </select>
			</td>
        </tr>
       
      </table>
    </fieldset>
    <br>
     <fieldset>
      <legend>Account Details</legend>
      <table class="FrmTable T-12" >
        <tr>
        
        <td  width="150"  align="right" class=""><strong>BankName</strong></td>
          <td align="left"><input type="text" placeholder="BankName" id="BankName" name="BankName" value="<?php echo @$BankName; ?>" class="scs-ctrl scs-txt scs-txt" />
            <div class="BankName" ></div></td>
        
          <td  width="150" align="right" class=""><strong>Branch</strong></td>
          <td align="left"><input type="text" placeholder="Branch" id="AcBranch" name="AcBranch" value="<?php echo @$AcBranch; ?>" class="scs-ctrl scs-txt" />
            <div class="AcBranch" ></div></td>
        </tr>
        
          <td  width="150"  align="right" class=""><strong>AccountName</strong></td>
          <td align="left"><input type="text" placeholder="AccountName" id="AccountName" name="AccountName" value="<?php echo @$AccountName; ?>" class="scs-ctrl scs-txt scs-txt" />
            <div class="AccountName" ></div></td>
        
          <td  width="150" align="right" class=""><strong>AccountNo</strong></td>
          <td align="left"><input type="text" placeholder="AccountNo" id="AccountNo" name="AccountNo" value="<?php echo @$AccountNo; ?>" class="scs-ctrl scs-txt" />
            <div class="AccountNo" ></div></td>
        </tr>
        
         <tr>
          <td  width="150"  align="right" class=""><strong>IFSC Code</strong></td>
          <td align="left"><input type="text" placeholder="IFSC" id="IFSC" name="IFSC" value="<?php echo @$IFSC; ?>" class="scs-ctrl scs-txt scs-txt" />
            <div class="IFSC" ></div></td>
        
          <td  width="150" align="right" class=""><strong>UPI ID</strong></td>
          <td align="left"><input type="text" placeholder="UPI" id="UPI" name="UPI" value="<?php echo @$UPI; ?>" class="scs-ctrl scs-txt" />
            <div class="UPI" ></div></td>
        </tr>
        
          
        <tr>
          <td>&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
        
        </table>
      </fieldset>
      <br>
      <div class="col-sm-4" >
      <fieldset>
      
      <legend>Logo Upload</legend>
      
        <table>
          <tr>
            <td><div class='preview'> <img src="<?php echo scs_url;?>/upload/<?php echo @$Logo; ?>.png" id="img" width="100" height="100"> </div><?php if(@$PTY==0) { ?>
              <div >
                <input type="file" id="file" name="file" />
                <input type="button" class="button" value="Upload" id="but_upload">
              </div>
              <?php } ?>
              </td>
          </tr>
        </table>
       
      </fieldset>
      </div>
      
      
      <div class="col-sm-4" >
      <fieldset>
      
      <legend>UPI QRCode Upload</legend>
      
        <table>
          <tr>
            <td><div class='preview'> <img src="<?php echo scs_url;?>/upload/<?php echo @$UpiId; ?>.png" id="imgQr" width="100" height="100"> </div><?php if(@$PTY==0) { ?>
              <div >
                <input type="file" id="fileQr" name="fileQr" />
                <input type="button" class="button" value="Upload" id="QRCode_upload">
              </div>
              <?php } ?>
              </td>
          </tr>
        </table>
       
      </fieldset>
      </div>
      
      
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
$(document).ready(function(){

            $("#QRCode_upload").click(function(){

                var fd = new FormData();

                var files = $('#fileQr')[0].files[0];

                fd.append('fileQr',files);

                $.ajax({
                    url:'<?php echo scs_url;?>uploadQr.php?Keyy=<?php echo @$UpiId; ?>',
                    type:'post',
                    data:fd,
                    contentType: false,
                    processData: false,
                    success:function(response){
                        if(response != 0){
							 
                            $("#imgQr").attr("src",'<?php echo scs_url;?>'+response);
                            $('.preview imgQr').show();
                        }else{
                            alert('File not uploaded');
                        }
                    }
                });
            });
        });
$(document).ready(function(){

            $("#but_upload").click(function(){

                var fd = new FormData();

                var files = $('#file')[0].files[0];

                fd.append('file',files);

                $.ajax({
                    url:'<?php echo scs_url;?>upload.php?Keyy=<?php echo @$Logo; ?>',
                    type:'post',
                    data:fd,
                    contentType: false,
                    processData: false,
                    success:function(response){
                        if(response != 0){
							 
                            $("#img").attr("src",'<?php echo scs_url;?>'+response);
                            $('.preview img').show();
                        }else{
                            alert('File not uploaded');
                        }
                    }
                });
            });
        });



</script>