<?php
defined( 'BASEPATH' )OR exit( 'No direct script access allowed' );
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader( $this->session );
$this->pweb->menu( $this->Menu, $this->session );
$this->pweb->Cheader( 'Customer', 'Announcement' );
$this->pfrm->FrmHead2( 'Customer / Announcement', $F_Class . "/" . $F_Ctrl, $F_Class . "/" . $F_Ctrl . "_View" );


?>

<div class="col-sm-6">
	<div class="the-box F_ram">
		<fieldset>
			<legend>Announcement</legend>

			<table class="FrmTable T-12">
				<tr>
					<td width="150" align="right" class=""><strong>Customer</strong>
					</td>
					<td align="left">
						<select class="scs-ctrl">
							<option>All</option>
						</select>
						<div class="Customer"></div>
					</td>

				</tr>
				<tr>
					<td width="150" align="right" class=""><strong>Title</strong>
					</td>
					<td align="left"><input type="text" placeholder="Title" id="Title" name="Title" value="<?php echo @$Title; ?>" class="scs-ctrl scs-txt scs-txt"/>
						<div class="Title"></div>
					</td>

				</tr>
				<tr>
					<td width="150" align="right" class=""><strong>Body</strong>
					</td>
					<td align="left"><textarea style="height: 200px" type="text" placeholder="Body" id="Body" name="Body" class="scs-ctrl scs-txt scs-txt"></textarea>
						<div class="Body"></div>
					</td>

				</tr>
				<tr><td></td>
					<td align="left"><a class="btn btn-danger btn-sm" > Send </a></td>
				</tr>

			</table>
		</fieldset>
		<br>



	</div>
	<div class="the-box D_IS"></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs( $F_Ctrl );
?>
<script>
	$( document ).ready( function () {

		$( "#QRCode_upload" ).click( function () {

			var fd = new FormData();

			var files = $( '#fileQr' )[ 0 ].files[ 0 ];

			fd.append( 'fileQr', files );

			$.ajax( {
				url: '<?php echo scs_url;?>uploadQr.php?Keyy=<?php echo @$UpiId; ?>',
				type: 'post',
				data: fd,
				contentType: false,
				processData: false,
				success: function ( response ) {
					if ( response != 0 ) {

						$( "#imgQr" ).attr( "src", '<?php echo scs_url;?>' + response );
						$( '.preview imgQr' ).show();
					} else {
						alert( 'File not uploaded' );
					}
				}
			} );
		} );
	} );
	$( document ).ready( function () {

		$( "#but_upload" ).click( function () {

			var fd = new FormData();

			var files = $( '#file' )[ 0 ].files[ 0 ];

			fd.append( 'file', files );

			$.ajax( {
				url: '<?php echo scs_url;?>upload.php?Keyy=<?php echo @$Logo; ?>',
				type: 'post',
				data: fd,
				contentType: false,
				processData: false,
				success: function ( response ) {
					if ( response != 0 ) {

						$( "#img" ).attr( "src", '<?php echo scs_url;?>' + response );
						$( '.preview img' ).show();
					} else {
						alert( 'File not uploaded' );
					}
				}
			} );
		} );
	} );
</script>