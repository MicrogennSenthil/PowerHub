 <?php
 $qry=" Set_UserMenu '".$_POST['UID']."','".$_POST['MID']."'";
 $Res=$this->db->query($qry);
 
 ?>
 <br>
 <div class="T-6" >
 <table class="mytable ">
 <thead>
 <tr>
 <th width="50">Sno</th>
 <th>Menu</th>
 <th width="100">Active</th>
 </tr>
 </thead>
  <tbody>
  <?php
  $cou=1;
  foreach($Res->result() as $row)
  {
	  $chk="";
	 if($row->USHOW==1){ $chk="checked"; } 
    echo '<tr>
	      <td>'.$cou.'</td>
          <td>'.$row->SubMenu.' <div class="msgg'.$row->RG_ID.' pull-right" ></div></td>
	      <td align="center"><input '.$chk.' type="checkbox" onclick="Update_User(this.checked,'.$row->RG_ID.')"  /></td>
          </tr>';
	
	$cou++;
  }
  ?>
  </tbody>
  
</table>
</div>
<script>

function Update_User(ee,MID)
{
	$('.msgg'+MID).html('Please Wait...');
	$.ajax({
		type:"POST",
		url:"<?php echo scs_index;?>setting/UpdateUser",
		data:"val="+ee+"&MID="+MID,
		success: function(html)
		{
			$('.msgg'+MID).html(html);
		}
	})
}

</script>