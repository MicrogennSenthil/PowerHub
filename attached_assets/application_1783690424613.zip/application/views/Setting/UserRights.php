<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Setting','UserRights');
$this->pfrm->FrmHead1('Setting / UserRights',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$Userid; ?>" >
      <table class="FrmTable T-6" >
        <tr>
          <td align="right" class="F_val">User Group</td>
          <td align="left"><select id="EmailId" name="EmailId"   class="scs-ctrl"  >
          <?php
          $res=$this->Myclass->UserGroup();
		  foreach($res as $row)
		  {
			 echo '<option value="'.$row['Group_Id'].'" >'.$row['UserGroup'].'</option>';  
		  }
		  
		  ?>
          
          </select>
            <div class="EmailId" ></div></td>            
             <td align="right" class="F_val">Menu</td>
             <td align="left"><select id="Menu" name="Menu"   class="scs-ctrl"  >
          <?php
          $res=$this->Myclass->Menu();
		  foreach($res as $row)
		  {
			 echo '<option value="'.$row['Menu_Id'].'" >'.$row['Menu'].'</option>';  
		  }
		  
		  ?>
          
          </select>
            </td>
            
            <td><a onClick="UserRight()" class="btn btn-sm btn-success" >Get</a> </td>
        </tr>
        
      
    
         
      </table>
    </fieldset>
  </div>
  <div class="Ress" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
 

function UserRight()
{
	$.ajax({
		type:"POST",
		url:"<?php echo scs_index;?>setting/getuser",
		data:"UID="+$('#EmailId').val()+"&MID="+$('#Menu').val(),
		success: function(html)
		{
			$('.Ress').html(html);
		}
	})
}
</script>
