<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
 
$this->pfrm->FrmHead2('Master / Mobile Device active',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

?>

 
    <div class="table-responsive">
      <table class="table table-bordered table-hover table-striped mydatatable"  id="example1">
        <thead  >
          <tr>
            <th>Sno</th>
            <th>MobileNo</th>
            <th>Mobile ID</th>
			<th>Status</th>
            <th style="width:160px !important" align="center" > <div align="center" >Action</div></th>
          </tr>
        </thead>
        <tbody>
          <?php 
			$Res=$this->Myclass->Regester();
			$count=1;
			 
		 foreach($Res as $row)
			{ 
               echo  '<tr class="odd gradeX">
                      <td>'.$count.' </td>
                      <td>'.$row['MobileNo'].'</td>
					  <td>'.$row['MobileID'].'</td>
					  <td width="64" ><img src="'.scs_url.$row['Active'].'.png" ></td>
					  	 
                      <td  align="center" > ';
					  
					  if($row['Active']==0)
					  {
					echo '  <a class="btn btn-success btn-xs" href="'.scs_index.$F_Class."/Regestermn/".$row['Regester_Id'].'/Active"   >
					  <i class="fa fa-edit"></i> Active</a>  ';
					  }
					  else
					  {
					  
					 echo ' <a class="btn btn-danger btn-xs" href="'.scs_index.$F_Class."/Regestermn/".$row['Regester_Id'].'/DeActive"   >
					  <i class="fa fa-trash"></i> DeActive</a> ';
					  }
					  
					 echo '</td></tr>';
                 
                 
                
				 $count++;
              
			}
			 ?>
        </tbody>
      </table>
   
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
