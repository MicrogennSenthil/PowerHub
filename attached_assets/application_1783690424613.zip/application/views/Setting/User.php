<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Setting','User');

$this->pfrm->FrmHead1('Setting / User',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$UserId; ?>" >
      <table class="FrmTable T-4" >
        <tr>
          <td align="right" class="F_val">User Id</td>
          <td align="left"><input type="text" <?php if($MOD==1){ echo 'readonly'; } ?>   placeholder="User Id" id="UserName" name="UserName" value="<?php echo @$UserName; ?>" class="scs-ctrl" />
            <div class="UserName" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">Password</td>
          <td align="left"><input type="password" placeholder="Password" id="Password" value="<?php echo @$Password; ?>" name="Password" class="scs-ctrl" />
            <div class="Password" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">UserGroup</td>
          <td align="left"><select name="UserGroup" id="UserGroup"  class="scs-ctrl"   >
          <option value="" > -- Select UserGroup -- </option>
              <?php
				  $Res=$this->Myclass->UserGroup();
				  $count=1;
				   foreach($Res as $row)
					{
						echo '<option value="'.$row['Group_Id'].'">'.$row['UserGroup'].'</option>';
					}
		  	   ?>
          </select>
            <div class="UserGroup" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">Enable ON/OFF Operation</td>
          <td align="left"><select name="EnableONOFFoperation" id="EnableONOFFoperation"  class="scs-ctrl"   >
          <option value="1" >Yes</option>
           <option value="2" >No</option>
          </select>
            <div class="EnableONOFFoperation" ></div></td>
        </tr>   
        <tr>
          <td align="right" class="F_val">Active</td>
          <td align="left"><select name="Active" id="Active"  class="scs-ctrl"   >
          <option value="1" >Yes</option>
           <option value="2" >No</option>
          </select>
            <div class="Active" ></div></td>
        </tr>   
    
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
$(document).ready(function(e) {

	<?php if($BUT=="DELETE")
	{
	  echo "$('.scs-ctrl').attr('readonly','readonly')";
	}
  else if($BUT=="UPDATE")
  { ?>
    $("#Active").val('<?php echo @$Active; ?>');
    $("#UserGroup").val('<?php echo @$UserGroup; ?>');
    $("#EnableONOFFoperation").val('<?php echo @$EnableONOFFoperation; ?>');
    <?php 
  }
	if($MOD==1){ 
	   echo "$('.box-header').hide()";
	
	 }
	
	?>
	
	
});
</script>
