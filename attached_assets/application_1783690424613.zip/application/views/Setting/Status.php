<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
//$this->pweb->Cheader('Master','ControlType');
$this->pfrm->FrmHead1('Master / Status',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$Status_Id; ?>" >
      <table class="FrmTable T-4" >
        
        
         <tr>
          <td align="right" class="F_val">Status</td>
          <td align="left"><input type="text" placeholder="Status Name" id="Status" name="Status" value="<?php echo @$Status; ?>" class="scs-ctrl" />
            <div class="Status" ></div></td>
        </tr>
         <tr>
         <td align="right" class="F_val">IsProcess</td>
          <td>
		  
		  <select  type="text" id="Flag" name="Flag"   class="scs-ctrl" > 
		  <option value="0" >No</option> <option value="1" >Yes</option>
		  </select>
		  </td>
		  </tr>
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
 $(document).ready(function(e) {
    $('#Flag').val(<?php echo @$Flag; ?>);
});
</script>