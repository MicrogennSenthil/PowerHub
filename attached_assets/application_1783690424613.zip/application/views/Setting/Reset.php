<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
//$this->pweb->Cheader('Master','ControlType');
$this->pfrm->FrmHead2('Master / Reset',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$Status_Id; ?>" >
      <table class="FrmTable T-4" >
        
        
         <tr>
          <td align="right" class="F_val"> </td>
          <td align="left">
		  <input type="checkbox"   id="Status" name="Status"   /> Agree
            <div class="Status" ></div></td>
        </tr>
         
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><a  class="btn btn-success btn-sm"  onclick="Reset_()"    > Reset</a></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
 $(document).ready(function(e) {
    $('#Flag').val(<?php echo @$Flag; ?>);
});
function Reset_()
{
	if($('#Status').prop('checked')==true) { 
     
	 $.ajax({
		
		type:"POST",
		url:"<?php echo scs_index; ?>Api/PowerRest",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.RepDet').html(html);
		}
		
		
		
	})

	}
}
</script>