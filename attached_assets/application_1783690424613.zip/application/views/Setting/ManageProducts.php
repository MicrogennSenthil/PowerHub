<?php
defined( 'BASEPATH' )OR exit( 'No direct script access allowed' );
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader( $this->session );
$this->pweb->menu( $this->Menu, $this->session );
$this->pweb->Cheader( 'Setting', 'Manage Products' );

$this->pfrm->FrmHead2( 'Setting / Manage Products', $F_Class . "/" . $F_Ctrl, $F_Class . "/" . $F_Ctrl . "_View" );


?>
<style>
	.scs-ctrl {
		color: #000000;
		font-weight: bold
	}
</style>

<div class="col-sm-7">
	<div class="the-box F_ram">

		<table class="mytable" style="font-size: 13px">
			<thead>
				<tr>
					<th>#</th>
					<th>Pricing</th>
					<th width="200">Add</th>
					<th width="200">Renew</th>
				</tr>
			</thead>
			<tbody>
			<?php
				
				$qry="SELECT * FROM Mas_Price";
				$res=$this->db->query($qry);
				$cou=1;
				foreach($res->result() as $row)
				{
			?>
			<input type="hidden" name="Price_Id[]" value="<?php echo $row->Price_Id; ?>" >
				<tr style="font-weight: normal;color:#B5B5B5">
					<td><?php echo $cou; ?></td>
					<td style="color: #000000"><strong><?php echo $row->Price; ?></strong>
					</td>
					<td align="center">Per Control<br>
						<input name="Rate[]" value="<?php echo floatval($row->Rate); ?>" type="text" style="width:100px" class="scs-ctrl" num=1><br> <?php echo $row->Month; ?> Months<br><?php echo $row->Rate; ?>
					</td>

					<td align="center">Per Control<br>
						<input name="Renew[]" value="<?php echo floatval($row->Renew); ?>" type="text" style="width:100px" class="scs-ctrl" num=1><br> <?php echo $row->Month; ?> Months<br><?php echo $row->Renew; ?>
					</td>

				</tr>

			 <?php $cou++; } ?>



			</tbody>
			<tfoot>
				<tr>
					<td colspan="5" align="right" ><samp class="RepDet" ></samp><a class="btn btn-success btn-sm" onClick="RateUpdate()" > Update </a></td>
				</tr>
			</tfoot>
		</table>

	</div>
	<div class="the-box D_IS"></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs( @$F_Ctrl );
?>
<script>
function RateUpdate()
	{
		$.ajax({
		type:"POST",
		url:"<?php echo scs_index; ?>Setting/RateUpdate",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.RepDet').html(html);
		}
		})
	}
</script>