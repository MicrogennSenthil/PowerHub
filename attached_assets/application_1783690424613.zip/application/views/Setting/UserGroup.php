<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Setting','User Group');
$this->pfrm->FrmHead1('Setting / User Group',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$Group_Id; ?>" >
      <table class="FrmTable T-4" >
        <tr>
          <td align="right" class="F_val">User Group</td>
          <td align="left"><input type="text" <?php if($MOD==1){ echo 'readonly'; } ?>   placeholder="User Group" id="UserGroup" name="UserGroup" value="<?php echo @$UserGroup; ?>" class="scs-ctrl" />
            <div class="UserGroup" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">Active</td>
          <td align="left"><select name="Active" id="Active"  class="scs-ctrl"   >
          <option value="1" >Yes</option>
           <option value="2" >No</option>
          </select>
            <div class="Active" ></div></td>
        </tr>        
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
$(document).ready(function(e) {

	<?php if($BUT=="DELETE")
	{
	  echo "$('.scs-ctrl').attr('readonly','readonly')";
	}
  else if($BUT=="UPDATE")
  { ?>
    $("#Active").val('<?php echo @$Active; ?>');    
    <?php 
  }
	if($MOD==1){ 
	   echo "$('.box-header').hide()";	
	 }
	
	?>
	
	
});
</script>
