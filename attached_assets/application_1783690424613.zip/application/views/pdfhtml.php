<?php
require_once 'dompdf/autoload.inc.php';
use Dompdf\Dompdf;
 
$dompdf = new Dompdf();
$dompdf->loadHtml(base64_decode($pdfhtml));
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();
$dompdf->stream($_POST['RTitle'].".pdf");