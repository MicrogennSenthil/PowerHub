 
 <?php
	
	$Res='select * from Mas_Device where Hotel_Id='.$Hotel_Id;
    $Res=$this->db->query($Res);
	foreach($Res->result_array() as $row)
			{
				?>
				
				<table class="sertable" >
					<thead>
					<tr><th style="background-color:#34495e;
					" colspan="4" ><div style="color:#FFFFFF" align="center"><?php echo $row['Device'];?></div></th></tr>
					<tr style="background-color:#34495e;color: #FFFFFF
						">
						<th  colspan="2"><div align="center">Slate 1</div> </th>
						<th  colspan="2"><div align="center">Slate 2</div> </th>
					</tr>
						<tr style="background-color:#34495e;color: #FFFFFF
						">
							<th style="color:#FFFFFF">Control</th>
							<th style="color:#FFFFFF">Status</th>
							<th style="color:#FFFFFF">Control</th>
							<th style="color:#FFFFFF">Status</th>
						</tr>
					</thead>
					<tbody>
						<?php
						$qry=" SELECT a.Control AC,isnull(a.State,0) ASS,b.Control BC,isnull(b.State,0) BS FROM MC1 a, MC2 b
WHERE a.Control=b.Control AND a.Device=b.Device and a.Device='".$row['Device']."' ORDER BY a.Control ";
						$Rm=$this->db->query($qry);
						foreach($Rm->result() as $R)
						{
							echo '<tr>';
							echo '<td align="center" >'.$R->AC.'</td>';
						 
							echo '<td align="center" > <img src="'.scs_url.'power/icon/'.$R->ASS.'l.png" > </td>';
							echo '<td align="center" >'.$R->BC.'</td>';
						 
							echo '<td align="center" > <img src="'.scs_url.'power/icon/'.$R->BS.'l.png" > </td>';
							echo '<tr>';
						}
						?>
					</tbody>
				</table>

				<?php
			}
	
	?>