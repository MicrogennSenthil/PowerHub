<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
//$this->pweb->Cheader('Master','Room');
$this->pfrm->FrmHead1('Master / Room',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
      <input type="hidden" name="idv" value="<?php echo @$Room_Id; ?>" >
      <table class="FrmTable T-4" >
        <tr>
          <td align="right" class="F_val">Room</td>
          <td align="left"><input type="text" placeholder="Room No" id="RoomNo" name="RoomNo" value="<?php echo @$RoomNo; ?>" class="scs-ctrl" />
            <div class="RoomNo" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">Block</td>
          <td align="left"><select type="text" id="Block_Id" name="Block_Id" class="scs-ctrl" style="width:100%">
              <option value="" > -- Select Block -- </option>
              <?php
				  $Res=$this->Myclass->Block();
				  $count=1;
				   foreach($Res as $row)
					{
						echo '<option value="'.$row['Block_Id'].'">'.$row['Block'].'</option>';
					}
		  	   ?>
            </select>
            <div class="Block_Id" ></div></td>
        </tr>
         <tr>
          <td align="right" class="F_val">Floor</td>
          <td align="left"><select type="text" id="Floor_Id" name="Floor_Id" class="scs-ctrl" style="width:100%">
              <option value="" > -- Select Floor -- </option>
              <?php
				  $Res=$this->Myclass->Floor();
				  $count=1;
				   foreach($Res as $row)
					{
						echo '<option value="'.$row['Floor_Id'].'">'.$row['Floor'].'</option>';
					}
		  	   ?>
            </select>
            <div class="Floor_Id" ></div></td>
        </tr>
           <tr>
          <td align="right" class="F_val">RoomType</td>
          <td align="left"><select type="text" id="RoomType_Id" name="RoomType_Id" class="scs-ctrl" style="width:100%">
              <option value="" > -- Select RoomType -- </option>
              <?php
				  $Res=$this->Myclass->RoomType();
				  $count=1;
				   foreach($Res as $row)
					{
						echo '<option value="'.$row['RoomType_Id'].'">'.$row['RoomType'].'</option>';
					}
		  	   ?>
            </select>
            <div class="RoomType_Id" ></div></td>
        </tr>
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
 $(document).ready(function(e) {
    $('#Floor_Id').val(<?php echo @$Floor_Id; ?>);
	$('#Block_Id').val(<?php echo @$Block_Id; ?>);
	$('#RoomType_Id').val(<?php echo @$RoomType_Id; ?>);
});
</script>