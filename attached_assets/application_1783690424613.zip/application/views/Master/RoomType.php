<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
//$this->pweb->Cheader('Master','RoomType');
$this->pfrm->FrmHead1('Master / RoomType',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$RoomType_Id; ?>" >
      <table class="FrmTable T-4" >
        
        
         <tr>
          <td align="right" class="F_val">RoomType</td>
          <td align="left"><input type="text" placeholder="RoomType Name" id="RoomType" name="RoomType" value="<?php echo @$RoomType; ?>" class="scs-ctrl" />
            <div class="RoomType" ></div></td>
        </tr>
        
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
 $(document).ready(function(e) {
    $('#Type_Id').val(<?php echo @$Type_Id; ?>);
});
</script>