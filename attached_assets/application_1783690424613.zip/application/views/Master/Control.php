<?php
defined( 'BASEPATH' )OR exit( 'No direct script access allowed' );
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader( $this->session );
$this->pweb->menu( $this->Menu, $this->session );
//$this->pweb->Cheader('Master','Control');
$this->pfrm->FrmHead2( 'Master / Control', $F_Class . "/" . $F_Ctrl, $F_Class . "/" . $F_Ctrl . "_View" );
					 
?>

<div class="col-sm-12">
	<div class="the-box F_ram">
	

			<ul class="nav nav-tabs">
			<?php
				$Res=$this->Myclass->Device();
			$count=1;
			 $active='active';
			 $DID='';
		 foreach($Res as $row)
			{ 
			    if($DID==''){ $DID=$row['Device']; }
				echo '<li class="'.$active.' '.$row['Device'].' Device">
				<a class="btn "  onclick="Device_(&#39;'.$row['Device'].'&#39;)"  >'.$row['Device'].'</a> </li>';
				$active='';
				
				  $qru="exec AddCtrl ".Hotel_Id.",'".$row['Device']."'";
	$this->db->query($qru);	
			}
			?>
		 </ul>
		 	<fieldset>
		 <table class="mytable " style="padding: 10px"  id="sortable">
        <thead>
          <tr>
            <th>#</th>
			
            <th width="100"  >FLOOR</th>
            <th width="150"  >ROOM Type</th>
            <th  >ROOM NO</th>
            <th  >ControlType</th>
            <th>CTRL (Realy)</th>
            <th>SLATE (Board)</th>
            <th>Action</th>
			<th width="200" >Status</th>
          </tr>
        </thead>
		<?php
				  $Res=$this->Myclass->Device();
				  $count=1;
				   foreach($Res as $row)
					{
						 $qry="SELECT * FROM Mas_Control mc
							   left outer JOIN Mas_room mr ON mr.Room_Id=mc.Room_Id
							   left outer JOIN Mas_roomtype ry ON ry.RoomType_Id=mr.RoomType_Id
							   left outer JOIN Mas_floor mf ON mf.Floor_Id=mr.Floor_Id
							   WHERE mc.Device='".$row['Device']."' ORDER BY mc.Slate,mc.Control_Id";
					    $RM=$this->db->query($qry);
						$tractive=' '; 
						$cou=1;
						foreach($RM->result() as $R)
					           {	
							   
							     echo '<tr style="'.$tractive.'" class="'.$row['Device'].' CDevice" >';
								   echo '<td width="10">'.$cou.'</td>';
							   
							   
							      echo '<input type="hidden"  name="Device'.$R->Control_Id.'" value="'.$row['Device'].'" />';
							     
								   echo '<td class="FLO'.$R->Control_Id.'" >'.$R->Floor.'</td>';
								  echo '<td class="RTP'.$R->Control_Id.'" >'.$R->RoomType.'</td>';
								    echo '<td><select type="text" id="Room_Id'.$R->Control_Id.'" name="Room_Id'.$R->Control_Id.'" onchange="Rm_('.$R->Control_Id.')"  class="scs-ctrl" style="width:100%">
							<option value="0"> -- Select -- </option>';	
								   $Room = $this->Myclass->Room();
									foreach ( $Room as $Crow ) {
										$selected='';
										if($R->Room_Id==$Crow[ 'Room_Id' ])
										{
											$selected='selected';
										}
										 echo '<option RoomType="'. $Crow[ 'RoomType' ] .'" Floor="'. $Crow[ 'Floor' ] .'" '.$selected.' value="' . $Crow[ 'Room_Id' ] . '">' . $Crow[ 'RoomNo' ] . '</option>';
									}
								   echo '</select></td>';
								   
								   echo '<td> <select type="text" name="ControlType_Id'.$R->Control_Id.'"   class="scs-ctrl" style="width:100%">
							<option value="0"> -- Select -- </option>';	
								   $ControlType = $this->Myclass->ControlType();
									foreach ( $ControlType as $Crow ) {
										$selected='';
										if($R->ControlType_Id==$Crow[ 'ControlType_Id' ])
										{
											$selected='selected';
										}
										 echo '<option '.$selected.' value="' . $Crow[ 'ControlType_Id' ] . '">' . $Crow[ 'ControlType' ] . '</option>';
									}
								   echo '</select></td>';
								   
								 
								   echo '<td> <input readonly type="text" name="Control'.$R->Control_Id.'" value="'.$R->Control.'"  class="scs-ctrl" style="width:100%">
										</td>';
								   
								   $Board='';
								   if($R->Slate==1) {$Board='First Board'; }
								   else
								   {  $Board='Second Board';			   }
								   echo '<td align="center" >	
								   <input type="hidden" name="Slate'.$R->Control_Id.'" value="'.$R->Slate.'" >						 	
								   <input type="text" readonly class="scs-ctrl"  value="'.$Board.'" >						 
								    </td>';
								   echo '<td align="center" ><a class="btn btn-success btn-sm" onclick="UpdateCtrl('.$R->Control_Id.')" >Update</a></td>';
									echo '<td class="STA'.$R->Control_Id.' STAERR" > </td>';								  
								  echo '</tr>';
								   $cou++;
							   }
						$tractive='display: none;'; 
					}
		  	   ?>
 </table>
			 
		</fieldset>
	</div>
	<div class="the-box ErrMsg"></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs( $F_Ctrl );
?>
<script type="text/javascript">
  $(document).ready(function(){
    $('#sortable').dataTable({
        'iDisplayLength': 100
    })})
</script>
<script>



	$( document ).ready( function ( e ) {
		  Device_('<?php echo $DID; ?>');
		  
	} );
	
	function Device_(Cla)
	{
		$('.Device').removeClass('active');
	    $('.CDevice').hide();
		$('.'+Cla).addClass('active');
		$('.'+Cla).show();
	}
	function Rm_(ee)
	{
		 
		 $('.FLO'+ee).html($('#Room_Id'+ee+' option:selected').attr('floor'));
		  $('.RTP'+ee).html($('#Room_Id'+ee+' option:selected').attr('RoomType'));
	}
	function UpdateCtrl(ee)
	{
		$('.STA'+ee).html('<i class="fa fa-spinner fa-spin fa-1x fa-fw"></i>');
		$.ajax({
		
		type:"POST",
		url:"<?php echo scs_index; ?>Master/UpdateCtrl/"+ee,
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			  $('.STAERR').html('');
			  $('.STA'+ee).html(html);
		}
		
		
		
	   })
	}
</script>