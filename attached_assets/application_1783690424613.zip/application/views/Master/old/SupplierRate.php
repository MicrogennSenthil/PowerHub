<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
//$this->pweb->Cheader('Master','Company');
$this->pfrm->FrmHead2('Master / Company',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>
 

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
      <input type="hidden" name="idv" value="<?php echo @$Company_Id; ?>" >
      <input type="hidden" name="key" value="<?php echo rand().rand().rand(); ?>" >
      <table class="FrmTable T-4" >
        <tr>
          <td align="right" class="F_val">Supplier</td>
          <td align="left"><select class="scs-ctrl mysel" name="Supplier_Id" id="Supplier_Id" onChange="Supplier_Rate()" >
              <option value="" >Select</option>
              <?php
          
		  $Res=$this->Myclass->Supplier();
		  $count=1;
		 foreach($Res as $row)
			{
				echo '<option value="'.$row['Supplier_Id'].'" >'.$row['SupplierName'].'</option>';
			}
		  
		  ?>
            </select>
            <div class="CompanyName" ></div></td>
        </tr>
      </table>
    </fieldset>
    <fieldset>
      <table class="  mytable" >
        <thead>
          <tr>
            <th width="25">Sno</th>
            <th width="90" >CatNo</th>
            <th>ItemName</th>
            <th width="70" >Uom</th>
            <th width="170" >Rate</th>
            <th  width="50">#</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td  ><input type="text" class="f-ctrl" name="Sno" ></td>
            <td><input readonly type="text" class="f-ctrl" name="CatNo" id="CatNo" ></td>
            <td><div class="ui-widget"><input type="text" class="f-ctrl" name="Item" id="Item" >
            <input type="hidden" class="f-ctrl" name="Item_Id" id="Item_Id" >
            </div></td>
            <td ><input readonly type="text" class="f-ctrl" name="Uom"  id="Uom" ></td>
            <td><input type="text" class="f-ctrl" name="Rate"  id="Rate" num=1 ></td>
            <td align="center"> <a onClick="ItemAdd()" class="btn btn-success btn-xs" ><i class="fa fa-plus" ></i> Add</a> </td>
          </tr>
        </tbody>
        <tbody class="ItemAdd">
        
        </tbody>
        <tfoot>
        <tr><td class="Loading" colspan="9"  ></td></tr>
        </tfoot>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
var Supplier_Id=1
 function Supplier_Rate()
 {
	 $.ajax({
		
		type:"POST",
		url:"<?php echo scs_index; ?>Master/ItemGet",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.ItemAdd').html(html);
			$('.Loading').html(''); 
			  $("#Item").val('');
	         $("#CatNo").val('');
		    $("#Uom").val('');
		    $("#Item_Id").val('');
			$('#Item').focus();
		}	
	})
 }
 function ItemAdd()
{
	$('.Loading').html('<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>');
	$.ajax({
		
		type:"POST",
		url:"<?php echo scs_index; ?>Master/ItemAdd",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.ItemAdd').html(html);
			$('.Loading').html(''); 
			  $("#Item").val('');
	    $("#CatNo").val('');
		$("#Uom").val('');
		$("#Rate").val(0);
		$("#Item_Id").val('');
			$('#Item').focus();
		}	
	})
}
 
function ItemDel(ee)
{
	$('.Loading').html('<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>');
	$.ajax({
		
		type:"POST",
		url:"<?php echo scs_index; ?>Master/ItemDel/"+ee,
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.ItemAdd').html(html);
			$('.Loading').html(''); 
			
		}	
	})
}
   
    $( "#Item" ).autocomplete({
      source: "<?php echo scs_index; ?>Auto_c/SupItem?Supplier_Id="+Supplier_Id,
      minLength: 2,
      select: function( event, ui ) {
        $("#Item").val(ui.item.Item);
	    $("#CatNo").val(ui.item.CatNo);
		$("#Uom").val(ui.item.Symbol);
		$("#Item_Id").val(ui.item.Item_Id);
		$('#Rate').focus();
      }
    });
 </script> 
