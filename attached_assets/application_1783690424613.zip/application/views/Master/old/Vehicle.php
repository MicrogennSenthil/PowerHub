<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
//$this->pweb->Cheader('Master','Vehicle');
$this->pfrm->FrmHead1('Master / Vehicle',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");


?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
      <input type="hidden" name="idv" value="<?php echo @$Vehicle_Id; ?>" >
      <table class="FrmTable T-4" >
        <tr>
          <td align="right" class="F_val">Vehicle</td>
          <td align="left"><input type="text" placeholder="Vehicle Name" id="Vehicle" name="Vehicle" value="<?php echo @$Vehicle; ?>" class="scs-ctrl" />
            <div class="Vehicle" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">VehicleNo</td>
          <td align="left"><input type="text" placeholder="VehicleNo" id="VehicleNo" name="VehicleNo" value="<?php echo @$VehicleNo; ?>" class="scs-ctrl" />
            <div class="VehicleNo" ></div></td>
        </tr>
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
