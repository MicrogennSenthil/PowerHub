<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
 
$this->pfrm->FrmHead1('Master / Product',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

?>

 
    <div class="table-responsive">
      <table class="table table-bordered table-hover"  id="example1">
        <thead  >
          <tr>
            <th>Sno</th>
            <th>Productname</th>
            <th>CatNo</th>
            <th>RefNo</th>
            <th>HSNCode</th>
        
            <th>Active</th>
          
            <th style="width:100px !important" align="center" >Edit</th>
          </tr>
        </thead>
        <tbody>
          <?php 
			$Res=$this->Myclass->Item();
			$count=1;
			 
		 foreach($Res as $row)
			{
				 $act='<i style="font-size:24px;color:red" class="fa fa-check-circle-o" aria-hidden="true"></i>';
				if($row['Active']==1)
				{
					$act='<i style="font-size:24px;color:green" class="fa fa-check-circle-o" aria-hidden="true"></i>';
				}
               echo  '<tr class="odd gradeX">
                      <td>'.$count.' </td>
                      <td>'.$row['ItemName'].'</td>
					  <td>'.$row['CatNo'].'</td>
					  <td>'.$row['RefNo'].'</td>
					  <td>'.$row['HSNCode'].'</td>
				 
					  <td>'. $act.'</td>				   
				 				  	 
                      <td>
					  <a class="btn btn-warning btn-xs" href="'.scs_index.$F_Class."/".$F_Ctrl."/".$row['Item_Id'].'/UPDATE"   >
					  <i class="fa fa-edit"></i> Edit</a> | 
					   <a class="btn btn-danger btn-xs" href="'.scs_index.$F_Class."/".$F_Ctrl."/".$row['Item_Id'].'/DELETE"   >
					  <i class="fa fa-trash"></i> Delete</a>
					  
					  </td>
                      
                      </tr>';
                 
                 
                
				 $count++;
              
			}
			 ?>
        </tbody>
      </table>
   
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
