<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
 
$this->pfrm->FrmHead1('Master / Product',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");


?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
      <legend>Product Details</legend>
      <input type="hidden" name="idv" value="<?php echo @$Item_Id; ?>" >
      <table class="FrmTable T-8" >
        
        <tr>
          <td align="right" >HSNCode</td>
          <td align="left"><input type="text" placeholder="HSNCode" id="HSNCode" name="HSNCode" value="<?php echo @$HSNCode; ?>" class="scs-ctrl" />
            <div class="HSNCode" ></div></td>
          <td align="right" class="F_val" >ItemName</td>
          <td align="left"><input type="text" placeholder="ItemName" id="ItemName" name="ItemName" value="<?php echo @$ItemName; ?>" class="scs-ctrl" />
            <div class="ItemName" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">Category</td>
          <td align="left"><select type="text" id="Category_Id" name="Category_Id" class="scs-ctrl" style="width:100%">
              <option value="" > -- Select ItemCategory -- </option>
              <?php
				  $Res=$this->Myclass->Category();
				  $count=1;
				   foreach($Res as $row)
					{
						echo '<option value="'.$row['Category_Id'].'">'.$row['CategoryName'].'</option>';
					}
		  	   ?>
            </select>
            <div class="Category_Id" ></div></td>
          <td align="right" class="F_val">Unit</td>
          <td align="left"><select type="text" id="Unit_Id" name="Unit_Id" class="scs-ctrl" style="width:100%">
              <option value="" > -- Select Unit -- </option>
              <?php
				  $Res=$this->Myclass->Unit();
				  $count=1;
				   foreach($Res as $row)
					{
						echo '<option value="'.$row['Unit_Id'].'">'.$row['Symbol'].'</option>';
					}
		  	   ?>
            </select>
            <div class="Unit_Id" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">Group</td>
          <td align="left"><select type="text" id="Group_Id" name="Group_Id" class="scs-ctrl" style="width:100%">
              <option value="" > -- Select ItemGroup -- </option>
              <?php
				  $Res=$this->Myclass->Group();
				  $count=1;
				   foreach($Res as $row)
					{
						echo '<option value="'.$row['Group_Id'].'">'.$row['GroupName'].'</option>';
					}
		  	   ?>
            </select>
            <div class="Group_Id" ></div></td>
          <td align="right" class="F_val">TaxSetup</td>
          <td align="left"><select type="text" id="TaxSetup_Id" name="TaxSetup_Id" class="scs-ctrl" style="width:100%">
              <option value="" > -- Select Unit -- </option>
              <?php
				  $Res=$this->Myclass->TaxSetup();
				  $count=1;
				   foreach($Res as $row)
					{
						echo '<option value="'.$row['TaxSetup_Id'].'">'.$row['TaxSetup'].'</option>';
					}
		  	   ?>
            </select>
            <div class="TaxSetup_Id" ></div></td>
        </tr>
      </table>
    </fieldset>
    <br>
    <input type="hidden"  id="Alias" name="Alias" value="<?php echo @$Alias; ?>" class="scs-ctrl" />
    <fieldset>
      <legend>Other Details</legend>
      <table class="FrmTable T-8" >
        <tr>
          <td align="right"  >Pur Rate</td>
          <td align="left"><input type="text" num="1"   id="PRate" name="PRate" value="<?php echo @$PRate; ?>" class="scs-ctrl" />
            <div class="PRate" ></div></td>
          <td align="right"  >Sal Rate </td>
          <td align="left"><input type="text"  num=1 id="SRate" name="SRate" value="<?php echo @$SRate; ?>" class="scs-ctrl" />
            <div class="SRate" ></div></td>
        </tr>
        <tr>
          <td align="right"  >ReOrder</td>
          <td align="left"><input type="text" num="1" placeholder="ReOrder" id="ReOrder" name="ReOrder" value="<?php echo @$ReOrder; ?>" class="scs-ctrl" />
            <div class="ReOrder" ></div></td>
          <td align="right"  >MRP</td>
          <td align="left"><input type="text" num="1"  id="MRP" name="MRP" value="<?php echo @$MRP; ?>" class="scs-ctrl" />
            <div class="MRP" ></div></td>
        </tr>
        <tr>
          <td align="right"  >Discount</td>
          <td align="left"><input type="text" num="1"  id="Discount" name="Discount" value="<?php echo @$Discount; ?>" class="scs-ctrl" />
            <div class="Discount" ></div></td>
          <td align="right"  >OrederItem</td>
          <td align="left"><input type="text" num="1"  id="OrederItem" name="OrederItem" value="<?php echo @$OrederItem; ?>" class="scs-ctrl" />
            <div class="OrederItem" ></div></td>
        </tr>
        <tr>
          <td align="right"  >MinOrd</td>
          <td align="left"><input type="text" num="1"  id="MinOrd" name="MinOrd" value="<?php echo @$MinOrd; ?>" class="scs-ctrl" />
            <div class="MinOrd" ></div></td>
          <td align="right" class="F_val">IsSales</td>
          <td align="left"><select name="IsSales" id="IsSales"  class="scs-ctrl"   >
              <option value="1" >Yes</option>
              <option value="2" >No</option>
            </select>
            <div class="IsSales" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">Active</td>
          <td align="left"><select name="Active" id="Active"  class="scs-ctrl"   >
              <option value="1" >Yes</option>
              <option value="2" >No</option>
            </select>
            <div class="Active" ></div></td>
        </tr>
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>

 $(document).ready(function(e) {
    $('#CatNo').focus();
	$('#Brand_Id').val(<?php echo @$Brand_Id; ?>);
	$('#Group_Id').val(<?php echo @$Group_Id; ?>);
	$('#Category_Id').val(<?php echo @$Category_Id; ?>);
	$('#Active').val(<?php echo @$Active; ?>);
	$('#IsSales').val(<?php echo @$IsSales; ?>);
	$('#TaxSetup_Id').val(<?php echo @$TaxSetup_Id; ?>);
	$('#Unit_Id').val(<?php echo @$Unit_Id; ?>);
	
	
});



 </script> 
