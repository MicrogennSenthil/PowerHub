<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Master','LedgerType');
$this->pfrm->FrmHead1('Master / LedgerType',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$LedgerType_Id; ?>" >
      <table class="FrmTable T-5" >
        
         <tr>
          <td align="right" class="F_val">LedgerType&nbsp;Code</td>
          <td align="left"><input type="text"  id="LedgerTypeCode" name="LedgerTypeCode" value="<?php echo @$LedgerTypeCode; ?>" class="scs-ctrl" style="width:280px"  />
            <div class="LedgerTypeCode" ></div></td>
        </tr>
         
         <tr>
          <td align="right" class="F_val">LedgerType</td>
          <td align="left"><input type="text"  id="LedgerType" name="LedgerType" value="<?php echo @$LedgerType; ?>" class="scs-ctrl" style="width:280px"  />
            <div class="LedgerType" ></div></td>
        </tr>
         
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>

 $(document).ready(function(e) {
    
	$('#LedgerTypeCode').focus();
	 
});

 </script> 
 
