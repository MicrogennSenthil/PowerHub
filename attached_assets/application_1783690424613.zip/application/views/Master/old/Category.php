<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
//$this->pweb->Cheader('Master','Category');
$this->pfrm->FrmHead1('Master / Category',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$Category_Id; ?>" >
      <table class="FrmTable T-4" >
        
        
         <tr>
          <td align="right" class="F_val">Category Name</td>
          <td align="left"><input type="text" placeholder="Category Name" id="CategoryName" name="CategoryName" value="<?php echo @$CategoryName; ?>" class="scs-ctrl" />
            <div class="CategoryName" ></div></td>
        </tr>
         
         <tr>
          <td align="right" class="F_val">Active</td>
          <td align="left"><select name="Active" id="Active"  class="scs-ctrl"   >
          <option value="1" >Yes</option>
           <option value="2" >No</option>
          </select>
            <div class="CategoryName" ></div></td>
        </tr>
         
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
 
