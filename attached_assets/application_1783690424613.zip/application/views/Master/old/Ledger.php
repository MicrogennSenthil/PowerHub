<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Master','Ledger');
$this->pfrm->FrmHead1('Master / Ledger',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
      <input type="hidden" name="idv" value="<?php echo @$Ledger_Id; ?>" >
      <table class="FrmTable T-9">
        <tr>
          <td colspan="4" align="center" class="F_val F_head">Ledger Information</td>
        </tr>
        <tr>
          <td align="right" class="F_val">Ledger Name</td>
          <td align="left"><input type="text" placeholder="Ledger Name" id="LedgerName" name="LedgerName" value="<?php echo @$LedgerName; ?>" class="scs-ctrl" />
            <div class="LedgerName" ></div></td>
          <td align="right" class="F_val">Ledger Code</td>
          <td align="left"><input type="text" placeholder="Ledger Code" id="LedgerCode" name="LedgerCode" value="<?php echo @$LedgerCode; ?>" class="scs-ctrl" />
            <div class="LedgerCode" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">LedgerType</td>
          <td align="left">
          <select type="text" id="LedgerType_Id" name="LedgerType_Id" class="scs-ctrl" style="width:100%">
              <option value="" > -- Select LedgerType -- </option>
              <?php
				  $Res=$this->Myclass->LedgerType();
				  $count=1;
				   foreach($Res as $row)
					{
						echo '<option value="'.$row['LedgerType_Id'].'">'.$row['LedgerType'].'</option>';
					}
		  	   ?>
            </select>
            <div class="LedgerType_Id" ></div></td>
        </tr>
        
        
        <tr>
          <td align="right" class="F_val">Address 1</td>
          <td align="left"><input type="text" placeholder="Address 1" id="Address1" name="Address1" value="<?php echo @$Address1; ?>" class="scs-ctrl" />
            <div class="Address1" ></div></td>
          <td align="right" class="F_val">Address 2</td>
          <td align="left"><input type="text" placeholder="Address 2" id="Address2" name="Address2" value="<?php echo @$Address2; ?>" class="scs-ctrl" />
            <div class="Address2" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">City</td>
          <td align="left"><input type="text" placeholder="City" id="City" name="City" value="<?php echo @$City; ?>" class="scs-ctrl" />
            <div class="City" ></div></td>
          <td align="right" class="F_val">Pincode</td>
          <td align="left"><input type="text" placeholder="Pincode" id="Pincode" name="Pincode" value="<?php echo @$Pincode; ?>" class="scs-ctrl" />
            <div class="Pincode" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">Phone</td>
          <td align="left"><input type="text" placeholder="Phone" id="Phone" name="Phone" value="<?php echo @$Phone; ?>" class="scs-ctrl" />
            <div class="Phone" ></div></td>
          <td align="right" class="F_val">Email</td>
          <td align="left"><input type="text" placeholder="Email" id="Email" name="Email" value="<?php echo @$Email; ?>" class="scs-ctrl" />
            <div class="Email" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">Mobile</td>
          <td align="left"><input type="text" placeholder="Mobile" id="Mobile" name="Mobile" value="<?php echo @$Mobile; ?>" class="scs-ctrl" />
            <div class="Mobile" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">GST No:</td>
          <td align="left"><input type="text" placeholder="GST No" id="GSTNo" name="GSTNo" value="<?php echo @$GSTNo; ?>" class="scs-ctrl" />
            <div class="GSTNo" ></div></td>
        </tr>
        <tr>
          <td colspan="4" align="right"><input type="button" class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>

 $(document).ready(function(e) {
    
	$('#LedgerType_Id').val(<?php echo @$LedgerType_Id; ?>).trigger('change');
});

 </script> 
