<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
//$this->pweb->Cheader('Master','Template');
$this->pfrm->FrmHead1('Master / Template',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
      <input type="hidden" name="idv" value="<?php echo @$Template_Id; ?>" >
      <input type="hidden" name="Keey" value="<?php echo @$Keey; ?>" >
      <table class="FrmTable T-6" >
        <tr>
          <td align="right" class="F_val">Supplier</td>
          <td align="left"><select class="scs-ctrl mysel" name="Supplier_Id" id="Supplier_Id"   >
              <option value="" >Select</option>
              <?php
          
		  $Res=$this->Myclass->Supplier();
		  $count=1;
		 foreach($Res as $row)
			{
				echo '<option value="'.$row['Supplier_Id'].'" >'.$row['SupplierName'].'</option>';
			}
		  
		  ?>
            </select>
            <div class="Supplier_Id" ></div></td>
          <td width="150" align="right" class="F_val">TemplateName</td>
          <td align="left"><input type="text" placeholder="Template" id="Template" name="Template" value="<?php echo @$Template; ?>" class="scs-ctrl" />
            <div class="Template" ></div></td>
        </tr>
      </table>
    </fieldset>
    <fieldset>
      <table class="  mytable" >
        <thead>
          <tr>
            <th width="25">Sno</th>
            <th width="90" >CatNo</th>
            <th>ItemName</th>
            <th width="70" >Uom</th>
            <th width="170" >Rate</th>
            <th  width="50">#</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td  ><input type="text" class="f-ctrl" name="Sno" ></td>
            <td><input readonly type="text" class="f-ctrl" name="CatNo" id="CatNo" ></td>
            <td><div class="ui-widget">
                <input type="text" class="f-ctrl" name="Item" id="Item" onClick="Pop_Item(this)" >
                <input type="hidden" class="f-ctrl" name="Item_Id" id="Item_Id" >
              </div></td>
            <td ><input readonly type="text" class="f-ctrl" name="Uom"  id="Uom" ></td>
            <td><input type="text" class="f-ctrl" name="Rate"  id="Rate" num=1 ></td>
            <td align="center"><a onClick="ItemAdd()" class="btn btn-success btn-xs" ><i class="fa fa-plus" ></i> Add</a></td>
          </tr>
        </tbody>
        <tbody class="ItemAdd">
        
        <?php
		if(@$Template_Id!=''){
        $qry="exec Exec_Temp_Template_Update '".@$Keey."',".@$Template_Id;
		$Res=$this->db->query($qry);
		$cou=1;
		 foreach($Res->result() as $row)
		 {
			 echo '<tr>
			 <td>'.$cou.'</td>
			 <td>'.$row->CatNo.'</td>
			 <td>'.$row->ItemName.'</td>
			 <td>'.$row->Symbol.'</td>
			 <td align="right" >'.$row->Rate.'</td>
			 <td> <a onclick="ItemDel('.$row->Template_Det_Id.')" class="btn btn-danger btn-xs" >
			 <i class="fa fa-trash" ></i> Delete </a> </td>
			 </tr>';
		     $cou++;
		 }
		}
		
		?>
        
        </tbody>
        <tfoot>
          <tr>
            <td class="Loading" colspan="9"  ></td>
          </tr>
        </tfoot>
         <tfoot>
         
          <tr>
            <td colspan="13" align="right" ><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
          </tr>
        </tfoot>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>

$(document).ready(function(e) {
    $('#Supplier_Id').val(<?php echo @$Supplier_Id; ?>).trigger('change');
});

 function Supplier_Rate()
 {
	 $.ajax({
		
		type:"POST",
		url:"<?php echo scs_index; ?>Master/TItemDel",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.ItemAdd').html(html);
			$('.Loading').html(''); 
		    $("#Item").val('');
	        $("#CatNo").val('');
		    $("#Uom").val('');
		    $("#Item_Id").val('');
			$('#Item').focus();
		}	
	})
 }
 function ItemAdd()
{
	$('.Loading').html('<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>');
	$.ajax({
		
		type:"POST",
		url:"<?php echo scs_index; ?>Master/TItemAdd",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.ItemAdd').html(html);
			$('.Loading').html(''); 
			$("#Item").val('');
			$("#CatNo").val('');
			$("#Uom").val('');
			$("#Rate").val(0);
			$("#Item_Id").val('');
			$('#Item').focus();
		}	
	})
}
 
function ItemDel(ee)
{
	$('.Loading').html('<i class="fa fa-spinner fa-spin fa-3x fa-fw"></i>');
	
	$.ajax({
		type:"POST",
		url:"<?php echo scs_index; ?>Master/TItemDel/"+ee,
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.ItemAdd').html(html);
			$('.Loading').html(''); 
			
		}	
	})
}
   
     
 </script> 
