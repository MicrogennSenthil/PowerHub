<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Master','OpeningStock');
$this->pfrm->FrmHead1('Master / OpeningStock',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");


?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
      <input type="hidden" name="idv" value="<?php echo @$Stock_Id; ?>" >
      <table class="FrmTable T-6" >
       
       
        <tr>
          <td align="right" class="F_val">Itemname</td>
          <td align="left"><select type="text" id="Item_Id" name="Item_Id" class="scs-ctrl" style="width:100%">
              <option value="" > -- Select Itemname -- </option>
              <?php
				  $Res=$this->Myclass->Item();
				  $count=1;
				   foreach($Res as $row)
					{
						echo '<option value="'.$row['Item_Id'].'">'.$row['Itemname'].'</option>';
					}
		  	   ?>
            </select>
            <div class="Item_Id" ></div></td>
        </tr>
        
        <tr>
          <td align="right" class="F_val">Qty</td>
          <td align="left"><input type="text" num="1" placeholder="Qty" id="OpQty" name="OpQty" value="<?php echo floatval( @$OpQty); ?>" class="scs-ctrl" />
            <div class="OpQty" ></div></td>
        </tr>
        
         <tr>
          <td align="right" class="F_val">Date</td>
          <td align="left"><input type="text"    id="OpDate" name="OpDate" value="<?php echo @$OpDate; ?>" class="scs-ctrl" />
            <div class="OpDate" ></div></td>
        </tr>
         
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>

 $(document).ready(function(e) {
    
	$('#Item_Id').val(<?php echo @$Item_Id; ?>).trigger('change');
	 
});

 </script> 
