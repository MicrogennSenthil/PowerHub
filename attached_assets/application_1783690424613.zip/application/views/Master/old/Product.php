<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Master','Product');
$this->pfrm->FrmHead1('Master / Product',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");


?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
      <input type="hidden" name="idv" value="<?php echo @$Product_Id; ?>" >
       <input type="hidden" name="Keyy" value="<?php echo @$Keyy; ?>" >
      <table class="FrmTable T-12" >
        <tr>
          <td align="right" class="F_val">Productname</td>
          <td align="left"><input type="text" placeholder="Product" id="Product" name="Product" value="<?php echo @$Product; ?>" class="scs-ctrl" />
            <div class="Product" ></div></td>
          <td align="right" class="F_val">Model</td>
          <td align="left"><input type="text" placeholder="Model" id="Model" name="Model" value="<?php echo @$Model; ?>" class="scs-ctrl" />
            <div class="Model" ></div></td>
        </tr>
      </table>
    </fieldset>
    <fieldset>
      <div class="T-12">
        <table class="mytable" style="margin-top:10px ">
          <thead>
            <tr>
              <th style="width:20px" >#</th>
              <th style="width:150px" >ITEM CODE</th>
              <th>ITEM DESCRIPTION</th>
              <th  style="width:50px" >UOM</th>
              <th style="width:100px" >BOM QTY</th>
              <th style="width:40px" >Action</th>
            </tr>
          </thead>
          <tbody>
            <tr>
              <td></td>
              <td><input type="text" name="PartNumber" id="PartNumber" readonly    class="scs-ctrl" ></td>
              <td width="250"><select type="text"   id="Item_Id" name="Item_Id"   class="scs-ctrl" onChange="getval()" >
                  <option value="0" > -- Select Product -- </option>
                  <?php
          $Res=$this->Myclass->Item();
			$count=1;
			 
		 foreach($Res as $row)
			{
			    echo '<option value="'.$row['Item_Id'].'" SYMBOL="'.$row['SYMBOL'].'" PartNumber="'.$row['PartNumber'].'"   >'.$row['Itemname'].'</option>';
			}
		  ?>
                </select></td>
              <td><input type="text" name="UOM" id="UOM" readonly class="scs-ctrl"  ></td>
              <td><input type="text" name="BOMQTY" id="BOMQTY" num=1  class="scs-ctrl" ></td>
              <td><a class="btn btn-info btn-sm" onClick="ProAdd()" ><i class="fa fa-plus-circle "  ></i> ADD</a></td>
            </tr>
          </tbody>
          <tbody class="purdet">
            <?php
            
			$qry=" exec Temp_Get_Product_Update  '".@$Keyy."','".@$Product_Id."'";
		$res=$this->db->query($qry);
		$cou=1;
		$AMT=0;
		foreach($res->result() as $row)
		{
			echo '<tr class="RW'.$row->Product_Det_Id.'" >
			<td>'.$cou.'</td>
			<td>'.$row->PartNumber.'</td>
			<td>'.$row->Itemname.'</td>
			<td>'.$row->SYMBOL.'</td>
			<td align="right" >'.floatval($row->BOMQTY).'</td>';
			 
			
			echo '<td><a class="btn btn-danger btn-sm" onclick="DadaDel('.$row->Product_Det_Id.')" >Delete</a></td>
			</tr>';
			$cou++;
			 
		}
			
			?>
          </tbody>
          <tfoot>
            <tr>
              <td colspan="10" align="left">&nbsp;</td>
            </tr>
            <tr>
              <td colspan="10" align="right">&nbsp;
                <input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
            </tr>
          </tfoot>
        </table>
      </div>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>

function getval()
{
	units=$('#Item_Id option:selected').attr('SYMBOL');
	PartNumber= $('#Item_Id option:selected').attr('PartNumber');
	$('#PartNumber').val(PartNumber);
	$('#UOM').val(units);
	$('#BOMQTY').focus();
	
}
function ProAdd()
{
	 
	$.ajax({
		
		type:"POST",
		url:"<?php echo scs_index; ?>Entry/ProAdd",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.purdet').html(html);
			$('#Item_Id,#BOMQTY').val(0);
			 $('#PartNumber,#UOM').val('');
			$('#Item_Id').focus();
			
		}	
	})
}

function DadaDel(ee)
{
	$.ajax({
		
		type:"POST",
		url:"<?php echo scs_index; ?>Entry/DadaDel/"+ee,
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.purdet').html(html);
			$('#PartNumber,#RATE,#QTY,#TOTAL').val('');
			$("#Item_Id").val(0).trigger('change');
			 $('#UOM').val('');
			$('#Item_Id').focus();
			
		}	
	})
}
</script>