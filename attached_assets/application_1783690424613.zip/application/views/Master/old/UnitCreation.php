<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Master','UnitCreation');
$this->pfrm->FrmHead1('Master / UnitCreation',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$UID; ?>" >
      <table class="FrmTable T-4" >
        <tr>
          <td align="right" class="F_val">Symbol</td>
          <td align="left"><input type="text" placeholder="Symbol" id="SYMBOL" name="SYMBOL" value="<?php echo @$SYMBOL; ?>" class="scs-ctrl" />
            <div class="SYMBOL" ></div></td>
        </tr>
        
         <tr>
          <td align="right" class="F_val">Full Name</td>
          <td align="left"><input type="text" placeholder="Full Name" id="FLNAME" name="FLNAME" value="<?php echo @$FLNAME; ?>" class="scs-ctrl" />
            <div class="FLNAME" ></div></td>
        </tr>
         
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
 
