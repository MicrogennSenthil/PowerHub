<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session); 
$this->pfrm->FrmHead1('Master / Customer',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");


?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
      <legend>Customer Details</legend>
      <input type="hidden" name="idv" value="<?php echo @$Customer_Id; ?>" >
      <input type="hidden" name="Keyy" value="<?php echo @$Keyy; ?>" >
      <div class="col-sm-10" >
        <table class="FrmTable T-12" >
          <tr>
            <td width="150" align="right" class="F_val">CustomerName</td>
            <td align="left"><input type="text" placeholder="Customer Name  " id="CustomerName" name="CustomerName" value="<?php echo @$CustomerName; ?>" class="scs-ctrl" />
              <div class="CustomerName" ></div></td>
            <td  width="150" align="right" class="F_val">CustomerId</td>
            <td align="left"><input readonly type="text" placeholder="CustomerId" id="CustomerId" name="CustomerId" value="<?php echo @$CustomerId; ?>" class="scs-ctrl" />
              <div class="CustomerId" ></div></td>
          </tr>
          <tr>
            <td align="right" class="F_val" >Address</td>
            <td align="left"><input type="text" placeholder="Address" id="Address" name="Address" value="<?php echo @$Address; ?>" class="scs-ctrl" />
              <div class="Address" ></div></td>
            <td align="right"   >Address1</td>
            <td align="left"><input type="text" placeholder="Address1" id="Address1" name="Address1" value="<?php echo @$Address1; ?>" class="scs-ctrl" />
              <div class="Address1" ></div></td>
          </tr>
          <tr>
            <td align="right" >City</td>
            <td align="left"><input type="text" placeholder="City" id="City" name="City" value="<?php echo @$City; ?>" class="scs-ctrl" />
              <div class="Address" ></div></td>
            <td align="right" class="F_val" >ZipCode</td>
            <td align="left"><input type="text" num=1 placeholder="ZipCode" id="ZipCode" name="ZipCode" value="<?php echo @$ZipCode; ?>" class="scs-ctrl" />
              <div class="ZipCode" ></div></td>
          </tr>
          
          <tr>
            <td  width="150" align="right" class="F_val" >OpAmt</td>
            <td align="left"><input type="text" num="1"   id="OpAmt" name="OpAmt" value="<?php echo @$OpAmt; ?>" class="scs-ctrl" />
              <div class="Phone" ></div></td>
            <td  width="150" align="right"  >OpDate</td>
            <td align="left"><input type="text"   id="OpDate" name="OpDate" value="<?php echo @$OpDate; ?>" class="scs-ctrl Dat" />
              <div class="OpDate" ></div></td>
          </tr>
          <tr>
            <td align="right" >GSTNo</td>
            <td align="left"><input type="text" placeholder="GSTNo" id="GSTNo" name="GSTNo" value="<?php echo @$GSTNo; ?>" class="scs-ctrl" />
              <div class="GSTNo" ></div></td>
           
          </tr>
        </table>
      </div>
      <div class="col-sm-2" >
        <table>
          <tr>
            <td><div class='preview'> <img src="<?php echo scs_url;?>upload/<?php echo @$Keyy;?>.png" id="img" width="100" height="100"> </div>
              <div >
                <input type="file" id="file" name="file" />
                <input type="button" class="button" value="Upload" id="but_upload">
              </div></td>
          </tr>
        </table>
      </div>
    </fieldset>
    <br>
    <fieldset>
      <legend>Contact Details</legend>
       <div class="col-sm-10" >
      <table class="FrmTable T-12" >
        <tr>
          <td  width="150" align="right" class="F_val" >Phone</td>
          <td align="left"><input type="text" num="1"   id="Phone" name="Phone" value="<?php echo @$Phone; ?>" class="scs-ctrl" />
            <div class="Phone" ></div></td>
          <td  width="150" align="right"  >Mobile</td>
          <td align="left"><input type="text"  num=1 id="Mobile" name="Mobile" value="<?php echo @$Mobile; ?>" class="scs-ctrl" />
            <div class="Mobile" ></div></td>
        </tr>
        <tr>
          <td align="right"  >Email</td>
          <td align="left"><input type="text"  placeholder="Email" id="Email" name="Email" value="<?php echo @$Email; ?>" class="scs-ctrl" />
            <div class="Email" ></div></td>
          <td align="right"  >ContactPerson </td>
          <td align="left"><input type="text"   placeholder="" id="ContactPerson" name="ContactPerson" value="<?php echo @$ContactPerson; ?>" class="scs-ctrl" />
            <div class="ContactPerson" ></div></td>
        </tr>
        <tr>
          <td align="right"  >CMobile</td>
          <td align="left"><input type="text" num="1"  id="CMobile" name="CMobile" value="<?php echo @$CMobile; ?>" class="scs-ctrl" />
            <div class="CMobile" ></div></td>
          <td align="right"  >CEmail</td>
          <td align="left"><input type="text"   id="CEmail" name="CEmail" value="<?php echo @$CEmail; ?>" class="scs-ctrl" />
            <div class="CEmail" ></div></td>
        </tr>
        <tr>
          <td align="right"  >PAN No</td>
          <td align="left"><input type="text"  id="PAN" name="PAN" value="<?php echo @$PAN; ?>" class="scs-ctrl" />
            <div class="PAN" ></div></td>
           
           
            </tr>
      </table>
      </div>
    </fieldset>
    <br>
    <fieldset>
      <legend>Message Details</legend>
       <div class="col-sm-10" >
      <table class="FrmTable T-12" > <tr>
    <td width="150" align="right" class="F_val">Sales Message</td>
            <td align="left"><select name="Active" id="Active"  class="scs-ctrl"   >
                <option value="1" >Yes</option>
                <option value="2" >No</option>
              </select>
              <div class="Active" ></div></td>
              <td width="150" align="right" class="F_val">Collection Message</td>
              <td align="left"><select name="Message" id="Message"  class="scs-ctrl"   >
                <option value="1" >Yes</option>
                <option value="2" >No</option>
              </select>
              <div class="Message" ></div></td>
</tr>
              </table>
      </div>
    </fieldset>
    <br>
    <fieldset>
      <legend>Bank Details</legend>
       <div class="col-sm-10" >
      <table class="FrmTable T-12" >
        <tr>
          <td  width="150" align="right"  >BankAccountNo</td>
          <td align="left"><input type="text" num="1"  id="BankAccountNo" name="BankAccountNo" value="<?php echo @$BankAccountNo; ?>" class="scs-ctrl" />
            <div class="BankAccountNo" ></div></td>
          <td  width="150" align="right"  >BankName</td>
          <td align="left"><input type="text"    id="BankName" name="BankName" value="<?php echo @$BankName; ?>" class="scs-ctrl" />
            <div class="BankName" ></div></td>
        </tr>
        <tr>
          <td align="right"  >Branch</td>
          <td align="left"><input type="text"    id="Branch" name="Branch" value="<?php echo @$Branch; ?>" class="scs-ctrl" />
            <div class="Branch" ></div></td>
          <td align="right"  >IFSC Code</td>
          <td align="left"><input type="text"    id="IFSECode" name="IFSECode" value="<?php echo @$IFSECode; ?>" class="scs-ctrl" />
            <div class="IFSECode" ></div></td>
        </tr>
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
      </div>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>

 $(document).ready(function(e) {
    $('#CustomerName').focus();
    $('#Message').val(<?php echo $Message; ?>);
    $('#Active').val(<?php echo $Active; ?>);
	$('#scsfrm').attr('enctype','multipart/form-data'); 
	
	
});

        $(document).ready(function(){

            $("#but_upload").click(function(){

                var fd = new FormData();

                var files = $('#file')[0].files[0];

                fd.append('file',files);

                $.ajax({
                    url:'<?php echo scs_url;?>upload.php?Keyy=<?php echo @$Keyy;?>',
                    type:'post',
                    data:fd,
                    contentType: false,
                    processData: false,
                    success:function(response){
                        if(response != 0){
							 
                            $("#img").attr("src",'<?php echo scs_url;?>'+response);
                            $('.preview img').show();
                        }else{
                            alert('File not uploaded');
                        }
                    }
                });
            });
        });



 </script> 
