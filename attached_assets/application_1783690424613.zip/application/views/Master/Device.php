<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
//$this->pweb->Cheader('Master','Device');
$this->pfrm->FrmHead1('Master / Device',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$Device_Id; ?>" >
      <table class="FrmTable T-4" >
        
        
         <tr>
          <td align="right" class="F_val">Device</td>
          <td align="left"><input type="text" maxlength="6" placeholder="Device Name" id="Device" name="Device" value="<?php echo @$Device; ?>" class="scs-ctrl" />
            <div class="Device" ></div></td>
        </tr>
		
		 <tr>
          <td align="right" class="F_val">IP</td>
          <td align="left"><input type="text"  placeholder="IP Address" id="IP" name="IP" value="<?php echo @$IP; ?>" class="scs-ctrl" />
            <div class="IP" ></div></td>
        </tr>
        <tr>
          <td align="right" class="F_val">Floor</td>
          <td align="left"><select type="text" id="Floor_Id" name="Floor_Id" class="scs-ctrl" style="width:100%">
              <option value="" > -- Select Floor -- </option>
              <?php
				  $Res=$this->Myclass->Floor();
				  $count=1;
				   foreach($Res as $row)
					{
						echo '<option value="'.$row['Floor_Id'].'">'.$row['Floor'].'</option>';
					}
		  	   ?>
            </select>
            <div class="Floor_Id" ></div></td>
        </tr>
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
 $(document).ready(function(e) {
    $('#Type_Id').val(<?php echo @$Type_Id; ?>);
	 $('#Floor_Id').val(<?php echo @$Floor_Id; ?>);
});
</script>