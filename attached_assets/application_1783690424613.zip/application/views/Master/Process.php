<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
//$this->pweb->Cheader('Master','Process');
$this->pfrm->FrmHead1('Master / Process',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

 
?>

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
      <input type="hidden" name="idv" value="<?php echo @$ID; ?>" >
      <table class="FrmTable T-4" >
       
         
          <td align="right" class="F_val">Process</td>
          <td align="left"><select type="text" id="Process_Id" name="Process_Id" class="scs-ctrl" style="width:100%">
              <option value="" > -- Select Process -- </option>
              <?php
				  $Res=$this->Myclass->Process();
				  $count=1;
				   foreach($Res as $row)
					{
						echo '<option value="'.$row['Status_Id'].'">'.$row['Status'].'</option>';
					}
		  	   ?>
            </select>
            <div class="Process_Id" ></div></td>
        </tr>
		
		  
		  <tr>
         <td align="right" class="F_val">IsAuto</td>
          <td>
		  
		  <select  type="text" id="IsAuto" name="IsAuto" onchange="IsAuto_(this.value)"  class="scs-ctrl" > 
		  <option value="0" >No</option> <option value="1" >Yes</option>
		  </select>
		  </td>
		  </tr>
		  <tr class="PT" >
         <td align="right" class="F_val">Time</td>
          <td><input  type="text" id="Ptime" name="Ptime" num=1 class="scs-ctrl"  value="<?php echo @$Ptime; ?>" /> </td>
		  </tr>
		  
        <tr>
          <td align="right">&nbsp;</td>
          <td align="left"><input type="button"   class="btn btn-success btn-sm" id="EXEC" name="EXEC" value="<?php echo $BUT;?>"   /></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="the-box D_IS" ></div>
</div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
 $(document).ready(function(e) {
    $('#IsAuto').val(<?php echo @$IsAuto; ?>);
	$('#Process_Id').val(<?php echo @$Process_Id; ?>);
	 $('.PT').hide();
});

function IsAuto_(a)
{
	if((a*1)==1){ $('.PT').show(); } else { $('.PT').hide(); }
	
}

</script>