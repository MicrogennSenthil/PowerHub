<table class="table  table-striped" style="width: 100%" >
<thead>
  <tr>
    <th>Device</th>
    <th>Status</th>
    <th></th>
    
  </tr>
</thead>
<tbody>
  <?php
$qry="Get_Device_Status ".$HotelId;
$rom=$this->db->query($qry);
foreach($rom->result() as $RM)
	{
					echo '<tr>';
					echo '<td class="'.$RM->Status.'" >'.$RM->Device.'</td>';
					echo '<td class="'.$RM->Status.'" >'.$RM->Status.'</td>';
					 
					echo '<td><img   src="'.scs_url.'power/icon/'.$RM->Img.'l.png" /></td>';
					echo '</tr>';
	}
	
	?>
</tbody>
	</table>