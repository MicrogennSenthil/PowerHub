<?php
 require_once APPPATH.'views/dompdf/autoload.inc.php';
 use Dompdf\Dompdf;
 
use Dompdf\Options; 
use Dompdf\FontMetrics; 
$dompdf = new Dompdf();
$dompdf->loadHtml($html);
$dompdf->setPaper('A4', 'landscape');
$dompdf->render();
$options = new Options(); 
$options->set('isPhpEnabled', 'true');
$canvas = $dompdf->getCanvas(); 
$fontMetrics = new FontMetrics($canvas, $options); 
$w = $canvas->get_width(); 
$h = $canvas->get_height(); 
$font = $fontMetrics->getFont('times'); 
$text = "Supreme Broilers ";  
$txtHeight = $fontMetrics->getFontHeight($font, 75); 
$textWidth = $fontMetrics->getTextWidth($text, $font, 75); 
$canvas->set_opacity(.05); 
$x = (($w-$textWidth)/2); 
$y = (($h-$txtHeight)/2);  
$canvas->text($x, $y, $text, $font, 75,$color = array(0, 0, 0), $word_space = 0.0, $char_space = 0.0, $angle = 15.0); 
 

//$dompdf->stream($filename.".pdf", array("Attachment" => 0));
$dompdf->stream($filename.".pdf");