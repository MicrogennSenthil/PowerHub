 
  <div class="box-header with-border" style="padding:10px">
    <?php

$QRRY = "Rep_PurchaseOrder '".$this->Myclass->DateSplit($_POST['Fdate'])."' , 
	   '".$this->Myclass->DateSplit($_POST['Tdate'])."'";
 
 
		$qry = $this->db->query($QRRY);
		$Res = $qry->result_Array();
		$res = 	'<table id="example1" class="table table-striped table-bordered">
            		<thead>
              			<tr>
                			<th>Sno</th>
            <th>OrderNo</th>
            <th>OrderDate</th>
            <th>Supplier</th>
            <th>CGST</th>
            <th>SGST</th>
            <th>Total</th>
			                <th>Action</th>
              			</tr>
            		</thead>
        			<tbody>';
	  	$cou=1;
	  	 foreach($Res as $row)
			{

     		$res .= '<tr>
        			 <td>'.$cou.' </td>
                      <td>'.$row['OrderNo'].'</td>
					  <td>'.$row['Dat'].'</td>
					  <td>'.$row['LedgerName'].'</td>
					  <td>'.$row['CGST'].'</td>	 
					  <td>'.$row['SGST'].'</td>	 
					  <td>'.$row['TotalAmount'].'</td>
        			<td>';
        			 
                        	$res .= '<a class="btn btn-warning btn-xs" target="_blank" href="'.scs_index."Reprint/PrintPo/".$row['PurchaseOrder_Id'].'"   ><i class="fa fa-print" aria-hidden="true"></i> Print</a> | ';
							
							$res .= '<a class="btn btn-success btn-xs" target="_blank" href="'.scs_index."Reprint/PrintPo/".$row['PurchaseOrder_Id'].'"   ><i class="fa fa-envelope-o" aria-hidden="true"></i> Sent Mail</a>';

                        
      			$res .='</tr>';
			$cou++;
	  	}
        $res .=	'</tbody>
	          </table>';
	    echo $res; 



?>
  </div>
 
<script>
$('#example1').DataTable();
</script>