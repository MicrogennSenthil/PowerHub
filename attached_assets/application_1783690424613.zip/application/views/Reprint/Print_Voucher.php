<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
<style type="text/css">
* {
	font-size: 11px;
}
</style>
<style type="text/css" media="print">
.breakAfter {
	page-break-after: always;
}
 
</style>
</head>
<?php
$qry="exec Print_Voucher ".$ID;
$res=$this->db->query($qry);
$Grn=$res->row();

 
?>
<body onLoad="window.print();window.close()"  >
<style type="text/css" media="print"> 
.breakAfter{ 
	page-break-after: always; 
} 
</style>
<div style="width: 100%;height: auto;border: 1px solid #000;font-size: 9px;">
  <table style="width: 100%;border-collapse: collapse;padding-left: 15px;">
    <tr>
      <td align="center" ><h2 style="font-size:15px" ><?php echo Branch; ?></h2>
        <p><?php echo Address; ?><br>
          <?php echo City; ?> - <?php echo PinCode; ?>. <br>
          <strong>GSTIN : <?php echo GST; ?></strong><br>
          Phone : +91 <?php echo Phone; ?></p></td>
    </tr>
    <tr>
      <td align="center"><b><?php echo $_REQUEST['TY']; ?>
        </p>
        </b></td>
    </tr>
  </table>
  <table style="width: 100%;border-collapse: collapse;padding-left: 15px;">
    <tr>
      <td style="float:left;padding-left:15px;"><b>VO NO &nbsp;&nbsp;&nbsp;</b></td>
      <td style="float:left;padding-left:15px;"> : <?php echo $Grn->PNo; ?></td>
      <td align="right" ><div style= "float:left;text-align: left;"><b>Date</b></div></td>
      <td style= "padding-right: 15px;"> : <?php echo $Grn->DAT; ?></td>
    </tr>
    <tr>
      <td style="float:left;padding-left:15px;"><b>Ledger </b></td>
      <td style="float:left;padding-left:15px;"> : <?php echo $Grn->LNAME; ?> <br>
        &nbsp; <?php echo $Grn->AD1." , ".$Grn->AD2; ?><br>
        &nbsp; <?php echo $Grn->CITY; ?></td>
    </tr>
  </table>
  <br>
  <table width="100%" border="0" cellspacing="1" cellpadding="1" align="center" style="width: 98%;border-collapse: collapse;padding-left: 15px;padding-right: 15px;" align="center">
  <thead style="font-weight: bold" >
    <tr>
      <td align="center" style= "border: 1px solid #000;" >Sno</td>
      <td align="center" style= "border: 1px solid #000;" >Particulars</td>
   
      <td align="center" style= "border: 1px solid #000;" >Amount</td>
    </tr>
  </thead>
  <tbody>
    <?php
  $cou=1;
  $qry="exec Print_Voucher_Det ".$ID;
  $res=$this->db->query($qry);
  $amount=0;
  foreach($res->result() as $row)
  {
      ?>
    <tr>
      <td style= "border: 1px solid #000;"><?php echo $cou; ?></td>
      <td style= "border: 1px solid #000;"><?php echo $row->LNAME; ?></td>
     
      <td align="right" style= "border: 1px solid #000;"><?php echo $row->Amount; ?></td>
    </tr>
    <?php 
    $amount =$amount+$row->Amount;
	$cou++;
}

 ?>
  </tbody>
  
  <tbody style="font-size:18px !important" >
    <tr>
 
      <td colspan="1" style= "border: 1px solid #000;" ></td>
      <td  align="right" style= "border: 1px solid #000;"><b>Net Total </b></td>
      <td align="right" style= "border: 1px solid #000;"><b><?php echo $amount; ?></b></td>
    </tr>
  </tbody>
  </table>
  <table width="100%" border="0" cellspacing="1" cellpadding="0" align="center" style="width: 98%;border-collapse: collapse;padding-left: 15px;padding-right: 15px;" align="center">
  <tr><td>
  <b> Amount In Words : </b> <span id='numwords'> <?php echo $Grn->W; ?> </span>
  </td></tr></table>
  <br>
  <br>
  <table style="width: 100%;border-collapse: collapse;padding-left: 15px;">
    <tr>
      <td><div style="float:left;padding-left:15px;">Terms & Condition</div>
        <div style= "float:right;padding-right: 15px;text-align: left;" ><span style="font-size: 12.5px;"><b >For <?php echo Branch; ?></b></span></div></td>
    </tr>
    <tr>
      <td><div style="float:left;padding-left:15px;">All disputes are subject to <?php echo  City; ?> jurisdiction only</div>
        <div style= "float:right;padding-right: 15px;text-align: left;"></div></td>
    </tr>
    <tr>
      <td><div style="float:left;padding-left:15px;""><b> E & O.E</b></div>
        <div style= "float:right;padding-right: 15px;text-align: left;"><b>Authorised Signatory</b></div></td>
    </tr>
  </table>
  <div  align="center"><Span>Page(1)</Span></div>
</div>
</body>
</html>
