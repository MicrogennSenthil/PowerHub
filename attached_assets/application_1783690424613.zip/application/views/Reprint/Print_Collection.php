<?php
$qry="exec Print_Collection ".$ID;
$res=$this->db->query($qry);
$data=$res->row();
$PRI='';
$filename=$data->CollectionNo;
if($PTY==1)
{
$PRI=' onLoadd="window.print();window.close()"';
}
 
$Logo = file_get_contents(spath.'upload/logo.png');
$Logo = base64_encode($Logo);
$UpiFile = file_get_contents(spath.'upload/QRCode.png');
$UpiFile = base64_encode($UpiFile);
$Damt=$data->V2000+$data->V1000+$data->V500+$data->V200+$data->V100+$data->V50+$data->v20+$data->V10;

$html='
 <!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
table { font-family:verdana, arial, sans-serif;
font-size:11pt;
 }
</style>
</head>
<body '.$PRI.'  >
<table width="100%" border="0" cellspacing="0" cellpadding="3">
  <tbody>
    <tr>
      <td style="border-right:1px dotted  #6c3483 ;border-bottom:1px dotted  #6c3483 ;" width="65%"><div>
        <div align="left"><img width=50 height=50 src="data:image/png;base64,'.$Logo.'" ></div> 
         <div style="margin-top:-25px" align="center"><strong style="font-size:28px;color: #f1c40f  " > Receipt Voucher</strong></div>
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tbody>
              <tr>
                <td colspan="4" style="border-bottom:4px double  #f1c40f   " valign="bottom" > 
                  </td> 
              </tr>
              <tr>
                <td colspan="4">&nbsp;</td>
              </tr>
              <tr>
                <td align="center" valign="top" style="border-right:1px dotted  #6c3483 "><div><strong>Collection Number</strong></div>
                  <br>
                  '.$data->CollectionNo.'</td>
				  <td align="center" valign="top" style="border-right:1px dotted  #6c3483 "><div><strong>Collection  Date</strong></div>
                  <br>
                  '.$data->DAT.'</td>
                <td align="center" valign="top" style="border-right:1px dotted  #6c3483 ">
                
                </td>
                <td align="center" valign="top"  >
                </td>
              </tr>
            </tbody>
          </table>
        </div></td>
      <td style="border-bottom:1px dotted  #6c3483 ;"  width="35%"><div align="left" >
          <storng style="color: #f1c40f  ;font-weight:bolder;font-size:16px" >'.Branch.'</storng><br>
          '.Address.'<br>
          '.City.',<br>
          Pincode -'.PinCode.',<br>
          <b>Mobile : '.MobileNo.','.Phone.'</b> <br>
          Email : '.Email.'<br>
          GSTIN : '.GST.'</div></td>
    </tr>
    <tr>
      <td style="border-right:1px dotted  #6c3483 ;" >
	   <table width="100%"><tr> 
	  <td align="left" ><h1>Rs . '.$data->Amount.'</h1></td>
	  <td align="center" >  
    <table><tr><td>
    <b>BankName</b> : '.BankName.'</td></tr><tr><td>
	  <b>AccountName</b> : '.AccountName.'</td></tr><tr><td>
	  <b>AccountNo</b>   : '.AccountNo.'</td></tr><tr><td>
	  <b>IFSC</b>        : '.IFSC.'</td></tr><tr><td>
	  <b>UPI </b>        : '.UPI.'</td></tr>
	  </table>
	  </td>  
	  <td align="right"  > <img width=100 height=100 src="data:image/png;base64,'.$UpiFile.'" >
 </td></tr></table>
	  </td>
      <td ><div align="left" >
          <label style="color:#8C8C8C">Customer</label>
          <br>
          <div style="color: #f1c40f  ;font-size:18px" ><b>'.$data->CustomerName.'</b></div>
          '.$data->Address.','.$data->Address1.'<br>
          '.$data->City.',<br>
          Pincode-'.$data->ZipCode.',<br>
          Mobile : '.$data->Phone.' <br>
          Email : '.$data->Email.' </div></td>
    </tr>
  </tbody>
</table>
<table width="100%" border="0" ><tr><td valign="top" width="75%">
<table width="100%" border="0" cellspacing="0" cellpadding="5">
   
    <tr style="font-weight:bold"  >
      <td style="background-color: #f1c40f  ;color:rgba(255,255,255,1.00);font-weight:bold">Sno</td>
      <td align="left" style="background-color: #f1c40f  ;color:rgba(255,255,255,1.00);font-weight:bold">Description</td>
      
      <td align="right" width=130 style="background-color: #f1c40f  ;color:rgba(255,255,255,1.00)">Amount</td>
 
    </tr>
 
  <tbody>';
  $qry="exec Print_Collection ".$ID;
  $ress=$this->db->query($qry);
  $cou=1;
  $TaxVal=0;$Amount=0;
  foreach($ress->result() as $row)
  {
	  $html .='<tr>
	  <td style="border-bottom:1px dotted  #6c3483 ;" >'.$cou.'</td>
    <td align="left"  style="border-bottom:1px dotted  #6c3483 ;" >Collection</td>
    
	  <td align="right" style="border-bottom:1px dotted  #6c3483 ;" >'.$row->Amount.'</td>
   </tr>';
	  $cou++;
	 
	  $Amount +=$row->Amount;
  }
  for($i=0;$i<1; $i++)
  {
	   $html .= '<tr><td colspan="3" align="left" >&nbsp;</td></tr>';
  }
  $html .='</tbody>
  <tfoot>
  <tr style="background-color:#DCDCDC;" ><td colspan="2" align="right" ><strong>Previous Balance</strong></td>
  <td align="right" ><strong>'.number_format($data->CustomerBal,2, '.', '').'</strong></td></tr>
  <tr style="background-color:#ffffff;" ><td colspan="2" align="right" ><strong>Received  Amount</strong></td>
  <td align="right" ><strong>'.number_format($Amount,2, '.', '').'</strong></td></tr>
  <tr style="background-color:#DCDCDC;" ><td colspan="2" align="right" ><strong>Current Balance</strong></td>
  <td align="right" ><strong>'.number_format(($data->CustomerBal-$Amount),2, '.', '').'</strong></td></tr>
  </tfoot>
  </table>
  <table width="100%" border="0" cellspacing="0" cellpadding="3">
    <tr>
    <td  colspan="3" ><b> Amount In Words : </b> '. $data->W.' </span></td>
     
    </tr>
    <tr>
    <td  colspan="3" ><b> Collection Mode : </b> '. $data->PayMode.' </span></td>
     
    </tr>
    </table>
    </td><td valign="top" width="25%"> 
 
  <table  width="100%" border="0" style="color:#929292"  cellspacing="0"  cellpadding="5"  >
  <tr><th colspan="5" style="background-color: #f1c40f  ;color:rgba(255,255,255,1.00);font-weight:bold">Denomination</th></tr>  
  <tbody style="background-color: #E5E4E2  ;color:#000;">

      <tr>
        <td style="padding:2px">2000 </td>
        <td width="20" align="center">x</td>
        <td>'.floatval($data->N2000).'</td>
        <td  width="20" align="center">=</td>
        <td align="right" >'.floatval($data->V2000).'</td>
      </tr>
      <tr>
      <td style="padding:2px">1000 </td>
      <td width="20" align="center">x</td>
      <td>'.floatval($data->N1000).'</td>
      <td  width="20" align="center">=</td>
      <td align="right">'.floatval($data->V1000).'</td>
    </tr>
    <tr>
    <td style="padding:2px">500 </td>
    <td width="20" align="center">x</td>
    <td>'.floatval($data->N500).'</td>
    <td  width="20" align="center">=</td>
    <td align="right">'.floatval($data->V500).'</td>
  </tr>

  <tr>
  <td style="padding:2px">200 </td>
  <td width="20" align="center">x</td>
  <td>'.floatval($data->N200).'</td>
  <td  width="20" align="center">=</td>
  <td align="right">'.floatval($data->V200).'</td>
</tr>
<tr>
  <td style="padding:2px">100 </td>
  <td width="20" align="center">x</td>
  <td>'.floatval($data->N100).'</td>
  <td  width="20" align="center">=</td>
  <td align="right">'.floatval($data->V100).'</td>
</tr>
<tr>
  <td style="padding:2px">50 </td>
  <td width="20" align="center">x</td>
  <td>'.floatval($data->N50).'</td>
  <td  width="20" align="center">=</td>
  <td align="right">'.floatval($data->V50).'</td>
</tr>
<tr>
  <td style="padding:2px">20 </td>
  <td width="20" align="center">x</td>
  <td>'.floatval($data->N20).'</td>
  <td  width="20" align="center">=</td>
  <td align="right">'.floatval($data->v20).'</td>
</tr>
<tr>
  <td style="padding:2px">10 </td>
  <td width="20" align="center">x</td>
  <td>'.floatval($data->N10).'</td>
  <td  width="20" align="center">=</td>
  <td align="right">'.floatval($data->V10).'</td>
</tr>
<tr style="background-color: #f1c40f;color:#ffffff" >
  <td style="padding:2px" colspan="4" ><b>Total</b> </td>
  <td align="right"><b>'.floatval($Damt).'</b></td>
</tr>


      </table>
</td></tr></table>
  <table width="100%" border="0" cellspacing="0" cellpadding="3">
    
     
    <tr>
      <td align="left"  height="80" >'.$data->EmployeeName.'<br><b>Authorized by</b> </td>
      <td align="center"    > </td>
      <td  colspan="5" align="right"   ><b>Approved by</b></td>
    </tr>
	</table>
  
  <div align="center">THANK YOU FOR YOUR BUSINESS!</div>
  </body>
</html>
  ';
  if($PTY==1)
  { 
  echo $html;
  }
 
 
  if($PTY==2)
 {  
     include('print.php');
  }
?>