<?php
$qry="exec Print_Sales ".$ID;
$res=$this->db->query($qry);
$data=$res->row();
$PRI='';
$filename=$data->DcNo;
if($PTY==1)
{
$PRI=' onLoad="window.print();window.close()"';
}
 
$Logo = file_get_contents(spath.'upload/logo.png');
$Logo = base64_encode($Logo);
$UpiFile = file_get_contents(spath.'upload/QRCode.png');
$UpiFile = base64_encode($UpiFile);
$html='
 <!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
table { font-family:verdana, arial, sans-serif;
font-size:11pt;
 }
</style>
</head>
<body '.$PRI.'  >
<table width="100%" border="0" cellspacing="0" cellpadding="3">
  <tbody>
    <tr>
      <td style="border-right:1px dotted #646464;border-bottom:1px dotted #646464;" width="65%"><div>
        <div align="left"><img width=50 height=50 src="data:image/png;base64,'.$Logo.'" ></div>  <div style="margin-top:-25px" align="center"><strong style="font-size:28px;color:#f6290c" >INVOICE</strong></div>
          <table width="100%" border="0" cellspacing="0" cellpadding="0">
            <tbody>
              <tr>
                <td colspan="4" style="border-bottom:4px double #f6290c " valign="bottom" > 
                  </td> 
              </tr>
              <tr>
                <td colspan="4">&nbsp;</td>
              </tr>
              <tr>
                <td align="center" valign="top" style="border-right:1px dotted #646464"><div><strong>Inv NO</strong></div>
                  <br>
                  '.$data->DcNo.'</td>
				  <td align="center" valign="top" style="border-right:1px dotted #646464"><div><strong>Inv DATE</strong></div>
                  <br>
                  '.$data->DAT.'</td>
                <td align="center" valign="top" style="border-right:1px dotted #646464"><div><strong>Ref No</strong></div>
                  <br>
                  '.$data->RefNo.'</td>
                <td align="center" valign="top"  ><div><strong>Ref Date</strong></div>
                  <br>
                  '.$data->RDAT.'</td>
              </tr>
            </tbody>
          </table>
        </div></td>
      <td style="border-bottom:1px dotted #646464;"  width="35%"><div align="left" >
          <storng style="color:#f6290c;font-weight:bolder;font-size:16px" >'.Branch.'</storng><br>
          '.Address.'<br>
          '.City.',<br>
          Pincode -'.PinCode.',<br>
          <b>Mobile : '.MobileNo.','.Phone.'</b> <br>
          Email : '.Email.'<br>
          GSTIN : '.GST.'</div></td>
    </tr>
    <tr>
      <td style="border-right:1px dotted #646464;" >
	   <table width="100%"><tr> 
	  <td align="left" ><h1>Rs . '.$data->TotalAmount.'</h1></td>
	  <td align="center" >  
    <table><tr><td>
    <b>BankName</b> : '.BankName.'</td></tr><tr><td>
	  <b>AccountName</b> : '.AccountName.'</td></tr><tr><td>
	  <b>AccountNo</b>   : '.AccountNo.'</td></tr><tr><td>
	  <b>IFSC</b>        : '.IFSC.'</td></tr><tr><td>
	  <b>UPI </b>        : '.UPI.'</td></tr>
	  </table>
	  </td>  
	  <td align="right"  > <img width=100 height=100 src="data:image/png;base64,'.$UpiFile.'" >
 </td></tr></table>
	  </td>
      <td ><div align="left" >
          <label style="color:#8C8C8C">Customer</label>
          <br>
          <div style="color:#f6290c;font-size:18px" >'.$data->CustomerName.'</div>
          '.$data->Address.','.$data->Address1.'<br>
          '.$data->City.',<br>
          Pincode-'.$data->ZipCode.',<br>
          Mobile : '.$data->Phone.' <br>
          Email : '.$data->Email.' </div></td>
    </tr>
  </tbody>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="5">
   
    <tr style="font-weight:bold"  >
      <td style="background-color:#f6290c;color:rgba(255,255,255,1.00);font-weight:bold">SNO</td>
      <td align="left" style="background-color:#f6290c;color:rgba(255,255,255,1.00);font-weight:bold">Item Name</td>
      <td align="left" style="background-color:#f6290c;color:rgba(255,255,255,1.00);font-weight:bold">No Of Box</td>
      
      <td align="right" style="background-color:#f6290c;color:rgba(255,255,255,1.00)">No Of Birds</td>
      <td align="right" style="background-color:#f6290c;color:rgba(255,255,255,1.00)">Load Weight </td>
      <td align="right" style="background-color:#f6290c;color:rgba(255,255,255,1.00)">Empty Weight </td>
      <td align="right" style="background-color:#f6290c;color:rgba(255,255,255,1.00)">Net Value</td>
      <td align="right" style="background-color:#f6290c;color:rgba(255,255,255,1.00)">Rate</td>
      <td align="right" style="background-color:#f6290c;color:rgba(255,255,255,1.00)">Amount</td>
 
    </tr>
 
  <tbody>';
  $qry="exec Print_Sales_det ".$ID;
  $ress=$this->db->query($qry);
  $cou=1;
  $TaxVal=0;$Amount=0;
  foreach($ress->result() as $row)
  {
	  $html .='<tr>
	  <td style="border-bottom:1px dotted #646464;" >'.$cou.'</td>
    <td align="left"  style="border-bottom:1px dotted #646464;" >'.$row->ItemName.'</td>
    <td align="left"  style="border-bottom:1px dotted #646464;" >'.$row->Cages.'</td>
    <td align="right" style="border-bottom:1px dotted #646464;" >'.floatval($row->Qty).'</td>
    <td align="right" style="border-bottom:1px dotted #646464;" >'.$row->LoadWeight.'</td>
    <td align="right" style="border-bottom:1px dotted #646464;" >'.$row->EmptyWeight.'</td>
    <td align="right" style="border-bottom:1px dotted #646464;" >'.$row->NetValue.'</td>
	  <td align="right" style="border-bottom:1px dotted #646464;" >'.$row->Rate.'</td>
	  <td align="right" style="border-bottom:1px dotted #646464;" >'.$row->Amount.'</td>
   </tr>';
	  $cou++;
	 
	  $Amount +=$row->Amount;
  }
  for($i=0;$i<1; $i++)
  {
	   $html .= '<tr><td colspan="9" align="left" >&nbsp;</td></tr>';
  }
  $html .='</tbody>
  <tfoot>
  <tr style="background-color:#DCDCDC;" ><td colspan="8" align="right" ><strong>Total</strong></td>
  <td align="right" ><strong>'.number_format($Amount,2, '.', '').'</strong></td></tr>
  <tr style="background-color:#ffffff;" ><td colspan="8" align="right" ><strong>Previous Balance</strong></td>
  <td align="right" ><strong>'.number_format($data->Balance,2, '.', '').'</strong></td></tr>
  <tr style="background-color:#DCDCDC;" ><td colspan="8" align="right" ><strong>Current Balance</strong></td>
  <td align="right" ><strong>'.number_format(($Amount+$data->Balance),2, '.', '').'</strong></td></tr>
  </tfoot>
  </table>
  <table width="100%" border="0" cellspacing="0" cellpadding="3">
    <tr>
    <td  colspan="7" ><b> Amount In Words : </b> '. $data->W.' </span></td>
     
    </tr>
     
    <tr>
      <td align="left"  height="100" >'.$data->EmployeeName.'<br><b>Delivery by</b> </td>
      <td align="center"    > </td>
      <td  colspan="5" align="right"   ><b>Approved by</b></td>
    </tr>
	</table>
  
  <div align="center">THANK YOU FOR YOUR BUSINESS!</div>
  </body>
</html>
  ';
  if($PTY==1)
  { 
  echo $html;
  }
 
 
  if($PTY==2)
 {  
     include('print.php');
  }
?>