<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>DC</title>
<style>
@import url('https://fonts.googleapis.com/css?family=Roboto:400,500,700&subset=cyrillic,vietnamese');
* {
	font-family: 'Roboto', sans-serif;
}
</style>
</head>
<?php
 $qry="exec Get_Dc_Item 1";
 $res=$this->db->query($qry);
 $cus=$res->row();
?>
<body onLoad="window.print();window.close()" >
<table width="100%" border="0" cellspacing="0" cellpadding="0" style="border:1px solid #5A5A5A" >
  <tbody>
    <tr>
      <td colspan="2" bgcolor="#FB5253" align="center" style="font-size:18px;border-bottom:1px solid #5A5A5A;color:#FFFFFF" ><strong>Delivery Challan </strong></td>
    </tr>
    <tr>
      <td style="padding:5px;border-right:1px solid #5A5A5A" width="92" ><img width="92" height="72" src="<?php  echo scs_url; ?>assets/mede.png" ></td>
      <td style="padding:5px;" align="right" valign="top"><strong> Madurai Mede </strong>
        <address>
        Plot No 5, Jeyam Avenue,<br>
        4th Sub-cross Street, Uthangudi,<br>
        Madurai - 625107
        </address></td>
    </tr>
  </tbody>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="0" style="border:1px solid #5A5A5A;border-top:none" >
  <tbody>
    <tr bgcolor="#FB5253"  >
      <td style="padding:2px;border-bottom:1px solid #5A5A5A;border-right:1px solid #5A5A5A;color:#FFFFFF" >Delivery Address</td>
      <td style="padding:2px;border-bottom:1px solid #5A5A5A;color:#FFFFFF" >Billing Address</td>
    </tr>
    <tr>
      <td style="padding:5px;border-right:1px solid #5A5A5A" width="50%"  align="left" ><strong> <?php echo $cus->CustomerName; ?> </strong>
        <address>
        
        <?php echo $cus->Address; ?>,<br>
        <?php echo $cus->Address1; ?><br>
          <?php echo $cus->City; ?>-<?php echo $cus->ZipCode; ?><br>
           <?php echo $cus->Mobile; ?>
        </address></td>
      <td style="padding:5px;" align="left" valign="top">
      <strong> <?php echo $cus->CustomerName; ?> </strong> <address>
       
        <?php echo $cus->Address; ?>,<br>
        <?php echo $cus->Address1; ?><br>
          <?php echo $cus->City; ?>-<?php echo $cus->ZipCode; ?><br>
           <?php echo $cus->Mobile; ?>
        </address></td>
    </tr>
  </tbody>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="4" style="border:1px solid #5A5A5A;border-top:none" >
  <thead>
    <tr style="background-color:#FBD4D4" >
      <th style="border-right:1px solid #5A5A5A;border-bottom:1px solid #5A5A5A;" width="10">Sno</th>
      <th style="border-right:1px solid #5A5A5A;border-bottom:1px solid #5A5A5A;" width="10%"  >CatNo</th>
      <th style="border-right:1px solid #5A5A5A;border-bottom:1px solid #5A5A5A;">ItemName</th>
      <th style="border-right:1px solid #5A5A5A;border-bottom:1px solid #5A5A5A;"  width="10%" >RefNo</th>
      <th style="border-right:1px solid #5A5A5A;border-bottom:1px solid #5A5A5A;"  width="10%" >BatchNo</th>
      <th style="border-right:1px solid #5A5A5A;border-bottom:1px solid #5A5A5A;"  width="10%" >Exp.Dat</th>
      <th style="border-right:1px solid #5A5A5A;border-bottom:1px solid #5A5A5A;"  width="10%" >Qty</th>
      <th style="border-right:1px solid #5A5A5A;border-bottom:1px solid #5A5A5A;"  width="10%" >Uom</th>
    </tr>
  </thead>
  <tbody style="font-size:14px" >
    <?php 
  
 
  $i=1;
  foreach($res->result() as $row)
  {
  
    echo '<tr>
      <td style="border-right:1px solid #5A5A5A;background-color:#F4F4F4" width="10">'. $i.'</td>
      <td style="border-right:1px solid #5A5A5A;" width="10%"  >'.$row->CatNo.'</td>
      <td style="border-right:1px solid #5A5A5A;background-color:#F4F4F4">'.$row->ItemName.'</td>
      <td style="border-right:1px solid #5A5A5A;"  width="10%" >'.$row->RefNo.'</td>
      <td style="border-right:1px solid #5A5A5A;background-color:#F4F4F4"  width="10%" >'.$row->BatchNo.'</td>
      <td style="border-right:1px solid #5A5A5A;"  width="10%" >'.$row->ED.'</td>
      <td style="border-right:1px solid #5A5A5A;background-color:#F4F4F4"  width="10%" align="right" >'.floatval($row->Qty).'</td>
      <td style="border-right:1px solid #5A5A5A;"  width="10%" >'.$row->Symbol.'</td>
    </tr>';
    $i++;  
 
  }
 for($j=$i;$j<10;$j++)
 {
	  echo '<tr>
      <td style="border-right:1px solid #5A5A5A;background-color:#F4F4F4" width="10"> </td>
      <td style="border-right:1px solid #5A5A5A;" width="10%"  > </td>
      <td style="border-right:1px solid #5A5A5A;background-color:#F4F4F4"> </td>
      <td style="border-right:1px solid #5A5A5A;"  width="10%" > </td>
      <td style="border-right:1px solid #5A5A5A;background-color:#F4F4F4"  width="10%" > </td>
      <td style="border-right:1px solid #5A5A5A;"  width="10%" > </td>
      <td style="border-right:1px solid #5A5A5A;background-color:#F4F4F4"  width="10%" align="right" > </td>
      <td style="border-right:1px solid #5A5A5A;"  width="10%" >&nbsp;</td>
    </tr>';
 }
 ?>
  </tbody>
</table>
<table width="100%" border="0" cellspacing="0" cellpadding="4" style="border:1px solid #5A5A5A;border-top:none" >
<tr><td width="50%" style="border-right:1px solid #5A5A5A;" ><div style="float:left;padding-left:15px;">Received the above goods in good condition</div> </td>
<td align="right" valign="top">
			<div style= "float:right;padding-right: 15px;text-align: left;" ><span style="font-size: 13.5px;"><b >For Madurai Mede</b></span></div></td></tr>

<tr><td width="50%" height="100" style="border-right:1px solid #5A5A5A;" align="left" valign="bottom" ><strong> Customer Signature</strong></td>
<td align="right" valign="bottom"><strong>Authorised Signatory</strong></td></tr>

</table>
</body>
</html>
