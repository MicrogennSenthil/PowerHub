<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>COSTEC INDUSTRIES LLP</title>
<style>
table {
	border-collapse: collapse;
}
</style>
</head>
<?php
$qry="exec Get_PurchaseOrder ".$IDD;
$res=$this->db->query($qry);

$res=$res->row();
?>
<!-- -->
<body onLoad="window.print() ;window.close()" >
<table width="100%" cellpadding="3" cellspacing="0">
  <tbody>
    <tr align="center">
      <td colspan="2" rowspan="3" style="border-top:1px solid #000000;border-right:1px solid #000000;border-left:1px solid #000000;
      border-bottom:1px solid #000000;"><img width="120" height="86" src="<?php echo scs_url.'assets/cosmo-pumps-logo.png'; ?>" alt="Costec Logo" /></td>
      <td colspan="5" style="border-top:1px solid #000000;border-right:1px solid #000000;border-left:1px solid #000000;
      border-bottom:1px solid #000000;font-weight:bold;">COSTEC INDUSTRIES LLP</td>
    </tr>
    <tr align="center">
      <td colspan="5" style="border-right:1px solid #000000;border-left:1px solid #000000;
      border-bottom:1px solid #000000;font-weight:bold;"><p>S.F.NO 544/2B1, AVINASHI ROAD, NILAMBUR,</p>
        <p>COIMBATORE - 641062</p></td>
    </tr>
    <tr align="center">
      <td colspan="5" style="border-right:1px solid #000000;font-weight:bold;">GST IN : 33AAXFR0528D1Z8</td>
    </tr>
    <tr>
      <td colspan="7" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000; padding-left:50px;">E-mail : purchase@cosmopumps.com, Phone : 0422 2974949, Mobile : +91 7639011411</td>
    </tr>
  </tbody>
</table>
<table width="100%" cellpadding="5" cellspacing="0">
  <tbody>
    <tr>
      <td width="792" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;font-weight:bold;">CONSIGNOR ADDRESS : <strong><?php echo $res->LedgerName; ?></strong></td>
      <td align="center" colspan="2" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;font-weight:bold;">PURCHASE ORDER</td>
    </tr>
    <tr>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;"><?php echo $res->Address1; ?>,<?php echo $res->Address2; ?>,<?php echo $res->City; ?>-<?php echo $res->Pincode; ?></td>
      <td width="273" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">P.O NO.</td>
      <td width="253" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;"><?php echo $res->OrderNo; ?></td>
    </tr>
    <tr>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;"><?php echo $res->Phone; ?>,<?php echo $res->Email; ?></td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">ORDER DATE</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;"><?php echo $res->Dat; ?></td>
    </tr>
    <tr>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">GST IN : </td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">P. O VALUE</td>
      <td align="left" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;"><strong><?php echo $res->TotalAmount; ?></strong></td>
    </tr>
  </tbody>
</table>
<table width="100%" cellpadding="5" cellspacing="0">
  <tbody>
    <tr align="center">
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;font-weight:bold;">S.NO.</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;font-weight:bold;">PART NO.</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;font-weight:bold;">PART DESCRIPTION</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;font-weight:bold;">SCHEDULE</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;font-weight:bold;">UOM</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;font-weight:bold;">QTY</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;font-weight:bold;">RATE(Rs.)</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;font-weight:bold;">TOTAL VALUE</td>
    </tr>
    
 <?php
 $qry="exec Get_Purchase_Order_Det ".$IDD;
 $Data=$this->db->query($qry);
 $cou=1;$AMT=0;
 foreach($Data->result() as $row )
 {
	 
   
   echo '<tr>
      <td align="center" 
	  style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">'.$cou.'</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">'.$row->PartNumber.'</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">'.$row->Itemname.'</td>
	  
	     <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">'.$row->Leadtime.'</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">'.$row->SYMBOL.'</td>
      <td align="right" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">'.$row->Qty.'</td>
      <td align="right" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">'.$row->Rate.'</td>
      <td align="right" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">'.$row->Amount.'</td>
    </tr>';
    $AMT +=$row->Amount;
    $cou++; } ?>  
    
    <tr align="right">
      <td colspan="7" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">TOTAL</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;"><strong><?php echo $AMT;?></strong></td>
    </tr>
    <tr align="right">
      <td colspan="7" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">CGST( 9% )</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;"><?php echo $res->CGST; ?></td>
    </tr>
    <tr align="right">
      <td colspan="7" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">SGST( 9% )</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;"><?php echo $res->SGST; ?></td>
    </tr>
    <tr align="right">
      <td colspan="7" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">TOTAL</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;"><strong><?php echo $res->TotalAmount; ?></strong></td>
    </tr>
    <tr>
      <td colspan="3" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">Terms and Conditions:</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">&nbsp;</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">&nbsp;</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">&nbsp;</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">&nbsp;</td>
      <td style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">&nbsp;</td>
    </tr>
    <tr>
      <td colspan="8" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">1. GST Extra as applicable</td>
    </tr>
    <tr>
      <td colspan="3" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">Prepared by</td>
      <td colspan="3" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">Checked by</td>
      <td colspan="4" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;">Approved by</td>
    </tr>
    <tr>
      <td align="center" colspan="8" style="border-left:1px solid #000000;border-right:1px solid #000000;border-bottom:1px solid #000000;font-weight:bold;">This is a system generated document signature not required</td>
    </tr>
  </tbody>
</table>
</body>
</html>
