<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Reprint','Purchase');
$this->pfrm->FrmHead2('Reprint / Purchase',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");
 
?>
<div id="content-wrapper">
	
	<div class="row">
		<div class="col-sm-12">
			<div class="panel">
				<div class="panel-heading"> <span class="panel-title">Purchase Invoice</span> <button id="print" class="btn btn-info btn-sm  pull-right mr10" value="<?php echo base64_decode($_GET['Key']); ?>"> <i class="fa fa-print" aria-hidden="true"></i> Print</button>  </div>
				<div class="panel-body Print_div">
					<?php $this->view('Template/PurchaseInvoice');?>
				</div>
			</div>
		</div>
	</div>
</div>
 <?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
	$("#print").on("click", function () { 
		var divContents = $(".Print_div").html();
		var mywindow = window.open('', 'csv', 'height=200,width=300'); 
		mywindow.document.write('<html><head><title></title>');
		mywindow.document.write('<style type="text/css"> * { font-size:10px; }</style> ');
		mywindow.document.write('<style type="text/css" media="print"> .breakAfter{ page-break-after: always; } </style> '); 
		mywindow.document.write('</head><body >');   
		mywindow.document.write(divContents); 
		mywindow.document.write('</body></html>');
		mywindow.document.close();
		mywindow.print();
	        mywindow.close();
	});
</script>

 