<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
									  
									  $QRY = "SELECT * FROM Trans_Sales TP
										INNER JOIN Mas_Ledger ML ON ML.LGID = TP.LID
									WHERE isnull(AP,0)=1 and  convert(DATE,TP.PODATE) >= '".$this->Myclass->DateSplit($_POST['Fdate'])."' AND 
									convert(DATE,TP.PODATE) <= '".$this->Myclass->DateSplit($_POST['Tdate'])."' ";
									  
									  $qry = $this->db->query($QRY);
			$ftu = $qry->result();
			$res = 	'<table id="streaskit_table" class="table table-striped table-bordered">
	            		<thead>
	              			<tr>
	                			<th >#</th>
				                <th>INV No</th>
				                <th>INV Date</th>
				                <th>Suplier</th>
				                <th>Price</th>
				                <th>Action</th>
	              			</tr>
	            		</thead>
            			<tbody>';
        			  	$cou=1;
        			  	foreach($ftu as $Row) {

                     	$res .= '<tr>
                        			<td>'.$cou.'</td>
                        			<td>'.$Row->PONO.'</td>
                        			<td>'.date('d/m/Y',strtotime($Row->PODATE)).'</td>
                        			<td>'.$Row->LNAME.'</td>
                        			<td>₹ '. $Row->TOTALAMT.'</td> 
                        			<td> ';
                       
                        	$res .= '<a href="'.scs_index.'Reprint/PrintSalInv/?Key='.base64_encode($Row->PPID).'" class="btn btn-success btn-sm" ><i class="fa fa-print" aria-hidden="true"></i> Print</a>';

                        
                      	$res .=	'</tr>';

        			  $cou++;
        			  }
		            $res .=	'</tbody>
		          		</table>';

		          		echo $res; 
 
?>
  