<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$qry="exec Reprint_Receipt ".$_GET['idd'];
$res=$this->db->query($qry);
$R=$res->row();
$res=$res->result();
 ?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Receipt</title>
<style>
.mytable {
	border-collapse: collapse;
	width: 100%;
	font-size: 13px;
	color: #000000 !important;
}
.mytable thead   {
	/* Permalink - use to edit and share this gradient: http://colorzilla.com/gradient-editor/#eeeeee+0,cccccc+100;Gren+3D */
background: #eeeeee; /* Old browsers */
background: -moz-radial-gradient(center, ellipse cover, #eeeeee 0%, #cccccc 100%); /* FF3.6-15 */
background: -webkit-radial-gradient(center, ellipse cover, #eeeeee 0%,#cccccc 100%); /* Chrome10-25,Safari5.1-6 */
background: radial-gradient(ellipse at center, #eeeeee 0%,#cccccc 100%); /* W3C, IE10+, FF16+, Chrome26+, Opera12+, Safari7+ */
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#eeeeee', endColorstr='#cccccc',GradientType=1 ); /* IE6-9 fallback on horizontal gradient */

}
.mytable thead th  {
		padding: 4px !important;
	border: solid #D9D9D9 1px;
	color: #2F2F2F !important;
	font-weight: bold !important;
}
.mytable td {
	padding: 2px;
	border: solid #CDCDCD 1px;
	font-weight: normal !important;
	background-color: #FFFFFF;
}
.tfoot td,.mytable tfoot td

{
	background-color:rgba(233,233,233,1.00) !important;
	color:rgba(255,0,0,1.00) !important;
	font-weight:bolder !important;
	font-size:14px;
}


</style>
</head>

<body onLoad="window.print();window.close()" >
<table width="100%" border="0"  >
  <tbody>
    <tr>
      <td align="center" style="font-size:18px;font-weight:bold" > Ramprakash Jewellery </td>
    </tr>
    <tr>
      <td align="center" > Shop No-434, Big Bazaar St, Town Hall,<br>
        Coimbatore, Tamil Nadu 641001</td>
    </tr>
    <tr>
      <td align="center" ><strong>Phone</strong>: 098940 14838</td>
    </tr>
  </tbody>
</table>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tbody>
    <tr>
      <td width="12%"><strong>RecNo</strong></td>
      <td width="62%"><?php echo $R->RecNo; ?></td>
      <td width="5%"><strong>Date</strong></td>
      <td width="21%"><?php echo $R->Dat; ?></td>
    </tr>
    <tr>
      <td width="12%" valign="top"><strong>Customer</strong></td>
      <td width="62%"><?php echo $R->Titel.' '.$R->FirstName; ?><br>
        <?php echo $R->Address; ?></td>
      <td width="5%"></td>
      <td width="21%"></td>
    </tr>
  </tbody>
</table>
<table class="mytable"  >
  <thead>
    <tr>
      <th>Due</th>
      <th>Due Date</th>
      <th>Amount</th>
    </tr>
  </thead>
  
  <tbody>
  <?php
  $Amount=0;
  foreach($res as $row)
  {
	  echo '<tr>';
	  echo '<td>'.$row->DueNumber.'</td>';
	  echo '<td>'.$row->DueDatee.'</td>';
	  echo '<td align="right">'.$row->Amount.'</td>';
	  echo '</tr>';
	  $Amount +=$Amount+$row->Amount;
  }
  $qrys="SELECT dbo.NumToWords(".$Amount.",'Y') AS Amt";
  $wrd=$this->db->query($qrys);
  $wrd=$wrd->row();
  ?>
  </tbody>
   <tfoot>
  <tr>
  <td align="right" colspan="2"> Total</td>
  <td align="right" ><?php echo number_format( $Amount,2) ; ?></td>
  </tr>
  </tfoot>
</table>
<table width="100%" border="0" cellspacing="2" cellpadding="2">
  <tbody>
    <tr>
      <td><strong>Amount In Words :</strong> <?php echo $wrd->Amt; ?></td>
    </tr>
    <tr><td align="center"><br><br><strong>Thank You for Your Business!</strong></td></tr>
  </tbody>
</table>

</body>
</html>
