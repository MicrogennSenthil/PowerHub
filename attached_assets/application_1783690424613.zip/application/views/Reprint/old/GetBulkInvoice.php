 


<div id="content-wrapper">
	
	<div class="row">
		<div class="col-sm-12">
			<div class="panel">
				<div class="panel-heading"> <span class="panel-title">Sales Invoice</span> 
                <a id="print" class="btn btn-info btn-sm  pull-right mr10" > <i class="fa fa-print" aria-hidden="true"></i> Print</a>  </div>
				<div class="panel-body Print_div">
					<?php $this->view('Template/SalesInvoice');?>
				</div>
			</div>
		</div>
	</div>
</div>
  
<script>
	$("#print").on("click", function () { 
		var divContents = $(".Print_div").html();
		var mywindow = window.open('', 'csv', 'height=200,width=300'); 
		mywindow.document.write('<html><head><title></title>');
		mywindow.document.write('<style type="text/css"> * { font-size:13px; }</style> ');
		mywindow.document.write('<style type="text/css" media="print"> .breakAfter{ page-break-after: always; } </style> '); 
		mywindow.document.write('</head><body >');   
		mywindow.document.write(divContents); 
		mywindow.document.write('</body></html>');
		mywindow.document.close();
		mywindow.print();
	        mywindow.close();
	});
</script>

 