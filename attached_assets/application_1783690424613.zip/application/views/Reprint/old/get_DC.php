<?php

$QRRY = "SELECT * FROM Trans_DC TP
										INNER JOIN Mas_Ledger ML ON ML.LGID = TP.LID
									WHERE convert(DATE,TP.PODATE) >= '".$this->Myclass->DateSplit($_POST['Fdate'])."' AND 
									convert(DATE,TP.PODATE) <= '".$this->Myclass->DateSplit($_POST['Tdate'])."' AND TP.AP = 1 AND
									TP.STOREID=1 ORDER BY convert(DATE,TP.PODATE) DESC";
 
 
		$qry = $this->db->query($QRRY);
		$ftu = $qry->result();
		$res = 	'<table id="example1" class="table table-striped table-bordered">
            		<thead>
              			<tr>
                			<th >#</th>
			                <th>DC No</th>
			                <th>DC Date</th>
			                <th>Ref No</th>
			                <th>Ref Date</th>
			                <th>Customer</th>
			                <th>Action</th>
              			</tr>
            		</thead>
        			<tbody>';
	  	$cou=1;
	  	foreach($ftu as $Row) {

     		$res .= '<tr>
        			<td>'.$cou.'</td>
        			<td>'.$Row->PONO.'</td>
        			<td>'.date('d/m/Y',strtotime($Row->PODATE)).'</td>
        			<td>'.$Row->RNO.'</td>
        			<td>'.date('d/m/Y',strtotime($Row->RDATE)).'</td>
        			<td>'.$Row->LNAME.'</td>
        			<td>';
        			 
                        	$res .= '<a href="'.scs_index.'Reprint/PrintDC/?Key='.base64_encode($Row->PPID).'" class="btn btn-success btn-sm" ><i class="fa fa-print" aria-hidden="true"></i> Print</a>';

                        
      			$res .='</tr>';
			$cou++;
	  	}
        $res .=	'</tbody>
	          </table>';
	    echo $res; 



?>
<script>
$('#example1').DataTable();
</script>