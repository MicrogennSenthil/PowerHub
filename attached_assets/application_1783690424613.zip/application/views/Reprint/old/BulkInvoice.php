<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Reprint','BulkInvoice');
$this->pfrm->FrmHead2('Reprint / BulkInvoice',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");
 
?>
 

<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$MemberType_Id; ?>" >
      <table class="FrmTable T-6" >
        <tr>
          <td align="right" class="F_val">From No</td>
          <td align="left"><input type="text"     name="Fdate"   class="scs-ctrl " num=1 />
            <div class="Type" ></div></td>
            <td align="right" class="F_val">To No</td>
          <td align="left"><input type="text"    name="Tdate"   class="scs-ctrl " num=1 />
            <div class="Type" ></div></td>
        
          <td align="left"><a    class="btn btn-success btn-sm"  onClick="GetReceipt()"    >GET</a></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="RepDet" ></div>
</div>
 
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
 <script>
 function GetReceipt()
 {
	 $.ajax({
		type:"POST",
		url:"<?php echo scs_index;?>Reprint/GetBulkInvoice",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.RepDet').html(html);
		}
    })
}
 
 </script>