﻿<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
									  
									  $QRY = "SELECT * FROM Trans_purchase TP
										INNER JOIN Mas_Ledger ML ON ML.LGID = TP.LID
									WHERE isnull(AP,0)<>0 and  convert(DATE,TP.PODATE) >= '".$this->Myclass->DateSplit($_POST['Fdate'])."' AND 
									convert(DATE,TP.PODATE) <= '".$this->Myclass->DateSplit($_POST['Tdate'])."' ";
									  
									  $qry = $this->db->query($QRY);
			$ftu = $qry->result();
			$res = 	'<table id="example1" class="table table-striped table-bordered">
	            		<thead>
	              			<tr>
	                			<th >#</th>
				                <th>GRN No</th>
				                <th>GRN Date</th>
				                <th>Customer</th>
				                <th>Price</th>
				                <th>Action</th>
	              			</tr>
	            		</thead>
            			<tbody>';
        			  	$cou=1;
        			  	foreach($ftu as $Row) {

                     	$res .= '<tr>
                        			<td>'.$cou.'</td>
                        			<td>'.$Row->PONO.'</td>
                        			<td>'.date('d/m/Y',strtotime($Row->PODATE)).'</td>
                        			<td>'.$Row->LNAME.'</td>
                        			<td>₹ '. $Row->TOTALAMT.'</td> 
                        			<td> ';
                       
                        	$res .= '<a href="'.scs_index.'Reprint/PrintPurInv/?Key='.base64_encode($Row->PPID).'" class="btn btn-success btn-sm" ><i class="fa fa-print" aria-hidden="true"></i> Print</a>';

                        
                      	$res .=	'</tr>';

        			  $cou++;
        			  }
		            $res .=	'</tbody>
		          		</table>';

		          		echo $res; 
 
?>
  
<script>
$('#example1').DataTable();
</script>