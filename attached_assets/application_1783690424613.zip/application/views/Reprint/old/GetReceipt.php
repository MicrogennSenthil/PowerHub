<?php
defined('BASEPATH') OR exit('No direct script access allowed');
 
 $qry=" Rep_Receipt_Date '".$this->Myclass->DateSplit($_POST['Fdate'])."','".$this->Myclass->DateSplit($_POST['Tdate'])."'";
 $chit=$this->db->query($qry);
 
?>

<br>
<legend>Chit Date Wise Receipt</legend>
<table class="mytable example1" >
  <thead>
    <tr>
      <th>Sno</th>
      <th>RecNo</th>
      <th>RecDate</th>
      <th>Name</th>
      <th>Mobile</th>
      <th>Code</th>
      <th>Schemes</th>
      <th>Amount</th>
      <th>#Print</th>
    </tr>
  </thead>
  <tbody>
  <?php 
  $cou=1;$Amount=0;
  foreach($chit->result() as $row)
  {
	  echo '<tr>';
	  echo '<td>'.$cou.'</td>';
	  echo '<td>'.$row->RecNo.'</td>';
	  echo '<td>'.$row->RecDate.'</td>';
	  echo '<td>'.$row->Name.'</td>';
	  echo '<td>'.$row->Mobile.'</td>';
	  echo '<td>'.$row->Code.'</td>';
	  echo '<td>'.$row->Schemes.'</td>';
	  echo '<td align="right">'.$row->Amount.'</td>';	  
	  echo '<td align="center"><a onclick="Receipt_Print('.$row->Receipt_Id.')" class="btn btn-warning btn-sm" ><i class="fa fa-print"></i> Print</a></td>';
	  echo '</tr>';
	  $cou++;
	  $Amount +=$row->Amount;
  }
  
  ?>
  </tbody>
 
</table>
<script>
function Receipt_Print(ee)
{
	var url="<?php echo scs_index;?>Reprint/ReceiptPop?idd="+ee;
	 window.open(url,'1419225559871','width=700,height=500,toolbar=0,menubar=0,location=0,status=0,scrollbars=0,resizable=1,left=0,top=0');return false; 
}
</script>