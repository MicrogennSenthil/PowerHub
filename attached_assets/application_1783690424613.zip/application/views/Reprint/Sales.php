<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
 
$this->pfrm->FrmHead3('Reprint / Sales',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");

?>
 <fieldset>
      <table class="FrmTable T-6" >
  <tbody>
    <tr>
      <td class="Loading" ></td>
          <td align="right" class="F_val">From</td>
          <td><input type="text" value="<?php echo date('d/m/Y'); ?>" name="FD" class="scs-ctrl Dat" ></td>
          <td align="right" class="F_val">To</td>
          <td><input type="text" value="<?php echo date('d/m/Y'); ?>" name="TD" class="scs-ctrl Dat" ></td>
          <td> <a   onClick="DcDet_()" class="btn btn-warning btn-xs" ><i class="fa fa-hand-o-right" ></i>GET</a> </td>
    </tr>
  </tbody>
</table>
</fieldset>
 <fieldset class="dcdet" >
 
 </fieldset> 
  
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>
$(document).ready(function(e) {
    DcDet_();
});
function DcDet_()
{
    $.ajax({
		
		type:"POST",
		url:"<?php echo scs_index;?>Reprint/SalesDet",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.dcdet').html(html);
		}
		
		
	})
}

</script>