<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();
$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Reprint','PurchaseOrder');
$this->pfrm->FrmHead2('Reprint / PurchaseOrder',$F_Class."/".$F_Ctrl,$F_Class."/".$F_Ctrl."_View");
 
?>
<div class="col-sm-12">
  <div class="the-box F_ram">
    <fieldset>
    <input type="hidden" name="idv" value="<?php echo @$MemberType_Id; ?>" >
      <table class="FrmTable T-6" >
        <tr>
          <td align="right" class="F_val">From Date</td>
          <td align="left"><input type="text" value="<?php echo date('d-m-Y'); ?>"   name="Fdate"   class="scs-ctrl Dat" />
            <div class="Type" ></div></td>
            <td align="right" class="F_val">To Date</td>
          <td align="left"><input type="text" value="<?php echo date('d-m-Y'); ?>"   name="Tdate"   class="scs-ctrl Dat" />
            <div class="Type" ></div></td>
        
          <td align="left"><a    class="btn btn-success btn-sm"  onClick="GetReceipt()"    >GET</a></td>
        </tr>
      </table>
    </fieldset>
  </div>
  <div class="RepDet" style="padding:10px" ></div>
</div>
<div id="main-menu-bg"></div>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs($F_Ctrl);
?>
<script>

$(document).ready(function(e) {
    GetReceipt();
});

 function GetReceipt()
 {
	 $.ajax({
		type:"POST",
		url:"<?php echo scs_index;?>Reprint/get_PurchaseOrder",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.RepDet').html(html);
		}
    })
}
 
 </script>
 