<?php
$qry="exec Pri_Purchase '".$this->Myclass->DateSplit($_REQUEST['FD'])."','".$this->Myclass->DateSplit($_REQUEST['TD'])."'";
$Res=$this->db->query($qry);
?>


<div class="table-responsive">
  <table class="table table-bed table-hover table-striped mydatatable "  id="example1">
    <thead  >
      <tr>
        <th>Sno</th>
        <th>GrnNo</th>
        <th>SupplierName</th>
        <th>Date</th>
         
        <th>NetValue</th>
        <th style="width:200px !important" align="center" > </th>
      </tr>
    </thead>
    <tbody>
      <?php 
			$Res=$Res->result_array();
			$count=1;
			 
		 foreach($Res as $row)
			{
				 
               echo  '<tr class="odd gradeX">
                      <td>'.$count.' </td>
                      <td>'.$row['DcNo'].'</td>
					  <td>'.$row['SupplierName'].'</td>
					  <td>'.$row['DATE'].'</td>
					  
					  <td>'.$row['NetValue'].'</td>
                      <td align="center">
					  
					  
 
					                
            <a class="btn btn-warning btn-xs" target="_blank" href="'.scs_index.$F_Class."/Print_Purchase/".$row['Purchase_Dc_Id'].'/1"   >
            <b> <i class="fa fa-print"></i> Print</b></a> 
             |
            <a class="btn btn-danger btn-xs" target="_blank" href="'.scs_index.$F_Class."/Print_Purchase/".$row['Purchase_Dc_Id'].'/2"   >
            <b> <i class="fa fa-file-pdf-o"></i> Pdf</b></a> 
					  
					  </td>
                      
                      </tr>';
                 
                 
                
				 $count++;
              
			}
			 ?>
    </tbody>
  </table>
</div>