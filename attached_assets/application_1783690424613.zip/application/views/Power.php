<?php
defined('BASEPATH') OR exit('No direct script access allowed');
$this->pweb->phead();
$this->pcss->wcss();

$this->pweb->wtop();
$this->pweb->wheader($this->session);
$this->pweb->menu($this->Menu,$this->session);
$this->pweb->Cheader('Home','Power');
$this->pfrm->FrmHeadD('Master','','');
$this->db->query("UPDATE Mas_Room SET Status_Id=2,State=0 WHERE isnull(Status_Id,200)=200");
?>
<style>
.RoomHover:hover
	{
		background-color:#F9FDE4;
		cursor: pointer;
		
	}
	.RoomHover
	{margin-left:10px;
		margin-top:10px;}
	.Offline {color:red; }
	.Online {color:green; }
</style>
<section class="content" style="background-color:#F3F3F3">
	<div class="row"   >
	<div class="col-md-12">
		<a onClick="RoomChart('FloorW')" class="btn btn-danger btn-sm"><img width="16" height="16" src="<?php echo scs_url; ?>power/icon/Floor.png" /> Floor</a>
		<a onClick="RoomChart('RoomTypeW')" class="btn btn-danger btn-sm"> <img width="16" height="16" src="<?php echo scs_url; ?>power/icon/roomtype.png" /> RoomType</a>
		 
	</div>
	</div>
	
<div class="row" style="margin-top:5px"   >
<div class="col-md-8 RepDet" >
 <?php include('Power_Det.php'); ?>
  
</div>
<div class="col-md-4 ">
<fieldset class="Rdiv" style="background-color:#FFFFFF;overflow: scroll"  >
<legend>Status</legend>
<table class="table  table-striped" style="width: 100%" >
<thead>
  <tr>
    <th>Device</th>
    <th>Status</th>
    <th></th>
    
  </tr>
</thead>
<tbody>
  <?php
       $qry="Get_Device_Status ".Hotel_Id;
	  $rom=$this->db->query($qry);
			   foreach($rom->result() as $RM)
				{
					echo '<tr>';
					echo '<td class="'.$RM->Status.'" >'.$RM->Device.'</td>';
					echo '<td class="'.$RM->Status.'" >'.$RM->Status.'</td>';
					 
					echo '<td><img   src="'.scs_url.'power/icon/'.$RM->Img.'l.png" /></td>';
					echo '</tr>';
				}
	
	?>
</tbody>
	</table>
</fieldset>
</div>
</div>
<button style="display:none"  type="button" class="btn btn-primary Mbut" data-toggle="modal" data-target=".bd-example-modal-sm">Small modal</button>

<div class="modal fade bd-example-modal-sm" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
  <div id="modal" class="modal-dialog modal-sm">
    <div class="modal-content">
          <div style="text-align: center; padding: 10px;">
      <input type="hidden" id="Room_Id" value="" />
      <input type="hidden" id="Device" value="" />
      <a href="#" onclick="poweronoff(0,1)" class="C1 CTRL btn btn-info btn-block pull-right"><img src="<?php echo scs_url; ?>power/icon/1.png" width="32" height="32" >  Checkin</a>
      <a href="#" onclick="poweronoff(0,7)" class="C1 CTRL btn btn-info btn-block pull-right"><img src="<?php echo scs_url; ?>power/icon/7.png" width="32" height="32" > MD Checkin</a>
      <a href="#" onclick="poweronoff(1,2)" class="C0 CTRL btn btn-info btn-block pull-right"><img src="<?php echo scs_url; ?>power/icon/2.png" width="32" height="32" >  CheckOut</a>
      <a href="#" onclick="poweronoff(0,3)" class="C1 CTRL btn btn-info btn-block pull-right"><img src="<?php echo scs_url; ?>power/icon/3.png" width="32" height="32" >  Cleaning</a>
      <a href="#" onclick="poweronoff(0,4)" class="C1 CTRL btn btn-info btn-block pull-right"><img src="<?php echo scs_url; ?>power/icon/4.png" width="32" height="32" >  Maintenance</a>
      <a href="#" onclick="poweronoff(0,5)" class="C1 CTRL btn btn-info btn-block pull-right"><img src="<?php echo scs_url; ?>power/icon/5.png" width="32" height="32" >  Visiting</a>
      <a href="#" onclick="poweronoff(0,13)" class="C1 CTRL btn btn-info btn-block pull-right"><img src="<?php echo scs_url; ?>power/icon/13.png" width="32" height="32" >  Bypass On</a>
	  <a href="#" onclick="poweronoff(1,14)" class="C0 CTRL btn btn-info btn-block pull-right"><img src="<?php echo scs_url; ?>power/icon/14_ON.png" width="32" height="32" >  Bypass Off</a>
        <button style="display: none" type="button" class="btn btn-secondary Mbutclose" data-dismiss="modal">Close</button>
      <div>&nbsp;</div>
      
    </div>
    </div>
  </div>
</div>
</section>
<?php
$this->pfrm->FrmFoot();
$this->pweb->wfoot();
$this->pcss->wjs(@$F_Ctrl);
?>
<script>
$(document).ready(function(e) {
  
    $('.Rdiv').height($('.Mdiv').height());
});
	var RoomTy='FloorW';
function showTemplateDialog(ID,State)
	{
		$('#Room_Id').val(ID);
		$('.CTRL').hide();
		 $('.C'+State).show();
		$('.Mbut').click();
	}
function  poweronoff (st,Status_Id)
	{
		$.ajax({
		type:"POST",
		url:"<?php echo scs_index; ?>Power/poweronoff/"+$('#Room_Id').val()+"/"+st+"/"+Status_Id+"/1",
		success: function(data)
		{
			$('.Mbutclose').click();
			window.location.reload();
	    },
		error: function(jqXHR,exception)
			{
			
		}
		
	})
	}
	function RoomChart(a)
	{
		$('.MC').hide();
		$('.'+a).show();
		RoomTy=a;
	}
</script>
 
<script>
 setInterval(function() {
		 
		$.ajax({
		type:"POST",
		url:"<?php echo scs_index; ?>Rep/PowerDet",
		data:$('#scsfrm').serialize(),
		success: function(html)
		{
			$('.RepDet').html(html);
			RoomChart(RoomTy);
		}
			
	  })
 },3000);	
 
</script>