<?php

class ByPassonoff extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function ByPassonoff_Val()
	{       
		 $this->form_validation->set_rules('Device_Id', 'Device Name', 'required');
         $this->form_validation->set_rules('Process', 'Process', 'required');
		 
	 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function ByPassonoff_exec()
	{
        $qry= "Exec Exec_BypassPowerpush '".$_REQUEST['Device_Id']."','".$_REQUEST['Process']."','".UserId."'"; 
        $res=$this->db->query($qry);
        $msg=$this->db->error(); 
        $this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>