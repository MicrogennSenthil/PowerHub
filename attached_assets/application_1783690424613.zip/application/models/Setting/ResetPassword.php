<?php

class ResetPassword extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function ResetPassword_Val()
	{
		 $this->form_validation->set_rules('UserName', 'User Id', 'required');
		 $this->form_validation->set_rules('Password', 'Password', 'required');
		 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function ResetPassword_exec()
	{
		  $qry= "exec Exec_Password
					  '".$_REQUEST['UserName']."',					  
					  '".md5($_REQUEST['Password'])."','".@$_REQUEST['idv']."'";
					  $res=$this->db->query($qry);
					  $msg=$this->db->error(); 
					  $this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>