<?php

class Regestermn extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function Regestermn_Val()
	{
		 $this->form_validation->set_rules('MobileNo', 'MobileNo', 'required|regex_match[/^[0-9]{10}$/]');
		 $this->form_validation->set_rules('Password', 'Password', 'required');
	 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function Regestermn_exec()
	{
			  $qry= " Exec_Regester 
			'".$_REQUEST['MobileNo']."','".md5($_REQUEST['Password'])."',
			'".Hotel_Id."','".@$_REQUEST['idv']."','".str_replace(" ","",$_REQUEST['BUT'])."'"; 
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>