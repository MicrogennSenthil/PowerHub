<?php

class User extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function User_Val()
	{
		 $this->form_validation->set_rules('UserName', 'User Id', 'required');
		 $this->form_validation->set_rules('Password', 'Password', 'required');
		 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function User_exec()
	{
		  $qry= "exec Exec_User 
					  '".$_REQUEST['UserName']."',					  
					  '".md5($_REQUEST['Password'])."','".Type."','".$_REQUEST['UserGroup']."','12208757211454','".$_REQUEST['Active']."',
					  '".@$_REQUEST['idv']."','".Hotel_Id."','".str_replace(" ","",$_REQUEST['BUT'])."','".$_REQUEST['EnableONOFFoperation']."'";
					  $res=$this->db->query($qry);
					  $msg=$this->db->error(); 
					  $this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>