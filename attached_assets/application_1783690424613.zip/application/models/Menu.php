<?php

class Menu extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		if(@$this->session->userdata['POS'])
		{
			foreach (@$this->session->userdata['POS'] as $key => $item) {
				define($key,$item);
			}
		}
		
	 
    }
	function Menu_()
	{
		
		 ?>
<div class="collapse navbar-collapse pull-left" id="navbar-collapse">
          <ul class="nav navbar-nav">
<li style="background-color:darkgreen" >
<a href="<?php echo scs_url;?>"><i class="fa fa-home"></i>  </a>
</li>
<li style="background-color:darkred" >
<a href="<?php echo scs_index;?>welcome/main"><i class="fa fa fa-lightbulb-o"></i> </a>
</li>
<?php 
	   $qry=" EXEC dbo.Gen_Menu ".Type;
	   $res=$this->db->query($qry);
	   $categories = array("Categories" => array());
	   foreach($res->result() as $row)
	   {
		   $category = array(); // temp array
		   $category["Menu"] =$row->Menu;
		   $category["Icon"] = "fa  ".$row->Icon;//$row->Icon;		  
		   $category["Des"] = $row->Menu; //$row->Des;	  
		   $category["sub_categories"] = array(); 
		   
		   $qry=" EXEC dbo.Gen_SubMenu ".$row->Menu_Id.",".Hotel_Id.",".Type.",".UserId; 
		 
	       $sres=$this->db->query($qry);
		    foreach($sres->result() as $srow)
		   {
			   $subcat = array();
			   $subcat["Menu"] = $srow->SubMenu;
               $subcat["Des"] = $srow->Dec;
			   array_push($category["sub_categories"], $subcat);
		   }
		   
		   array_push($categories["Categories"], $category);
	   } 
	   
	   $data= json_encode($categories);
		   $data=json_decode($data,true);
		 
	 
		   foreach($data['Categories']   as $da)
		   {
			   if($da['Menu']!="")
				  {
					  $Rep="#";
			         				
			   echo '<li class="dropdown   ">
			         <a href="'.$Rep.'" class="dropdown-toggle menuclo" data-toggle="dropdown" style="color:FFF" > 
					 <i class="'.$da['Icon'].' "></i> '.$da['Menu'].' <i class="fa fa-angle-down "></i> </a>
					 <ul class="dropdown-menu " role="menu">';
			  
				foreach($da['sub_categories']  as   $Sub)
				 {
					 
					 echo '<li style="border-bottom:1px solid color:#CCC" > <a href="'.scs_url.'index.php/'.str_replace(' ','',$da['Des']).'/'.str_replace(' ','',$Sub['Des']).'"><i class="fa fa-caret-right"></i> '.$Sub['Menu'].'</a></li>';
				 }
					echo '  </ul></li>';
			   }
		   }
   
   
   ?>
   </ul>
        </div>
<?php
		 
		return ;
	}
	
	
	
}
?>
