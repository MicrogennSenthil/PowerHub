<?php

class LedgerType extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function LedgerType_Val()
	{
		 $this->form_validation->set_rules('LedgerType', 'LedgerType', 'required');
		 $this->form_validation->set_rules('LedgerTypeCode', 'LedgerTypeCode', 'required');
		 
		 
		 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function LedgerType_exec()
	{
			$qry= " Exec_LedgerType '".$_REQUEST['LedgerTypeCode']."','".$_REQUEST['LedgerType']."','".@$_REQUEST['idv']."','".str_replace(" ","",$_REQUEST['BUT'])."'"; 
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>