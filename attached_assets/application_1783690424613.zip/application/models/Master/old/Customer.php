<?php

class Customer extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function Customer_Val()
	{
		 $this->form_validation->set_rules('CustomerName', 'CustomerName', 'required');
		 $this->form_validation->set_rules('CustomerId', 'Short Name', 'required');	
		 $this->form_validation->set_rules('Address', 'Address 1', 'required');
		  
		 $this->form_validation->set_rules('Phone', 'Phone', 'required');
		 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function Customer_exec()
	{
		 	  $qry= " Exec_Customer 
			'".$_REQUEST['CustomerName']."',
			'".$_REQUEST['CustomerId']."',
			'".$_REQUEST['Address']."',
			'".$_REQUEST['Address1']."',
			 
			'".$_REQUEST['City']."',1,1,
			'".$_REQUEST['ZipCode']."',
			'".$_REQUEST['Phone']."',
			'".$_REQUEST['Mobile']."',
			'".$_REQUEST['Email']."',
			'".$_REQUEST['ContactPerson']."',
			'".$_REQUEST['Keyy']."',
			'".$_REQUEST['OpAmt']."',
			'".$this->Myclass->DateSplit($_REQUEST['OpDate'])."',
			'".$_REQUEST['CMobile']."',
			'".$_REQUEST['CEmail']."',
		    '".$_REQUEST['PAN']."',
			'".$_REQUEST['Message']."', 
			'".$_REQUEST['GSTNo']."','".$_REQUEST['Active']."',".Branch_Id.",
			'".@$_REQUEST['idv']."','".str_replace(" ","",$_REQUEST['BUT'])."'"; 
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>