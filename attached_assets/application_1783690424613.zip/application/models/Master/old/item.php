<?php

class item extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function Item_Val()
	{
		 $this->form_validation->set_rules('ItemName', 'Item Name', 'required');
	     $this->form_validation->set_rules('Group_Id', 'Group', 'required');
		 $this->form_validation->set_rules('Category_Id', 'Category', 'required');
		 $this->form_validation->set_rules('Unit_Id', 'Unit', 'required');
		 $this->form_validation->set_rules('TaxSetup_Id', 'TaxSetup', 'required');
		 
		 
		 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function items_exec()
	{
			$qry= " Exec_Item 			
			'".$_REQUEST['ItemName']."',
			'".$_REQUEST['HSNCode']."',
			 
			'".$_REQUEST['Category_Id']."',
			'".$_REQUEST['Group_Id']."',
			'".$_REQUEST['Unit_Id']."',
			'".$_REQUEST['ReOrder']."',
			'".$_REQUEST['Alias']."',
			'".$_REQUEST['MRP']."',
			'".$_REQUEST['PRate']."',
			'".$_REQUEST['SRate']."',
			'".$_REQUEST['Discount']."',
			'".$_REQUEST['OrederItem']."',
			'".$_REQUEST['MinOrd']."',
			'".$_REQUEST['IsSales']."',
			'".$_REQUEST['Active']."',
			'".$_REQUEST['TaxSetup_Id']."',".Branch_Id.",
			'".@$_REQUEST['idv']."','".str_replace(" ","",$_REQUEST['BUT'])."'"; 
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>