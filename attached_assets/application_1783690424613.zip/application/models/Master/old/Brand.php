<?php

class Brand extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function Brand_Val()
	{
		 $this->form_validation->set_rules('BrandName', 'Brand Name', 'required');
		 
	 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function Brand_exec()
	{
			$qry= " Exec_Brand 
			'".$_REQUEST['BrandName']."','".$_REQUEST['Active']."',
			'".Branch_Id."','".@$_REQUEST['idv']."','".str_replace(" ","",$_REQUEST['BUT'])."'"; 
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>