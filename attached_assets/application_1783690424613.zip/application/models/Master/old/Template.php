<?php

class Template extends CI_Model
{
	function __construct()
    {
        parent::__construct();

    }
	function Template_Val()
	{
		$this->form_validation->set_rules('Supplier_Id', 'Supplier Name', 'required');
	    $this->form_validation->set_rules('Template', 'Template Name', 'required');
        if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function Template_exec()
	{
		if($_POST['BUT']=='SAVE')
		{   
		    $qry= " Exec_Template  
			'".$_REQUEST['Supplier_Id']."',
			'".$_REQUEST['Template']."',
			'".$_REQUEST['Keey']."',".Branch_Id;
			//echo $qry;
			$res=$this->db->query($qry);
			$msg=$this->db->error();
			$this->Myclass->GetRec($msg,$res,$qry);
		}
		if($_POST['BUT']=='UPDATE')
		{   
		    $qry= " Exec_Template_Update  
			'".$_REQUEST['Supplier_Id']."',
			'".$_REQUEST['Template']."',
			'".$_REQUEST['Keey']."',".Branch_Id.",'".$_REQUEST['idv']."'";
			//echo $qry;
			$res=$this->db->query($qry);
			$msg=$this->db->error();
			$this->Myclass->GetRec($msg,$res,$qry);
		}
	}
}
?>
