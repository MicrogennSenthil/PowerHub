<?php

class OpeningStock extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function OpeningStock_Val()
	{
		 $this->form_validation->set_rules('Item_Id', 'Item Name', 'required');
		 
	 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function OpeningStock_exec()
	{
			$qry= " Exec_OpeningStock 
			'".$_REQUEST['Item_Id']."','".$_REQUEST['OpQty']."',
			'".$this->Myclass->DateSplit($_REQUEST['OpDate'])."','".@$_REQUEST['idv']."','".str_replace(" ","",$_REQUEST['BUT'])."'"; 
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>