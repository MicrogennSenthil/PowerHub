<?php

class UnitCreation extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function UnitCreation_Val()
	{
		 $this->form_validation->set_rules('SYMBOL', 'Unit Symbol', 'required');
		 $this->form_validation->set_rules('FLNAME', 'Unit Name', 'required');
		 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function UnitCreation_exec()
	{
			$qry= " Exec_Unit '".$_REQUEST['SYMBOL']."','".$_REQUEST['FLNAME']."',	 
			'".@$_REQUEST['idv']."','".str_replace(" ","",$_REQUEST['BUT'])."'"; 
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>