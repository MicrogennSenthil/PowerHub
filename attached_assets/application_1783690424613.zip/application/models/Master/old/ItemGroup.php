<?php

class ItemGroup extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function ItemGroup_Val()
	{
		 $this->form_validation->set_rules('GroupCode', 'Group Code', 'required');
		 $this->form_validation->set_rules('GroupName', 'Group Name', 'required');
		 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function ItemGroup_exec()
	{
			$qry= " Exec_ItemGroup '".$_REQUEST['GroupName']."','".$_REQUEST['GroupCode']."',	 
			'".@$_REQUEST['idv']."','".str_replace(" ","",$_REQUEST['BUT'])."'"; 
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>