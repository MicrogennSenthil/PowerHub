<?php

class Profile extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function Profile_Val()
	{
		 
		 $this->form_validation->set_rules('Name', 'Name', 'required');
		 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function Profile_exec()
	{
			    $qry= " Exec_Profile 
			 
			'".$_REQUEST['Company']."',
			'".$_REQUEST['Name']."',
			'".$_REQUEST['Address']."',
			'".$_REQUEST['City']."',
			'".$_REQUEST['PinCode']."',
			'".$_REQUEST['Email']."',
			'".$_REQUEST['MobileNo']."',
			'".$_REQUEST['Phone']."',
			1,
			'".$_REQUEST['WEB']."','".$_REQUEST['GST']."'
			,'".$_REQUEST['BankName']."'
			,'".$_REQUEST['AcBranch']."'
			,'".$_REQUEST['AccountName']."'
			,'".$_REQUEST['AccountNo']."'
			,'".$_REQUEST['IFSC']."'
			,'".$_REQUEST['UPI']."'
			 "; 
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>