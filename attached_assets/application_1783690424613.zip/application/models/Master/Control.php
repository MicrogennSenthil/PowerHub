<?php

class Control extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function Control_Val()
	{
		 $this->form_validation->set_rules('Control', 'Control Name', 'required');
		 $this->form_validation->set_rules('Room_Id', 'Room No', 'required');
		 $this->form_validation->set_rules('Device', 'Device', 'required');
		 $this->form_validation->set_rules('Slate', 'Slate', 'required');
	     $this->form_validation->set_rules('ControlType_Id', 'ControlType', 'required');
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function Control_exec()
	{
			$qry= " Exec_Control 
			'".$_REQUEST['Control']."','".$_REQUEST['Room_Id']."','".$_REQUEST['Device']."','".$_REQUEST['Slate']."','".$_REQUEST['ControlType_Id']."',
			'".Hotel_Id."','".@$_REQUEST['idv']."','".str_replace(" ","",$_REQUEST['BUT'])."'"; 
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>