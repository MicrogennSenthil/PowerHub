<?php

class Room extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function Room_Val()
	{
		 $this->form_validation->set_rules('RoomNo', 'Room Name', 'required');
		 $this->form_validation->set_rules('Block_Id', 'Block', 'required');
		 $this->form_validation->set_rules('Floor_Id', 'Floor', 'required');
		 $this->form_validation->set_rules('RoomType_Id', 'RoomType', 'required');
	 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function Room_exec()
	{
			$qry= " Exec_Room 
			'".$_REQUEST['RoomNo']."','".$_REQUEST['Block_Id']."','".$_REQUEST['Floor_Id']."','".$_REQUEST['RoomType_Id']."',
			'".Hotel_Id."','".@$_REQUEST['idv']."','".str_replace(" ","",$_REQUEST['BUT'])."'"; 
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>