<?php

class Device extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function Device_Val()
	{
		 $this->form_validation->set_rules('Device', 'Device Name', 'required|min_length[6]|max_length[6]');
		 $this->form_validation->set_rules('Floor_Id', 'Floor', 'required');
	 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function Device_exec()
	{
			$qry= " Exec_Device 
			'".$_REQUEST['Device']."','".$_REQUEST['IP']."','".$_REQUEST['Floor_Id']."',
			'".Hotel_Id."','".@$_REQUEST['idv']."','".str_replace(" ","",$_REQUEST['BUT'])."'"; 
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>