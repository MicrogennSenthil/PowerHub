<?php

class Process extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function Process_Val()
	{
		 $this->form_validation->set_rules('Process_Id', 'Process', 'required');
		  
	 
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function Process_exec()
	{
			$qry= " Exec_Process 
			'".$_REQUEST['Process_Id']."','".$_REQUEST['Ptime']."','".$_REQUEST['IsAuto']."', 
			'".Hotel_Id."','".@$_REQUEST['idv']."','".str_replace(" ","",$_REQUEST['BUT'])."'"; 
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>