<?php

class Customer extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function Customer_Val()
	{
		 
		 $this->form_validation->set_rules('Name', 'Name', 'required');
		 $this->form_validation->set_rules('Hotel', 'Hotel', 'required');
		 if ($this->form_validation->run() == FALSE)
		 {
			 $output = $this->form_validation->return_f_error($this->input->post());
			 echo $output = json_encode($output);
		 }
		 else
		 {
			 $output = $this->form_validation->return_success($this->input->post());
			 echo $output = json_encode($output);
		 }
	}
	function Customer_exec()
	{
		if ($_REQUEST['BUT']=='SAVE') 
		 {
			$qry= " Exec_Customer 
			'".$_REQUEST['Hotel']."',
			'".$_REQUEST['Name']."',
			'".$_REQUEST['Address']."',
			'".$_REQUEST['City']."',
			'".$_REQUEST['PinCode']."',
			'".$_REQUEST['Email']."',
			'".$_REQUEST['MobileNo']."',
			'".$_REQUEST['Phone']."',
			".$_REQUEST['Active'].",
			'".md5('Password')."',
			'".$_REQUEST['WEB']."','".$_REQUEST['GST']."'
			,'".$_REQUEST['BankName']."'
			,'".$_REQUEST['AcBranch']."'
			,'".$_REQUEST['AccountName']."'
			,'".$_REQUEST['AccountNo']."'
			,'".$_REQUEST['IFSC']."'
			,'".$_REQUEST['UPI']."'
			,'".$_REQUEST['Logo']."'
			,'".$_REQUEST['UpiId']."','".md5(rand().rand().rand())."'
			 "; 
		 }
		if ($_REQUEST['BUT']=='UPDATE') 
		 {
			$qry= " Exec_Customer_Update 
			'".$_REQUEST['Hotel']."',
			'".$_REQUEST['Name']."',
			'".$_REQUEST['Address']."',
			'".$_REQUEST['City']."',
			'".$_REQUEST['PinCode']."',
			'".$_REQUEST['Email']."',
			'".$_REQUEST['MobileNo']."',
			'".$_REQUEST['Phone']."',
			".$_REQUEST['Active'].",
			 
			'".$_REQUEST['WEB']."','".$_REQUEST['GST']."'
			,'".$_REQUEST['BankName']."'
			,'".$_REQUEST['AcBranch']."'
			,'".$_REQUEST['AccountName']."'
			,'".$_REQUEST['AccountNo']."'
			,'".$_REQUEST['IFSC']."'
			,'".$_REQUEST['UPI']."'
			,'".$_REQUEST['Logo']."'
			,'".$_REQUEST['UpiId']."',".$_REQUEST['idv']; 
		 }
			$res=$this->db->query($qry);
			$msg=$this->db->error(); 
			$this->Myclass->GetRec($msg,$res,$qry);
	}
}
?>