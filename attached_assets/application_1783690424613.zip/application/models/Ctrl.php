<?php

class Ctrl extends CI_Model
{
	function __construct()
    {
        parent::__construct();
		 
    }
	function Option_($data,$id,$val,$dval,$text,$selected)
	{
		$html='<option value="'.$dval.'" >'.$text.'</option>';
		 foreach($data as $key)
		 {
		 	$SEL="";
			if($selected==$key->$id){$SEL="selected";}
			$html .='<option '.$SEL.' value="'.@$key->$id.'" >'.@$key->$val.'</option>';
		 }
		echo $html;
	}
function Iframe($data,$Rep='')
	{
 
		$html= '<iframe  class="Iframe priprint"  id="iFrameResizer" onload="onMyFrameLoad(this)"
		       src="http://50.63.165.200:8005/?Qry='.$data.'&_'.rand().rand().rand().'&Rep='.$this->RepHead($Rep).'"  ></iframe> ';
		
		echo $html;
		
	}
	function RepHead($Rep)
	{
		$html='<table width="100%" border="0" cellpadding="5" cellspacing="5">
			  <tbody>
				<tr>
				  <td align="center"><h3>'.@$this->session->userdata['scslog']['STORENAME'].'</h3>
				  <div align="center">'.@$this->session->userdata['scslog']['ADD1'].' <br>
				  '.@$this->session->userdata['scslog']['ADD2'].' <br>
                      Coimbatore - 641042</p></div>
				  </td>
				</tr>
			 
				
				<tr><td><strong>Report Name :</strong> '.$Rep.'</td></tr>
			  </tbody>
			</table>';
			$html=base64_encode($html);
		return $html;	
	}
	
}
?>
