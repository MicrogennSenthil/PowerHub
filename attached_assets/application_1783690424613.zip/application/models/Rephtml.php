<?php

class Rephtml extends CI_Model
{
	function __construct()
    {
        parent::__construct();
    }
    function Purchase(){
		$qry=" AMB_point19to20.dbo.Rep_Inward_Supewise '".$this->Myclass->DateSplit($_REQUEST['Fdate'])."','".$this->Myclass->DateSplit($_REQUEST['Tdate'])."',".MSID.",".$_REQUEST['LGID'].",0";
		$this->Iframe($qry,'Purchase');
      
    }
	function Model(){
		$qry=" Get_Product_Det '".$_REQUEST['Product_Id']."'";
		$this->Iframe($qry,'Consumption');
      
    }
	function MessAttendance(){
	    $qry=" AMB_point19to20.dbo.Rep_Attp '".$this->Myclass->DateSplit($_REQUEST['Fdate'])."','".$this->Myclass->DateSplit($_REQUEST['Tdate'])."',".MSID."";	
		$this->Iframe($qry,'MessAttendance');
      
    }
	function Stock(){
		$qry=" AMB_point19to20.dbo.REP_STOCK ".MSID.",'".$this->Myclass->DateSplit($_REQUEST['Fdate'])."','".$this->Myclass->DateSplit($_REQUEST['Tdate'])."',0,0,0";
		$this->Iframe($qry,'Stock');
      
    }
	
	
	function DateWiseInwardReport(){
		  $qry=" AMB_point19to20.dbo.Rep_Inward_Supewise '".$this->Myclass->DateSplit($_REQUEST['Fdate'])."','".$this->Myclass->DateSplit($_REQUEST['Tdate'])."',".MSID.",".$_REQUEST['LGID'].",0";
		$this->Iframe($qry,'DateWiseInwardReport');
      
    }
	function ItemWiseInward(){
		  $qry=" AMB_point19to20.dbo.Rep_Inward_Itemwise '".$this->Myclass->DateSplit($_REQUEST['Fdate'])."','".$this->Myclass->DateSplit($_REQUEST['Tdate'])."',".MSID.",".$_REQUEST['LGID'].",0";
		$this->Iframe($qry,'DateWiseInwardReport');
      
    }
	
	function DateWiseSales(){
		  $qry=" AMB_point19to20.dbo.Rep_Sales_Datewise '".$this->Myclass->DateSplit($_REQUEST['Fdate'])."','".$this->Myclass->DateSplit($_REQUEST['Tdate'])."',".MSID.",".$_REQUEST['LGID']."";
		$this->Iframe($qry,'DateWiseInwardReport');
      
    }
	function ItemWiseSales(){
		  $qry=" AMB_point19to20.dbo.Rep_Sales_Itemwise '".$this->Myclass->DateSplit($_REQUEST['Fdate'])."','".$this->Myclass->DateSplit($_REQUEST['Tdate'])."',".MSID.",".$_REQUEST['LGID'].",0";
		$this->Iframe($qry,'DateWiseInwardReport');
      
    }
	
	function InwardTaxReport(){
		  $qry=" AMB_point19to20.dbo.Rep_Tax_Inward '".$this->Myclass->DateSplit($_REQUEST['Fdate'])."','".$this->Myclass->DateSplit($_REQUEST['Tdate'])."',".MSID.",".$_REQUEST['LGID'].",".$_REQUEST['Tax'];
		$this->Iframe($qry,'DateWiseInwardReport');
      
    }
	function SalesTaxReport(){
		  $qry=" AMB_point19to20.dbo.Rep_Tax_Sales '".$this->Myclass->DateSplit($_REQUEST['Fdate'])."','".$this->Myclass->DateSplit($_REQUEST['Tdate'])."',".MSID.",".$_REQUEST['LGID'].",".$_REQUEST['Tax'];
		$this->Iframe($qry,'SalesTaxReport');
      
    }
	function SalesTaxSummary(){
		  $qry=" AMB_point19to20.dbo.Tax_Sales '".$this->Myclass->DateSplit($_REQUEST['Fdate'])."','".$this->Myclass->DateSplit($_REQUEST['Tdate'])."'";
		$this->Iframe($qry,'SalesTaxSummary');
      
    }
	
	function SalesHSNWiseTaxReport(){
		  $qry=" AMB_point19to20.dbo.Rep_HsnTax '".$this->Myclass->DateSplit($_REQUEST['Fdate'])."','".$this->Myclass->DateSplit($_REQUEST['Tdate'])."',".$_REQUEST['LGID'].",".$_REQUEST['Tax'];
		$this->Iframe($qry,'SalesHSNWiseTaxReport');
      
    }
	
	function DateWiseDcReport(){
		  $qry=" AMB_point19to20.dbo.Rep_Dc_Datewise '".$this->Myclass->DateSplit($_REQUEST['Fdate'])."','".$this->Myclass->DateSplit($_REQUEST['Tdate'])."',1,0";
		$this->Iframe($qry,'DateWiseDcReport');
      
    }
	
	function SupplierWiseDcReport(){
		  $qry=" AMB_point19to20.dbo.Rep_Inward_Supewise '".$this->Myclass->DateSplit($_REQUEST['Fdate'])."','".$this->Myclass->DateSplit($_REQUEST['Tdate'])."',".$_REQUEST['LGID'].",0";
		$this->Iframe($qry,'SupplierWiseDcReport');
      
    }
	
	
	
	function Iframe($data,$Rep='')
	{
 
		$html= '<iframe  class="Iframe priprint"  id="iFrameResizer" onload="onMyFrameLoad(this)"
		       src="http://50.63.165.200:8005/?Qry='.$data.'&_'.rand().rand().rand().'&Rep='.$this->RepHead($Rep).'"  ></iframe> ';
		
		echo $html;
		
	}
	function RepHead($Rep)
	{
		$html='<table width="100%" border="0" cellpadding="5" cellspacing="5">
			  <tbody>
				<tr>
				  <td align="center"><h3>'.@SNAME.'</h3>
				  <div align="center">'.@ADD1.' <br>
				  '.@ADD2.' <br>
                      Coimbatore - 641042</p></div>
				  </td>
				</tr>
			 
				
				<tr><td><strong>Report Name :</strong> '.$Rep.'</td></tr>
			  </tbody>
			</table>';
			$html=base64_encode($html);
		return $html;	
	}
	 public function Html_Report($qry)
      {
		 
		  $CI =& get_instance();
		  $this->load->library('table');
		  $query = $this->db->query($qry);	
		  $tmpl = array ( 'table_open'  => '<table id="RTable" border="1" cellpadding="2" cellspacing="1" class="table table-bordered table-striped">' );
		  $this->table->set_template($tmpl);	
		  $html=$CI->table->generate($query); 
		  $html="<div class='box-body table-responsive'>".$html."</div>";
		  echo $html;
	  }   
}