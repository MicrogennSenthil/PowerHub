<?php

class Myclass extends CI_Model
{
	function __construct()
    {
        parent::__construct();

    }
    function Menu($ID=0){

	  $qry=" exec  Gen_Menu ".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Block($ID=0){

	  $qry=" exec  Get_Block ".Hotel_Id.",".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Floor($ID=0){

	  $qry=" exec  Get_Floor ".Hotel_Id.",".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Regester($ID=0){

	  $qry=" exec  Get_Regester ".Hotel_Id.",".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Room($ID=0){

	  $qry=" exec  Get_Room ".Hotel_Id.",".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function RoomType($ID=0){

	  $qry=" exec  Get_RoomType ".Hotel_Id.",".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Device($ID=0){

	  $qry=" exec  Get_Device ".Hotel_Id.",".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Control($ID=0){

	  $qry=" exec  Get_Control ".Hotel_Id.",".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	 function Customer($ID=0){

	   $qry=" exec  Get_Customer  ".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	 function ControlType($ID=0){

	   $qry=" exec  Get_ControlType ".Hotel_Id.",".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	 function ProcessAp($ID=0){

	  $qry=" exec  Get_ProcessAp ".Hotel_Id.",".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Process($ID=0){

	   $qry=" exec  Get_Process ";
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Status($ID=0){

	  $qry=" exec  Get_Status ".Hotel_Id.",".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    } 
	function Status_DF($ID=0,$DF=0){

		$qry=" exec  Get_Status_DF ".Hotel_Id.",".$ID.",".$DF;
		$res=$this->db->query($qry);
		$Res= json_encode($res->result());
		$Res=json_decode($Res,true);
		return $Res;
	  } 
    function DateSplit($dat)
	{
		$dat=str_replace('/','-',$dat);
		$Odate = explode(' ', $dat);
		$date = explode('-',$Odate[0]);
		$month = $date[1];
		$day   = $date[0];
		$year  = $date[2];
		return $month."-".$day."-".$year;
	}
function GetRec($msg,$res,$qry)
  {
	   $output = array();
	   $output['Qry']=$qry;
	  if($msg['message']!="")
	  {
		$output['Success']=false;
		$output['MSG']=$this->ErrMessage($msg['message']);
		print_r(json_encode($output));

	  }
	  else
	  {
		  $res=$res->row();
		  $output['Success']=true;
		  $output['MSG']=$res->MGS;
		  print_r(json_encode($output));

	  }
  }

  function ErrMessage($Msg)
  {
	  $M=$Msg;
	  if (strpos($Msg, 'UNIQUE KEY') !== false)
	  {
		 $A= explode("'",$Msg);
		 $M= @$A[1].@$A[4];
	  }

	  return $M;
  }
  function UserGroup($ID=0){

	$qry=" exec  Get_UserGroup ".Hotel_Id.",".$ID;
	$res=$this->db->query($qry);
	$Res= json_encode($res->result());
	$Res=json_decode($Res,true);
	return $Res;
  }
  function User($ID=0){
	$qry=" exec  Get_User ".Hotel_Id.",".$ID;
	$res=$this->db->query($qry);
	$Res= json_encode($res->result());
	$Res=json_decode($Res,true);
	return $Res;
  }

}
