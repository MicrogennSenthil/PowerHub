<?php

class Mydata extends CI_Model
{
	function __construct()
    {
        parent::__construct();
    }
	
	function Supplier($ID=0){
     
	  $qry=" exec  Get_Supplier ".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Staff($ID=0){
     
	  $qry=" exec  Get_Staff ".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Collection($ID=0){
     
	  $qry=" exec  Edit_Collection ".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Payment($ID=0){
     
	  $qry=" exec  Edit_Payment ".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Purdet($ID=0,$FD=0,$TD=0){
     
	   $qry=" exec  View_GRN ".$ID.",'".$this->Myclass->DateSplit($FD)."','".$this->Myclass->DateSplit($TD)."'";
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Purchase($ID=0){
     
	   $qry=" exec  Edit_PurchaseDc ".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Investment($ID=0){
     
	  $qry=" exec  Edit_Investment ".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Sales($ID=0){
     
	  $qry=" exec  Edit_SalesDc ".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function BalSalesOrder($ID=0){
     
	  $qry=" exec  Get_BalSalesOrder ".$ID;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function QualityGrn($ID=0){
     
	  $qry=" exec  Det_Quality " ;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function Get_DC($ID=0,$FD=0,$TD=0){
     
	  $qry=" exec  Get_DC ".$ID.",'".$this->Myclass->DateSplit($FD)."','".$this->Myclass->DateSplit($TD)."'";
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
    }
	function SalaryReceipt($ID=0){
     
	  $qry=" exec  Edit_SalaryReceipt ".$ID ;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
		
	}
	function SalaryPayment($ID=0){
     
	  $qry=" exec  Edit_SalaryPayment ".$ID ;
	  $res=$this->db->query($qry);
	  $Res= json_encode($res->result());
	  $Res=json_decode($Res,true);
	  return $Res;
		
	}
}