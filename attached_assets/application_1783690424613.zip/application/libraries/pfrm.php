<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class pfrm {

        public function FrmHead1($Title,$load,$view)
        {
			 echo  '<form name="scsfrm" id="scsfrm" method="post" >';
			 echo '<input type="hidden" name="Mname" id="Mname" value="'.$load.'"  >';
			 echo '<input type="hidden" name="Scs_index" id="Scs_index" value="'.scs_index.'"  >';
			 echo '<section class="content">
				   <div class="box">
				   <div class="box-header with-border">
					<h3 class="box-title">'.$Title.'</h3>
					<a href="'.scs_index.$view.'" class="btn   btn-danger btn-sm pull-right" ><i class="fa fa-eye" aria-hidden="true"></i> VIEW</a> 
					<a href="'.scs_index.$load.'" id="Rload" class="btn btn-success btn-sm pull-right" ><i class="fa fa-plus" aria-hidden="true"></i> New</a> </div>
					<div class="box-body">';
			 
			 	   
        }
		public function FrmHead2($Title,$load,$view)
        {
			 echo  '<form name="scsfrm" id="scsfrm" method="post" >';
			 echo '<input type="hidden" name="Mname" id="Mname" value="'.$load.'"  >';
			 echo '<input type="hidden" name="Scs_index" id="Scs_index" value="'.scs_index.'"  >';
			 echo '<section class="content">
				   <div class="box">
				   <div class="box-header with-border">
					<h3 class="box-title">'.$Title.'</h3>
					 
					<a href="'.scs_index.$load.'" id="Rload" class="btn btn-success btn-sm pull-right" ><i class="fa fa-refresh" aria-hidden="true"></i> Reload</a> </div>
					<div class="box-body">';
			 
			 	   
        }
		
		public function FrmHead3($Title,$load,$view)
        {
			 echo  '<form name="scsfrm" id="scsfrm" method="post" >';
			 echo '<input type="hidden" name="Mname" id="Mname" value="'.$load.'"  >';
			 echo '<input type="hidden" name="Scs_index" id="Scs_index" value="'.scs_index.'"  >';
			 echo '<section class="content">
				   <div class="box">
				   <div class="box-header with-border">
					<h3 class="box-title">'.$Title.'</h3>
					 
					<a href="'.scs_index.$load.'" id="Rload" class="btn btn-success btn-sm pull-right" >
					<i class="fa fa-refresh" aria-hidden="true"></i> Reload</a>
					
					<a href="#" onClick="WinPrint()" id="Print" class="btn btn-warning btn-sm pull-right" >
					<i class="fa fa-print" aria-hidden="true"></i> Print</a>
					
					<a href="#" onClick="WinPdf(&#39;'.$Title.'&#39;)" id="Pdf" class="btn btn-danger btn-sm pull-right" >
					<i class="fa fa-file-pdf-o" aria-hidden="true"></i> PDF</a>

					</div>
					<div class="box-body">';
			 
			 	   
        }
		public function FrmHeadD($Title,$load,$view)
        {
			 echo  '<form name="scsfrm" id="scsfrm" method="post" >';
			 
			 echo '<section class="content">
				   <div class="box">
				 
					<div class="box-body">';
			 
			 	   
        }
		 public function FrmFoot()
		 {
			 echo '   </div></div></section></form>';
		 }
}