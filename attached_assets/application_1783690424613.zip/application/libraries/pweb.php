<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class pweb {

        public function phead()
        {
			 echo '<!DOCTYPE html>
				   <html><head><meta charset="utf-8">
  				   <meta http-equiv="X-UA-Compatible" content="IE=edge">
                   <title>::: Mpower V 1.0  :::</title>
				   ';
			 echo '<meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">';
			 	   
        }
		public function ltop()
        {
			echo '</head>';
		}
		public function wtop()
        {
			echo '</head>
			<script src="'.scs_url.'assets/js/jquery.js"></script>
			
			<body class="hold-transition skin-green-light layout-top-nav">';
			echo '<div class="wrapper">';
		} 
		public function wheader($Session)
		{
			  echo '<header class="main-header">
			  <nav class="navbar navbar-static-top">
			  <div class="container-fluid">
        <div class="navbar-header">				 
					<a style="margin-left:-15px" href="'.scs_url.'"  >
					 <img src="'.scs_url.'assets/logo.PNG" width="128px" height="50px"
					  class="user-image" alt="User Image"></a>
					 
		  </div>';
			  
			
			  echo ' <div class="navbar-custom-menu">
			  <ul class="nav navbar-nav ">
			  
			  
			  <li class="dropdown notifications-menu  ">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" aria-expanded="true">
            <b style="font-size:18px" > '.@$Session->userdata['POS']['Hotel'].'</b>
               
            </a>
             
          </li>
			  
			  			  
			        <li class="dropdown user user-menu">
					<a href="#" class="dropdown-toggle" data-toggle="dropdown">
					  <img src="'.scs_url.'upload/'.Logo.'.PNG?'.rand().'" class="user-image" alt="User Image">
					  <span class="hidden-xs">'.@$Session->userdata['POS']['UserName'].'</span>
					</a>
                    <ul class="dropdown-menu">
					<li class="user-header">
					<img src="'.scs_url.'upload/'.Logo.'.PNG?'.rand(),'" class="img-circle" alt="User Image">
 
				 <p> 
				   '.@$Session->userdata['POS']['UserName'].'
					
				 </p>
			   </li>   
					  
					  
					  
					             
              <!-- Menu Footer-->
              <li class="user-footer">
                <div class="pull-left">
                  <a href="'.scs_index.'Welcome/Profile" class="btn btn-default btn-flat">Profile</a>
                </div>
                <div class="pull-right">
                  <a href="'.scs_index.'login/logout" class="btn btn-default btn-flat">Sign out</a>
                </div>
              </li>
            </ul>
          </li>
				   </ul></div> 
				   ';	   		
					    
		
		}
		
		public function Menu($Menu,$Session)
		{

			
			$this->UserPanel($Session);
			 $Menu->Menu_($Menu);
			
			echo '</div></nav></header><div class="content-wrapper">';
		}
		public function wfoot()
        {
			echo '</div></div>
			
			<div id="dialogitem" title="Item Search" style="display:none" ><fieldset>
  			<input id="Ser_Item" onkeyup="Item_ser(this.value)" type="search"   class="search">
  			<div  id="Item_View" ></div></fieldset></div>
			
			<div id="dialogpopHead" title="Head Search" style="display:none" ><fieldset>
  			<input id="Ser_Head" onkeyup="Head_ser(this.value)" type="search"   class="search">
  			<div  id="popHead_View" ></div></fieldset></div>
			
			<div id="dialogpopHeadEx" title="Head Search" style="display:none" ><fieldset>
  			<input id="Ser_Head" onkeyup="Head_ser_Ex(this.value)" type="search"   class="search">
  			<div  id="popHead_Ex_View" ></div></fieldset></div>
			
			<div id="dialogStockitem" title="Item Search" style="display:none" ><fieldset>
  			<input id="Ser_StockItem" onkeyup="StockItem_ser(this.value)" type="search"   class="search">
  			<div  id="StockItem_View" ></div></fieldset></div>
			
			<div id="dialogsupplier" title="Supplier" style="display:none" ><fieldset>
  			<input id="Supplier_Item" onkeyup="Supplier_ser(this.value)" type="search"   class="search">
  			<div  id="Supplier_View" ></div></fieldset></div>
			
			<div id="dialogCustomer" title="Customer" style="display:none" ><fieldset>
  			<input id="Customer_Item" onkeyup="Customer_ser(this.value)" type="search"   class="search">
  			<div  id="Customer_View" ></div></fieldset></div>
			
			<div id="dialogpopitem" title="Item Search" style="display:none" ><fieldset>
  			<input id="Ser_popItem" onkeyup="Ser_popItem(this.value)" type="search"   class="search">
  			<div  id="popItem_View" ></div></fieldset></div>
			
			</body></html>';
			 
		}
		
		//##############################
		
		public function UserPanel($Session)
		{
			  '<div class="user-panel">
					<div class="pull-left image">
					  <img  class="img-circle"  >
					</div>
					<div class="pull-left info">
					  <p>'.@$Session->userdata['POS']['EmailId'].'</p>
					  <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
					</div>
				  </div>';
		}
		public function Cheader($Menu,$Title)
		{
			echo '<section class="content-header">
				  <h5>'.$Menu.'</h5>
				  <ol class="breadcrumb">
					<li><a href="#"><i class="fa fa-dashboard"></i> '.$Menu.'</a></li>
					<li><a href="#">'.$Title.'</a></li>
					 
				  </ol>
				</section>';
		}
}